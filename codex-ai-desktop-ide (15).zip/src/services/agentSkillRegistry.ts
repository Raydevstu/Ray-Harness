import { AgentSkill, AgentTool, AgentRole, AgentToolInvocation } from '../types';

// ============================================================================
// Core Practical Tools Registry for Ray Harness
// ============================================================================

export const REGISTERED_TOOLS: AgentTool[] = [
  // 1. Read File Tool
  {
    id: 'read_file',
    name: 'Read File',
    description: 'Reads the complete text content of a workspace file without modifying it.',
    category: 'workspace',
    permissionLevel: 'read_only',
    requiresApproval: false,
    isMutating: false,
    supportedRoles: ['code_executor', 'architect', 'reviewer', 'collaborator'],
    parameters: [
      {
        name: 'path',
        type: 'string',
        description: 'Relative or workspace path of the file to inspect (e.g. config/config.toml, src/render.rs)',
        required: true,
      },
    ],
  },

  // 2. List Workspace Files Tool
  {
    id: 'list_workspace_files',
    name: 'List Workspace Files',
    description: 'Enumerates files, folders, and templates in the active project worktree.',
    category: 'workspace',
    permissionLevel: 'read_only',
    requiresApproval: false,
    isMutating: false,
    supportedRoles: ['code_executor', 'architect', 'reviewer', 'collaborator'],
    parameters: [
      {
        name: 'directory',
        type: 'string',
        description: 'Optional subfolder path to list (defaults to project root)',
        required: false,
        default: '',
      },
    ],
  },

  // 3. Search Code Tool
  {
    id: 'search_code',
    name: 'Search Workspace Code',
    description: 'Searches for substrings or identifiers across all workspace source and configuration files.',
    category: 'workspace',
    permissionLevel: 'read_only',
    requiresApproval: false,
    isMutating: false,
    supportedRoles: ['code_executor', 'architect', 'reviewer', 'collaborator'],
    parameters: [
      {
        name: 'query',
        type: 'string',
        description: 'The search query or pattern to locate',
        required: true,
      },
      {
        name: 'caseSensitive',
        type: 'boolean',
        description: 'Whether to match casing exactly',
        required: false,
        default: false,
      },
    ],
  },

  // 4. Validate TOML Config Tool
  {
    id: 'validate_toml_config',
    name: 'Validate TOML Configuration',
    description: 'Validates TOML configuration against config.schema.json, checking allowed keys, types, and required array structures.',
    category: 'config',
    permissionLevel: 'read_only',
    requiresApproval: false,
    isMutating: false,
    supportedRoles: ['architect', 'reviewer', 'collaborator', 'code_executor'],
    parameters: [
      {
        name: 'tomlContent',
        type: 'string',
        description: 'Optional raw TOML string to validate. If omitted, uses active config/config.toml content.',
        required: false,
      },
    ],
  },

  // 5. Execute Terminal Command Tool
  {
    id: 'execute_terminal_command',
    name: 'Execute Terminal Command',
    description: 'Executes a safe sandboxed terminal command (e.g. cargo check, git status, cargo test) with exit-code tracking and safety validation.',
    category: 'terminal',
    permissionLevel: 'terminal_safe',
    requiresApproval: false,
    isMutating: false,
    supportedRoles: ['code_executor', 'collaborator'],
    parameters: [
      {
        name: 'command',
        type: 'string',
        description: 'Command line string to run in workspace (e.g. cargo check, git status, git diff)',
        required: true,
      },
      {
        name: 'cwd',
        type: 'string',
        description: 'Working directory path (default: jarvis-app)',
        required: false,
        default: 'jarvis-app',
      },
    ],
  },

  // 6. Propose File Patch Tool (Mutating - Approval Gated)
  {
    id: 'propose_file_patch',
    name: 'Propose File Patch',
    description: 'Generates a structured AST diff patch for user inspection and explicit approval. Does NOT mutate files without approval.',
    category: 'patch',
    permissionLevel: 'workspace_write',
    requiresApproval: true,
    isMutating: true,
    supportedRoles: ['code_executor', 'architect'],
    parameters: [
      {
        name: 'path',
        type: 'string',
        description: 'Target file path to modify (e.g. config/config.toml, src/render.rs)',
        required: true,
      },
      {
        name: 'proposedContent',
        type: 'string',
        description: 'Complete new proposed content for the target file',
        required: true,
      },
      {
        name: 'explanation',
        type: 'string',
        description: 'Human-readable explanation of why this patch is necessary',
        required: true,
      },
    ],
  },

  // 7. Run Cargo Tests Tool
  {
    id: 'run_cargo_tests',
    name: 'Run Cargo Test Suite',
    description: 'Runs workspace test suite assertions (e.g. cargo test --bin jarvis-tests) and reports pass/fail tallies.',
    category: 'test',
    permissionLevel: 'terminal_safe',
    requiresApproval: false,
    isMutating: false,
    supportedRoles: ['code_executor', 'collaborator'],
    parameters: [
      {
        name: 'filter',
        type: 'string',
        description: 'Optional test name filter (e.g. test_default_mode_rendering)',
        required: false,
        default: '',
      },
    ],
  },
];

// ============================================================================
// Practical Agent Skills Registry
// ============================================================================

export const REGISTERED_SKILLS: AgentSkill[] = [
  {
    id: 'workspace_inspector',
    name: 'Workspace Inspector',
    version: '1.0.0',
    description: 'Read-only skill for exploring the workspace directory, viewing file contents, and inspecting templates.',
    category: 'workspace',
    permissionLevel: 'read_only',
    requiresApproval: false,
    status: 'approved',
    supportedRoles: ['code_executor', 'architect', 'reviewer', 'collaborator'],
    tools: REGISTERED_TOOLS.filter(t => ['read_file', 'list_workspace_files'].includes(t.id)),
  },
  {
    id: 'workspace_search',
    name: 'Workspace Code Search',
    version: '1.0.0',
    description: 'Fast substring search and symbol indexing across source code, templates, and TOML configuration files.',
    category: 'analysis',
    permissionLevel: 'read_only',
    requiresApproval: false,
    status: 'approved',
    supportedRoles: ['code_executor', 'architect', 'reviewer', 'collaborator'],
    tools: REGISTERED_TOOLS.filter(t => ['search_code'].includes(t.id)),
  },
  {
    id: 'config_validator',
    name: 'TOML & Schema Validator',
    version: '1.1.0',
    description: 'Evaluates config.toml validity against config.schema.json, checking notify array flags and model directives.',
    category: 'analysis',
    permissionLevel: 'read_only',
    requiresApproval: false,
    status: 'approved',
    supportedRoles: ['architect', 'reviewer', 'collaborator', 'code_executor'],
    tools: REGISTERED_TOOLS.filter(t => ['validate_toml_config'].includes(t.id)),
  },
  {
    id: 'terminal_runner',
    name: 'Safe Terminal Execution',
    version: '1.2.0',
    description: 'Sandboxed command execution processor enforcing security policies and tracking POSIX exit codes.',
    category: 'execution',
    permissionLevel: 'terminal_safe',
    requiresApproval: false,
    status: 'approved',
    supportedRoles: ['code_executor', 'collaborator'],
    tools: REGISTERED_TOOLS.filter(t => ['execute_terminal_command'].includes(t.id)),
  },
  {
    id: 'patch_engine',
    name: 'AST Patch Proposal Engine',
    version: '2.0.0',
    description: 'Mutating patch generation engine. Enforces side-by-side Monaco diff review and mandatory developer sign-off.',
    category: 'system',
    permissionLevel: 'workspace_write',
    requiresApproval: true,
    status: 'approved',
    supportedRoles: ['code_executor', 'architect'],
    tools: REGISTERED_TOOLS.filter(t => ['propose_file_patch'].includes(t.id)),
  },
  {
    id: 'test_suite_runner',
    name: 'Cargo Verification Runner',
    version: '1.0.0',
    description: 'Runs integration tests and assertions for render modes, command processor safety, and collaborator RPC.',
    category: 'execution',
    permissionLevel: 'terminal_safe',
    requiresApproval: false,
    status: 'approved',
    supportedRoles: ['code_executor', 'collaborator'],
    tools: REGISTERED_TOOLS.filter(t => ['run_cargo_tests'].includes(t.id)),
  },
];

// ============================================================================
// Registry Query and Validation Helpers
// ============================================================================

export function getSkill(skillId: string): AgentSkill | undefined {
  return REGISTERED_SKILLS.find(s => s.id === skillId);
}

export function getTool(toolId: string): AgentTool | undefined {
  return REGISTERED_TOOLS.find(t => t.id === toolId);
}

export function getSkillsForRole(role: AgentRole): AgentSkill[] {
  return REGISTERED_SKILLS.filter(s => s.supportedRoles.includes(role));
}

export function getToolsForRole(role: AgentRole): AgentTool[] {
  return REGISTERED_TOOLS.filter(t => t.supportedRoles.includes(role));
}

export function validateToolInvocation(
  invocation: AgentToolInvocation,
  executingRole: AgentRole
): { valid: boolean; error?: string; tool?: AgentTool; skill?: AgentSkill } {
  if (!invocation || typeof invocation !== 'object') {
    return { valid: false, error: 'Malformed tool invocation payload' };
  }

  const { toolId, parameters = {} } = invocation;
  if (!toolId || typeof toolId !== 'string') {
    return { valid: false, error: 'Missing or invalid toolId' };
  }

  const tool = getTool(toolId);
  if (!tool) {
    return { valid: false, error: `Unknown tool ID: '${toolId}'. Not registered in skill catalog.` };
  }

  // Check role authorization
  if (!tool.supportedRoles.includes(executingRole)) {
    return {
      valid: false,
      error: `Role '${executingRole}' is not permitted to execute tool '${toolId}'. Allowed roles: [${tool.supportedRoles.join(', ')}]`,
      tool,
    };
  }

  // Validate parameters schema
  for (const param of tool.parameters) {
    const val = parameters[param.name];

    if (param.required && (val === undefined || val === null || val === '')) {
      return {
        valid: false,
        error: `Missing required parameter '${param.name}' for tool '${toolId}'`,
        tool,
      };
    }

    if (val !== undefined && val !== null) {
      const actualType = Array.isArray(val) ? 'array' : typeof val;
      if (param.type !== actualType) {
        return {
          valid: false,
          error: `Parameter '${param.name}' expected type '${param.type}', got '${actualType}'`,
          tool,
        };
      }
    }
  }

  // Find owning skill
  const skill = REGISTERED_SKILLS.find(s => s.tools.some(t => t.id === tool.id));

  return { valid: true, tool, skill };
}
