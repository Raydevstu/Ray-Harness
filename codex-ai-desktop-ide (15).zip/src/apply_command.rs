//! Command mutation handler for UI mode switching, template selection,
//! and contextual state transitions.

use crate::render::{AppConfig, RenderContext, render_layout};
use crate::legacy_apply_patch_exec_command_warning::LegacyApplyPatchExecCommandWarning;

pub enum Command {
    SwitchMode(String),
    UpdateContext(String),
    ExecutePatch(String),
    SetObjective(String),
}

pub struct SystemState {
    pub config: AppConfig,
    pub current_snapshot: String,
    pub active_template: String,
    pub planning_phase: String,
    pub plan_objective: String,
    pub plan_steps: String,
}

pub fn apply_ui_command(cmd: Command, state: &mut SystemState) -> Result<String, String> {
    match cmd {
        Command::SwitchMode(new_mode) => {
            state.config.ui_mode = new_mode.clone();
            state.active_template = match new_mode.as_str() {
                "plan" => include_str!("../core/templates/plan.md").to_string(),
                "agent" => include_str!("../core/templates/agents/collaboration.md").to_string(),
                _ => include_str!("../core/templates/default.md").to_string(),
            };
        }
        Command::UpdateContext(new_ctx) => {
            state.current_snapshot = new_ctx;
        }
        Command::SetObjective(obj) => {
            state.plan_objective = obj;
        }
        Command::ExecutePatch(patch_data) => {
            let (was_deprecated, _sanitized) =
                LegacyApplyPatchExecCommandWarning::sanitize_instruction(&patch_data);
            if was_deprecated {
                eprintln!("[Warning] Legacy exec command intercepted. Redirecting to apply_patch tool.");
            }
        }
    }

    let ctx = RenderContext {
        apps_info: "Active Apps: [Git, Filesystem, Terminal, Google GenAI]",
        context_snapshot: &state.current_snapshot,
        execution_output: "Ready.",
        template_content: &state.active_template,
        planning_phase: &state.planning_phase,
        plan_objective: &state.plan_objective,
        plan_steps: &state.plan_steps,
    };

    render_layout(&state.config, &ctx)
}
