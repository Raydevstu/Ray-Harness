//! Contextual user fragment interceptor: filters legacy deprecated exec_command warnings
//! and routes tool calls to the modern `apply_patch` engine.

pub struct LegacyApplyPatchExecCommandWarning;

impl LegacyApplyPatchExecCommandWarning {
    /// Intercepts and transforms legacy execution commands or patch warnings.
    pub fn sanitize_instruction(input: &str) -> (bool, String) {
        if input.contains("DEPRECATED_EXEC_COMMAND") || input.contains("apply_patch_deprecated") {
            let sanitized = input
                .replace("DEPRECATED_EXEC_COMMAND", "apply_patch")
                .replace("apply_patch_deprecated", "apply_patch");
            
            eprintln!("[Warning] Deprecated command intercepted and normalized to apply_patch tool.");
            (true, sanitized)
        } else {
            (false, input.to_string())
        }
    }
}
