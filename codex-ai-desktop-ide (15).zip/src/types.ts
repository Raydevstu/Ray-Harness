export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  thought?: string;
  isHighThinking?: boolean;
  modelUsed?: string;
  toolCalls?: Array<{
    name: string;
    args: Record<string, unknown>;
    result?: string;
    durationMs?: number;
  }>;
  presetCode?: {
    lang: string;
    title: string;
    code: string;
  };
  warning?: {
    title: string;
    items: string[];
  };
  patchProposal?: FilePatch;
  patchSetProposal?: FilePatchSet;
}

export type PatchApprovalStatus = 'pending' | 'reviewing' | 'approved' | 'rejected' | 'applied' | 'failed';

export type PatchSetStatus =
  | 'proposed'
  | 'reviewing'
  | 'approved'
  | 'rejected'
  | 'stale'
  | 'partially_invalid'
  | 'applied'
  | 'failed';

export interface FilePatch {
  type: 'file_patch';
  patchId: string;
  path: string;
  originalContent: string;
  proposedContent: string;
  requiresApproval?: boolean;
  status?: PatchApprovalStatus;
  explanation?: string;
  language?: string;
  authorAgent?: string;
  timestamp?: string;
}

export interface FilePatchSet {
  type: 'file_patch_set';
  patchSetId: string;
  description: string;
  patches: FilePatch[];
  createdAt: string;
  status: PatchSetStatus;
  requiresApproval: boolean;
  correlationId?: string;
  authorAgent?: AgentRole | string;
  staleState?: Record<string, { path: string; expectedOriginalContent: string }>;
}

export interface DiffApprovalRequest {
  id: string;
  patch: FilePatch;
  source: 'chat' | 'agent' | 'terminal';
  status: PatchApprovalStatus;
  timestamp: string;
  error?: string;
}

export interface PatchApprovalResult {
  success: boolean;
  patchId: string;
  path: string;
  status: PatchApprovalStatus;
  error?: string;
  appliedAt?: string;
}

export interface PatchSetApprovalResult {
  success: boolean;
  patchSetId: string;
  status: PatchSetStatus;
  error?: string;
  appliedAt?: string;
  appliedPatchesCount?: number;
}

export type ModelOption =
  | 'Gemini 3.8 Flash'
  | 'Gemini 3.5 Flash'
  | '5.6 Luna Light'
  | 'Gemini 3.1 Pro (High Thinking)';

export interface FileItem {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'dir';
  language?: string;
  content?: string;
  children?: FileItem[];
}

export interface TabItem {
  id: string;
  name: string;
  path: string;
  language: string;
  content: string;
  isModified?: boolean;
}

export interface ProjectInfo {
  name: string;
  active: boolean;
  branch: string;
  filesCount: number;
}

export type AgentRole = 'code_executor' | 'architect' | 'reviewer' | 'collaborator';

export type AgentPermissionLevel =
  | 'read_only'
  | 'workspace_write'
  | 'terminal_safe'
  | 'terminal_elevated'
  | 'network'
  | 'destructive';

export interface AgentToolParameter {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'object' | 'array';
  description: string;
  required: boolean;
  defaultValue?: unknown;
}

export interface AgentTool {
  id: string;
  name: string;
  description: string;
  permissionLevel: AgentPermissionLevel;
  requiresApproval: boolean;
  isMutating: boolean;
  parameters: AgentToolParameter[];
}

export interface AgentSkill {
  id: string;
  name: string;
  version: string;
  description: string;
  category: 'inspection' | 'filesystem' | 'terminal' | 'validation' | 'testing' | 'reasoning' | 'patching';
  tools: AgentTool[];
  requiredPermission: AgentPermissionLevel;
  requiresApproval: boolean;
  allowedRoles: AgentRole[];
  status: 'approved' | 'pending' | 'revoked';
}

export interface AgentExecutionContext {
  agentRole: AgentRole;
  correlationId: string;
  userApproved?: boolean;
  files?: FileItem[];
}

export interface AgentToolResult {
  success: boolean;
  toolId: string;
  skillId: string;
  correlationId: string;
  summary: string;
  data?: unknown;
  error?: string;
  requiresApproval?: boolean;
  patchProposal?: FilePatch;
  patchSetProposal?: FilePatchSet;
  durationMs?: number;
  permissionLevel: AgentPermissionLevel;
}

export interface AgentInfo {
  id: AgentRole;
  name: string;
  description: string;
  model: string;
  status: 'idle' | 'running' | 'waiting' | 'syncing';
  currentTask: string;
  concurrency: number;
}

export interface AgentMessage {
  id: string;
  fromAgent: AgentRole | 'user';
  toAgent: AgentRole | 'fleet';
  timestamp: string;
  subject: string;
  body: string;
  status?: 'pending' | 'approved' | 'completed' | 'in_progress' | 'rejected';
  codeSnippet?: string;
  actionRequired?: boolean;
}

export type TimelineEventCategory =
  | 'chat'
  | 'agent'
  | 'tool'
  | 'terminal'
  | 'patch'
  | 'system'
  | 'error';

export type TimelineEventStatus =
  | 'pending'
  | 'running'
  | 'completed'
  | 'failed'
  | 'rejected'
  | 'cancelled';

export type TimelineEventType =
  | 'chat_started'
  | 'chat_completed'
  | 'chat_failed'
  | 'agent_started'
  | 'agent_message'
  | 'agent_completed'
  | 'agent_failed'
  | 'tool_started'
  | 'tool_completed'
  | 'tool_failed'
  | 'tool_rejected'
  | 'command_started'
  | 'command_completed'
  | 'command_failed'
  | 'command_cancelled'
  | 'patch_proposed'
  | 'patch_review_opened'
  | 'patch_approved'
  | 'patch_rejected'
  | 'patch_applied'
  | 'patch_apply_failed'
  | 'patch_stale'
  | 'patch_set_proposed'
  | 'patch_set_review_opened'
  | 'patch_set_approved'
  | 'patch_set_rejected'
  | 'patch_set_stale'
  | 'patch_set_failed'
  | 'patch_set_applied'
  | 'system_init'
  | 'system_error';

export interface TimelineEvent {
  id: string;
  timestamp: string;
  createdAt?: number;
  sessionId?: string;
  type: TimelineEventType | string;
  category: TimelineEventCategory;
  status: TimelineEventStatus;
  title: string;
  description?: string;
  source: 'chat' | 'agent' | 'terminal' | 'system' | 'gemini';
  durationMs?: number;
  toolName?: string;
  commandSummary?: string;
  filePath?: string;
  patchId?: string;
  patchSetId?: string;
  correlationId?: string;
  metadata?: Record<string, unknown>;
  error?: string;
}

