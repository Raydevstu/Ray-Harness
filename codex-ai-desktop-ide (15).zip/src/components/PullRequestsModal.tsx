import React from 'react';
import { X, GitPullRequest, GitMerge, CheckCircle2, Clock, GitBranch } from 'lucide-react';

interface PullRequestsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PullRequestsModal: React.FC<PullRequestsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const prs = [
    {
      id: 42,
      title: 'feat(harness): integrate model-aware context budget controller',
      author: 'Hurera K',
      branch: 'feat/context-budget',
      status: 'Open',
      checks: '4/4 Passed',
      updated: '12m ago',
    },
    {
      id: 39,
      title: 'fix(config): enforce production linkUrl broker authentication keys',
      author: 'Hurera K',
      branch: 'fix/amr-config-auth',
      status: 'Ready to merge',
      checks: 'All checks green',
      updated: '1h ago',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 font-mono text-xs">
      <div className="w-full max-w-xl bg-[#11131c] border border-[#2c3142] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#181a25] border-b border-[#222635]">
          <div className="flex items-center gap-2">
            <GitPullRequest className="w-4 h-4 text-purple-400" />
            <h2 className="font-bold text-gray-100 text-sm tracking-wide">
              PULL REQUESTS // KAFSH & CODEX
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#222635] rounded text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* PR List */}
        <div className="p-4 space-y-3">
          {prs.map(pr => (
            <div
              key={pr.id}
              className="p-3.5 bg-[#181a25] border border-[#2c3142] rounded-lg hover:border-purple-500/40 transition-colors"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-gray-200 text-[12px]">
                  #{pr.id} {pr.title}
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-950/70 border border-purple-800/50 text-purple-300">
                  {pr.status}
                </span>
              </div>
              <div className="flex items-center gap-3 text-gray-400 text-[11px] mt-2">
                <span className="flex items-center gap-1 text-gray-300">
                  <GitBranch className="w-3 h-3 text-gray-500" />
                  {pr.branch}
                </span>
                <span>by {pr.author}</span>
                <span className="flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3 h-3" /> {pr.checks}
                </span>
                <span className="ml-auto text-gray-500">{pr.updated}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#181a25] border-t border-[#222635] flex items-center justify-between">
          <span className="text-gray-500 text-[11px]">Git remote: origin/main</span>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-[#222635] hover:bg-[#2c3142] text-gray-200 rounded"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
