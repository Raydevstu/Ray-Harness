import React, { useState, useMemo } from 'react';
import {
  Activity,
  Search,
  Filter,
  ArrowUpDown,
  CheckCircle2,
  XCircle,
  Clock,
  Ban,
  Terminal,
  MessageSquare,
  Bot,
  Wrench,
  GitCompare,
  FileCode,
  AlertTriangle,
  ChevronRight,
  ChevronDown,
  Copy,
  Check,
  Trash2,
  ExternalLink,
  ShieldCheck,
} from 'lucide-react';
import { TimelineEvent, TimelineEventCategory, TimelineEventStatus, FileItem, FilePatch } from '../types';

interface TelemetryTimelineProps {
  events: TimelineEvent[];
  onClearEvents?: () => void;
  onOpenFile?: (file: FileItem) => void;
  onOpenPatchReview?: (patch: FilePatch) => void;
  onFocusTerminal?: () => void;
  files?: FileItem[];
}

export const TelemetryTimeline: React.FC<TelemetryTimelineProps> = ({
  events,
  onClearEvents,
  onOpenFile,
  onOpenPatchReview,
  onFocusTerminal,
  files = [],
}) => {
  const [categoryFilter, setCategoryFilter] = useState<TimelineEventCategory | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<TimelineEventStatus | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Category Filter Chips
  const categoryChips: { id: TimelineEventCategory | 'all'; label: string; count: number }[] = useMemo(() => {
    const counts: Record<string, number> = {
      all: events.length,
      chat: 0,
      agent: 0,
      tool: 0,
      terminal: 0,
      patch: 0,
      system: 0,
      error: 0,
    };

    events.forEach(e => {
      counts[e.category] = (counts[e.category] || 0) + 1;
      if (e.status === 'failed' || e.error) {
        counts.error = (counts.error || 0) + 1;
      }
    });

    return [
      { id: 'all', label: 'All', count: counts.all },
      { id: 'chat', label: 'Chat', count: counts.chat || 0 },
      { id: 'agent', label: 'Agent', count: counts.agent || 0 },
      { id: 'tool', label: 'Tools', count: counts.tool || 0 },
      { id: 'terminal', label: 'Terminal', count: counts.terminal || 0 },
      { id: 'patch', label: 'Patches', count: counts.patch || 0 },
      { id: 'error', label: 'Errors', count: counts.error || 0 },
    ];
  }, [events]);

  // Filtered & Sorted Events
  const filteredEvents = useMemo(() => {
    let result = events.filter(e => {
      // Category check (special error tab)
      if (categoryFilter === 'error') {
        if (e.status !== 'failed' && !e.error) return false;
      } else if (categoryFilter !== 'all' && e.category !== categoryFilter) {
        return false;
      }

      // Status check
      if (statusFilter !== 'all' && e.status !== statusFilter) {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = e.title.toLowerCase().includes(q);
        const matchesDesc = (e.description || '').toLowerCase().includes(q);
        const matchesCmd = (e.commandSummary || '').toLowerCase().includes(q);
        const matchesFile = (e.filePath || '').toLowerCase().includes(q);
        const matchesTool = (e.toolName || '').toLowerCase().includes(q);
        const matchesPatch = (e.patchId || '').toLowerCase().includes(q);
        const matchesError = (e.error || '').toLowerCase().includes(q);
        return matchesTitle || matchesDesc || matchesCmd || matchesFile || matchesTool || matchesPatch || matchesError;
      }

      return true;
    });

    return [...result].sort((a, b) => {
      const timeA = a.createdAt || 0;
      const timeB = b.createdAt || 0;
      if (sortOrder === 'desc') {
        return timeB - timeA;
      }
      return timeA - timeB;
    });
  }, [events, categoryFilter, statusFilter, searchQuery, sortOrder]);

  const selectedEvent = useMemo(() => {
    return events.find(e => e.id === selectedEventId) || null;
  }, [events, selectedEventId]);

  const handleCopyEventJson = (e: TimelineEvent) => {
    const payload = JSON.stringify(e, null, 2);
    navigator.clipboard.writeText(payload);
    setCopiedId(e.id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const getCategoryIcon = (category: TimelineEventCategory) => {
    switch (category) {
      case 'chat':
        return <MessageSquare className="w-3.5 h-3.5 text-blue-400" />;
      case 'agent':
        return <Bot className="w-3.5 h-3.5 text-purple-400" />;
      case 'tool':
        return <Wrench className="w-3.5 h-3.5 text-cyan-400" />;
      case 'terminal':
        return <Terminal className="w-3.5 h-3.5 text-amber-400" />;
      case 'patch':
        return <GitCompare className="w-3.5 h-3.5 text-emerald-400" />;
      case 'error':
        return <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />;
      case 'system':
      default:
        return <Activity className="w-3.5 h-3.5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: TimelineEventStatus) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-1.5 py-0.5 rounded font-medium">
            <CheckCircle2 className="w-2.5 h-2.5" />
            <span>Completed</span>
          </span>
        );
      case 'running':
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] text-sky-400 bg-sky-950/60 border border-sky-800/60 px-1.5 py-0.5 rounded font-medium animate-pulse">
            <Clock className="w-2.5 h-2.5" />
            <span>{status === 'running' ? 'Running' : 'Pending'}</span>
          </span>
        );
      case 'failed':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] text-rose-400 bg-rose-950/60 border border-rose-800/60 px-1.5 py-0.5 rounded font-medium">
            <XCircle className="w-2.5 h-2.5" />
            <span>Failed</span>
          </span>
        );
      case 'rejected':
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] text-amber-400 bg-amber-950/60 border border-amber-800/60 px-1.5 py-0.5 rounded font-medium">
            <Ban className="w-2.5 h-2.5" />
            <span>{status === 'rejected' ? 'Rejected' : 'Cancelled'}</span>
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex-1 overflow-hidden bg-[#0d0f17] flex flex-col font-mono text-xs select-text">
      {/* Search & Filter Header Bar */}
      <div className="p-3 bg-[#11131c] border-b border-[#222635] flex flex-col gap-2.5">
        <div className="flex items-center gap-2">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search runtime timeline events..."
              className="w-full bg-[#181a25] border border-[#262b3d] rounded pl-8 pr-3 py-1 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-blue-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                ×
              </button>
            )}
          </div>

          {/* Sort order toggle */}
          <button
            onClick={() => setSortOrder(prev => (prev === 'desc' ? 'asc' : 'desc'))}
            className="px-2.5 py-1 bg-[#181a25] hover:bg-[#222635] border border-[#262b3d] text-gray-400 hover:text-gray-200 rounded flex items-center gap-1 text-[11px] transition-colors"
            title={sortOrder === 'desc' ? 'Newest first' : 'Oldest first'}
          >
            <ArrowUpDown className="w-3 h-3" />
            <span>{sortOrder === 'desc' ? 'Newest' : 'Oldest'}</span>
          </button>

          {/* Clear events */}
          {onClearEvents && events.length > 0 && (
            <button
              onClick={onClearEvents}
              className="p-1.5 bg-[#181a25] hover:bg-rose-950/50 border border-[#262b3d] hover:border-rose-900/60 text-gray-500 hover:text-rose-400 rounded transition-colors"
              title="Clear Session Timeline"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Category & Status Chips */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-0.5">
            <span className="text-[10px] text-gray-500 uppercase tracking-wider shrink-0 mr-1">Category:</span>
            {categoryChips.map(chip => {
              const isSelected = categoryFilter === chip.id;
              return (
                <button
                  key={chip.id}
                  onClick={() => setCategoryFilter(chip.id)}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-medium flex items-center gap-1 transition-colors whitespace-nowrap cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'bg-[#181a25] text-gray-400 hover:bg-[#222635] hover:text-gray-200 border border-[#262b3d]'
                  }`}
                >
                  <span>{chip.label}</span>
                  <span
                    className={`text-[9px] px-1 py-0.2 rounded-full ${
                      isSelected ? 'bg-blue-800 text-blue-100' : 'bg-[#0e1017] text-gray-500'
                    }`}
                  >
                    {chip.count}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-1 overflow-x-auto scrollbar-none text-[10px]">
            <span className="text-[10px] text-gray-500 uppercase tracking-wider shrink-0 mr-1">Status:</span>
            {(['all', 'running', 'completed', 'failed', 'pending', 'rejected'] as const).map(st => {
              const isSelected = statusFilter === st;
              return (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-1.5 py-0.5 rounded text-[9px] capitalize transition-colors ${
                    isSelected
                      ? 'bg-indigo-600 text-white font-semibold'
                      : 'bg-[#141721] text-gray-400 hover:text-gray-200 hover:bg-[#1e2230] border border-[#262b3d]'
                  }`}
                >
                  {st}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content Area: Split List / Details */}
      <div className="flex-1 flex overflow-hidden">
        {/* Event List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2 divide-y divide-[#1e2333]/40">
          {filteredEvents.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-gray-500">
              <Activity className="w-8 h-8 mb-2 opacity-30 text-gray-400" />
              <div className="text-sm font-semibold text-gray-400">No telemetry events found</div>
              <div className="text-xs text-gray-600 max-w-xs mt-1">
                {searchQuery || categoryFilter !== 'all'
                  ? 'Try adjusting your search query or filter chips.'
                  : 'Execute AI chat, commands, or agent tasks to record runtime telemetry.'}
              </div>
            </div>
          ) : (
            filteredEvents.map(evt => {
              const isSelected = selectedEventId === evt.id;
              const hasError = evt.status === 'failed' || Boolean(evt.error);

              return (
                <div
                  key={evt.id}
                  onClick={() => setSelectedEventId(isSelected ? null : evt.id)}
                  className={`pt-2 p-2.5 rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#191d2c] border-blue-500/60 shadow-md ring-1 ring-blue-500/20'
                      : hasError
                      ? 'bg-rose-950/20 border-rose-900/40 hover:bg-rose-950/30'
                      : 'bg-[#131622]/80 border-[#202538] hover:bg-[#181b2a] hover:border-[#2b324a]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2 min-w-0">
                      <div className="mt-0.5 p-1 rounded bg-[#0b0d14] border border-[#222635] shrink-0">
                        {getCategoryIcon(evt.category)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-gray-200 text-xs truncate">
                            {evt.title}
                          </span>
                          <span className="text-[10px] text-gray-500 font-mono">
                            {evt.timestamp}
                          </span>
                          {evt.durationMs !== undefined && (
                            <span className="text-[10px] text-gray-500 bg-[#0b0d14] px-1 py-0.2 rounded border border-[#222635]">
                              {evt.durationMs}ms
                            </span>
                          )}
                        </div>

                        {evt.description && (
                          <div className="text-[11px] text-gray-400 mt-0.5 line-clamp-2">
                            {evt.description}
                          </div>
                        )}

                        {/* Metadata Tags */}
                        <div className="flex items-center gap-1.5 flex-wrap mt-1.5">
                          {evt.commandSummary && (
                            <span className="text-[10px] text-amber-300 bg-amber-950/40 border border-amber-900/40 px-1.5 py-0.5 rounded flex items-center gap-1">
                              <Terminal className="w-2.5 h-2.5 text-amber-400" />
                              <span className="truncate max-w-[180px]">{evt.commandSummary}</span>
                            </span>
                          )}
                          {evt.filePath && (
                            <span className="text-[10px] text-cyan-300 bg-cyan-950/40 border border-cyan-900/40 px-1.5 py-0.5 rounded flex items-center gap-1">
                              <FileCode className="w-2.5 h-2.5 text-cyan-400" />
                              <span className="truncate max-w-[140px]">{evt.filePath}</span>
                            </span>
                          )}
                          {evt.toolName && (
                            <span className="text-[10px] text-purple-300 bg-purple-950/40 border border-purple-900/40 px-1.5 py-0.5 rounded flex items-center gap-1">
                              <Wrench className="w-2.5 h-2.5 text-purple-400" />
                              <span>{evt.toolName}</span>
                            </span>
                          )}
                          {evt.patchId && (
                            <span className="text-[10px] text-emerald-300 bg-emerald-950/40 border border-emerald-900/40 px-1.5 py-0.5 rounded flex items-center gap-1">
                              <GitCompare className="w-2.5 h-2.5 text-emerald-400" />
                              <span>{evt.patchId}</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {getStatusBadge(evt.status)}
                      <ChevronRight
                        className={`w-3.5 h-3.5 text-gray-500 transition-transform ${
                          isSelected ? 'rotate-90 text-blue-400' : ''
                        }`}
                      />
                    </div>
                  </div>

                  {/* Inline Expanded Inspector Details */}
                  {isSelected && (
                    <div
                      className="mt-3 pt-2.5 border-t border-[#262b3d] text-xs space-y-2 bg-[#0d0f17] p-2.5 rounded"
                      onClick={e => e.stopPropagation()}
                    >
                      <div className="flex items-center justify-between text-[11px] text-gray-400">
                        <span className="font-semibold text-gray-300 flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Event Telemetry Details ({evt.id})</span>
                        </span>
                        <button
                          onClick={() => handleCopyEventJson(evt)}
                          className="px-2 py-0.5 bg-[#181a25] hover:bg-[#222635] text-gray-400 hover:text-gray-200 border border-[#2a2f42] rounded text-[10px] flex items-center gap-1 transition-colors"
                        >
                          {copiedId === evt.id ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                          <span>{copiedId === evt.id ? 'Copied' : 'Copy JSON'}</span>
                        </button>
                      </div>

                      {/* Error Banner */}
                      {evt.error && (
                        <div className="p-2 rounded bg-rose-950/50 border border-rose-800/60 text-rose-300 text-[11px]">
                          <strong>Error:</strong> {evt.error}
                        </div>
                      )}

                      {/* Key-Value Summary Grid */}
                      <div className="grid grid-cols-2 gap-2 text-[11px]">
                        <div>
                          <span className="text-gray-500">Source: </span>
                          <span className="text-gray-300 font-semibold">{evt.source}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Event Type: </span>
                          <span className="text-gray-300">{evt.type}</span>
                        </div>
                        {evt.correlationId && (
                          <div>
                            <span className="text-gray-500">Correlation ID: </span>
                            <span className="text-gray-400 font-mono text-[10px]">
                              {evt.correlationId}
                            </span>
                          </div>
                        )}
                        {evt.durationMs !== undefined && (
                          <div>
                            <span className="text-gray-500">Execution Time: </span>
                            <span className="text-emerald-400 font-semibold">
                              {evt.durationMs}ms
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Sanitized Metadata Viewer */}
                      {evt.metadata && Object.keys(evt.metadata).length > 0 && (
                        <div className="space-y-1">
                          <span className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold">
                            Sanitized Metadata Payload
                          </span>
                          <pre className="p-2 rounded bg-black/60 border border-[#202538] text-[10px] text-gray-300 overflow-x-auto">
                            {JSON.stringify(evt.metadata, null, 2)}
                          </pre>
                        </div>
                      )}

                      {/* Cross-Link Actions */}
                      <div className="pt-2 flex items-center gap-2 flex-wrap border-t border-[#202538]/60">
                        {evt.filePath && onOpenFile && (
                          <button
                            onClick={() => {
                              const found = files.find(f => f.path === evt.filePath || f.name === evt.filePath?.split('/').pop());
                              if (found) {
                                onOpenFile(found);
                              } else if (evt.filePath) {
                                onOpenFile({
                                  id: `file_${Date.now()}`,
                                  name: evt.filePath.split('/').pop() || 'file',
                                  path: evt.filePath,
                                  type: 'file',
                                });
                              }
                            }}
                            className="px-2.5 py-1 rounded bg-blue-950/80 hover:bg-blue-900 border border-blue-800 text-blue-300 text-[10px] font-semibold flex items-center gap-1 transition-colors"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>Open File in Buffer</span>
                          </button>
                        )}

                        {evt.patchId && onOpenPatchReview && (
                          <button
                            onClick={() => {
                              const mockPatch: FilePatch = {
                                type: 'file_patch',
                                patchId: evt.patchId!,
                                path: evt.filePath || 'jarvis-app/config/config.toml',
                                originalContent: '# Baseline original\nui_mode = "plan"\n',
                                proposedContent: '# Proposed modification\nui_mode = "agent"\nnotify = ["terminal-notifier"]\n',
                                explanation: evt.title,
                              };
                              onOpenPatchReview(mockPatch);
                            }}
                            className="px-2.5 py-1 rounded bg-purple-950/80 hover:bg-purple-900 border border-purple-800 text-purple-300 text-[10px] font-semibold flex items-center gap-1 transition-colors"
                          >
                            <GitCompare className="w-3 h-3" />
                            <span>Review Patch Diff</span>
                          </button>
                        )}

                        {evt.category === 'terminal' && onFocusTerminal && (
                          <button
                            onClick={onFocusTerminal}
                            className="px-2.5 py-1 rounded bg-amber-950/80 hover:bg-amber-900 border border-amber-800 text-amber-300 text-[10px] font-semibold flex items-center gap-1 transition-colors"
                          >
                            <Terminal className="w-3 h-3" />
                            <span>Focus Terminal</span>
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
