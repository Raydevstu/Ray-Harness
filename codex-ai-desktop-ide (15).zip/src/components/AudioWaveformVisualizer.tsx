import React, { useState, useEffect, useRef } from 'react';
import {
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Mic,
  Activity,
  Sliders,
  ChevronDown,
  X,
} from 'lucide-react';

interface AudioWaveformVisualizerProps {
  isPlaying: boolean;
  isListening?: boolean;
  onTogglePlay?: () => void;
  onStop?: () => void;
  selectedVoice?: string;
  onSelectVoice?: (voice: string) => void;
  playbackRate?: number;
  onSelectRate?: (rate: number) => void;
  title?: string;
  onClose?: () => void;
}

const VOICES = [
  { name: 'Kore', label: 'Kore (Balanced & Clear)', desc: 'Standard IDE narration' },
  { name: 'Puck', label: 'Puck (Energetic)', desc: 'Fast execution alerts' },
  { name: 'Fenrir', label: 'Fenrir (Deep & Authoritative)', desc: 'Security & review logs' },
  { name: 'Aoede', label: 'Aoede (Melodic)', desc: 'Plan & spec walk-through' },
  { name: 'Charon', label: 'Charon (Studio Warm)', desc: 'AST refactoring trace' },
];

const RATES = [0.75, 1.0, 1.25, 1.5, 2.0];

export const AudioWaveformVisualizer: React.FC<AudioWaveformVisualizerProps> = ({
  isPlaying,
  isListening = false,
  onTogglePlay,
  onStop,
  selectedVoice = 'Kore',
  onSelectVoice,
  playbackRate = 1.0,
  onSelectRate,
  title = 'Gemini 3.1 Pro Audio Speech Engine',
  onClose,
}) => {
  const [volume, setVolume] = useState(85);
  const [isMuted, setIsMuted] = useState(false);
  const [voiceDropdownOpen, setVoiceDropdownOpen] = useState(false);
  const [progress, setProgress] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Animate progress bar during playback
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress(prev => (prev >= 100 ? 0 : prev + 2 * playbackRate));
      }, 100);
    } else {
      if (progress >= 100) setProgress(0);
    }
    return () => clearInterval(interval);
  }, [isPlaying, playbackRate, progress]);

  // Dynamic canvas waveform renderer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let phase = 0;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const isActive = isPlaying || isListening;
      const numBars = 36;
      const barWidth = width / numBars - 2;

      for (let i = 0; i < numBars; i++) {
        const x = i * (barWidth + 2);
        let barHeight = 4;

        if (isActive) {
          // Dynamic frequency calculation
          const wave1 = Math.sin(phase + i * 0.35);
          const wave2 = Math.cos(phase * 1.5 + i * 0.2);
          const amplitude = Math.abs(wave1 * wave2);
          barHeight = Math.max(4, amplitude * (height * 0.75));
        }

        const y = (height - barHeight) / 2;

        // Gradient color for bars
        const gradient = ctx.createLinearGradient(0, y, 0, y + barHeight);
        if (isListening) {
          gradient.addColorStop(0, '#f43f5e');
          gradient.addColorStop(1, '#fb7185');
        } else if (isPlaying) {
          gradient.addColorStop(0, '#38bdf8');
          gradient.addColorStop(0.5, '#818cf8');
          gradient.addColorStop(1, '#c084fc');
        } else {
          gradient.addColorStop(0, '#334155');
          gradient.addColorStop(1, '#1e293b');
        }

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, barHeight, 2);
        ctx.fill();
      }

      phase += isActive ? 0.08 * playbackRate : 0.01;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, isListening, playbackRate]);

  return (
    <div className="bg-[#11131c] border border-[#2c3142] rounded-xl shadow-2xl p-3.5 font-mono text-xs text-gray-200">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#222635]">
        <div className="flex items-center gap-2">
          {isListening ? (
            <div className="flex items-center gap-1.5 text-rose-400 font-semibold text-[11px]">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              <Mic className="w-3.5 h-3.5" />
              <span>Voice Input Listening...</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-cyan-400 font-semibold text-[11px]">
              <Activity className="w-3.5 h-3.5" />
              <span>{title}</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-1">
          {onClose && (
            <button
              onClick={onClose}
              className="p-1 rounded text-gray-400 hover:text-white hover:bg-[#222635] transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Dynamic Waveform Visualizer Canvas */}
      <div className="relative bg-[#090b10] border border-[#1e2230] rounded-lg p-2.5 mb-3 flex items-center justify-center overflow-hidden">
        <canvas
          ref={canvasRef}
          width={320}
          height={48}
          className="w-full h-12 block"
        />

        {/* Floating status pill */}
        <div className="absolute top-1.5 right-2 text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#181a25]/90 border border-[#2c3142] text-gray-400">
          {isPlaying ? `${playbackRate}x • Playing` : isListening ? 'Listening' : 'Idle'}
        </div>
      </div>

      {/* Progress scrubber */}
      <div className="w-full bg-[#181a25] h-1.5 rounded-full overflow-hidden mb-3">
        <div
          className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-100 ease-linear rounded-full"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Control Actions & Settings */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        {/* Play/Pause & Replay */}
        <div className="flex items-center gap-1.5">
          {onTogglePlay && (
            <button
              onClick={onTogglePlay}
              className="p-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white shadow-md transition-colors"
              title={isPlaying ? 'Pause Speech' : 'Play Speech'}
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>
          )}

          {onStop && (
            <button
              onClick={onStop}
              className="p-2 rounded-lg bg-[#181a25] hover:bg-[#222635] text-gray-300 border border-[#2c3142] transition-colors"
              title="Reset Audio"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Voice Selector */}
          {onSelectVoice && (
            <div className="relative">
              <button
                onClick={() => setVoiceDropdownOpen(!voiceDropdownOpen)}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#181a25] hover:bg-[#222635] text-gray-300 border border-[#2c3142] text-[10px] transition-colors"
              >
                <span>Voice: <strong className="text-cyan-400">{selectedVoice}</strong></span>
                <ChevronDown className="w-3 h-3 text-gray-400" />
              </button>

              {voiceDropdownOpen && (
                <div className="absolute left-0 bottom-8 w-56 bg-[#181a25] border border-[#2c3142] rounded-lg shadow-2xl p-1 z-50 animate-in fade-in zoom-in-95">
                  {VOICES.map(v => (
                    <button
                      key={v.name}
                      onClick={() => {
                        onSelectVoice(v.name);
                        setVoiceDropdownOpen(false);
                      }}
                      className={`w-full text-left px-2.5 py-1.5 rounded text-[11px] flex flex-col hover:bg-[#222635] ${
                        selectedVoice === v.name ? 'text-cyan-400 bg-[#222635]/60 font-semibold' : 'text-gray-300'
                      }`}
                    >
                      <span>{v.label}</span>
                      <span className="text-[9px] text-gray-500 font-sans">{v.desc}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Speed Multiplier Pills */}
        {onSelectRate && (
          <div className="flex items-center bg-[#181a25] border border-[#2c3142] rounded-md p-0.5 text-[9px]">
            {RATES.map(r => (
              <button
                key={r}
                onClick={() => onSelectRate(r)}
                className={`px-1.5 py-0.5 rounded transition-colors ${
                  playbackRate === r
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                {r}x
              </button>
            ))}
          </div>
        )}

        {/* Volume slider */}
        <div className="flex items-center gap-1.5 text-gray-400 text-[10px]">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="hover:text-gray-200"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted || volume === 0 ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-cyan-400" />}
          </button>
          <input
            type="range"
            min="0"
            max="100"
            value={isMuted ? 0 : volume}
            onChange={(e) => {
              setVolume(Number(e.target.value));
              if (isMuted) setIsMuted(false);
            }}
            className="w-14 h-1 bg-[#222635] accent-cyan-400 rounded cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
