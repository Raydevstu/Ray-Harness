import React, { useState } from 'react';
import { X, Share2, Copy, Check, ExternalLink } from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  if (!isOpen) return null;

  const shareUrl = window.location.href;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 font-mono text-xs">
      <div className="w-full max-w-md bg-[#11131c] border border-[#2c3142] rounded-xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95">
        
        <div className="flex items-center justify-between px-4 py-3 bg-[#181a25] border-b border-[#222635]">
          <div className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-blue-400" />
            <h2 className="font-bold text-gray-100 text-sm">SHARE CODEX WORKSPACE</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-[#222635] text-gray-400 hover:text-white rounded">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <p className="text-gray-300 text-xs leading-relaxed">
            Anyone with this URL can view the current Codex execution stream, configuration buffers, and workspace project files.
          </p>

          <div className="flex items-center gap-2 bg-[#181a25] border border-[#2c3142] rounded-md p-2">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className="bg-transparent text-gray-300 text-xs flex-1 outline-none truncate select-all"
            />
            <button
              onClick={handleCopy}
              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-[11px] font-semibold flex items-center gap-1 shrink-0"
            >
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        <div className="px-4 py-3 bg-[#181a25] border-t border-[#222635] flex justify-end">
          <button onClick={onClose} className="px-3 py-1 bg-[#222635] hover:bg-[#2c3142] text-gray-200 rounded">
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
