import React, { useState, useMemo, useEffect } from 'react';
import {
  X,
  Search,
  ChevronDown,
  Copy,
  Check,
  Plus,
  Code2,
  FileText,
  Settings,
  Play,
  GitCompare,
  Columns,
  AlignJustify,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Wrench,
  Cloud,
  Eye,
  Sparkles,
  ShieldCheck,
  Ban,
  ArrowRight,
  Activity,
} from 'lucide-react';
import { DiffEditor } from '@monaco-editor/react';
import { FileItem, TabItem, FilePatch, FilePatchSet, TimelineEvent } from '../types';
import { DocumentPreviewer } from './DocumentPreviewer';
import { TelemetryTimeline } from './TelemetryTimeline';
import { DriveFileItem } from '../services/GoogleDriveService';
import { validateTomlConfig, generateCanonicalToml, ValidationResult } from '../utils/tomlValidator';
import { computeDiffStats, validatePatchSet } from '../utils/patchParser';
import {
  CONFIG_TOML_CONTENT,
  PLAN_MD_CONTENT,
  DEFAULT_MD_CONTENT,
  COLLABORATOR_MD_CONTENT,
  RENDER_RS_CONTENT,
  LIB_RS_CONTENT,
  APPLY_COMMAND_RS_CONTENT,
  CONFIG_SCHEMA_JSON_CONTENT,
} from '../data/mockFiles';

interface RightInspectorProps {
  isOpen: boolean;
  onClose: () => void;
  files: FileItem[];
  tabs: TabItem[];
  activeTabId: string;
  onSelectTab: (id: string) => void;
  onCloseTab: (id: string) => void;
  onNewTab: () => void;
  onOpenFile: (file: FileItem) => void;
  uiMode?: string;
  onRunTest?: () => void;
  selectedDriveFile?: DriveFileItem | null;
  onUpdateTabContent?: (tabId: string, newContent: string) => void;
  activeReviewPatch?: FilePatch | null;
  activeReviewPatchSet?: FilePatchSet | null;
  onApprovePatch?: (patchId: string) => void;
  onRejectPatch?: (patchId: string) => void;
  onApprovePatchSet?: (patchSetId: string) => void;
  onRejectPatchSet?: (patchSetId: string) => void;
  onCancelReview?: () => void;
  onCancelPatchSetReview?: () => void;
  timelineEvents?: TimelineEvent[];
  onClearTimelineEvents?: () => void;
  onOpenPatchReview?: (patch: FilePatch) => void;
  onOpenPatchSetReview?: (patchSet: FilePatchSet) => void;
  onFocusTerminal?: () => void;
}

export const RightInspector: React.FC<RightInspectorProps> = ({
  isOpen,
  onClose,
  files,
  tabs,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onNewTab,
  onOpenFile,
  uiMode = 'plan',
  onRunTest,
  selectedDriveFile,
  onUpdateTabContent,
  activeReviewPatch,
  activeReviewPatchSet,
  onApprovePatch,
  onRejectPatch,
  onApprovePatchSet,
  onRejectPatchSet,
  onCancelReview,
  onCancelPatchSetReview,
  timelineEvents = [],
  onClearTimelineEvents,
  onOpenPatchReview,
  onOpenPatchSetReview,
  onFocusTerminal,
}) => {
  const [inspectorView, setInspectorView] = useState<'editor' | 'diff' | 'doc' | 'timeline'>('editor');
  const [diffSideBySide, setDiffSideBySide] = useState(true);
  const [filterQuery, setFilterQuery] = useState('');
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [selectedPatchSetIndex, setSelectedPatchSetIndex] = useState(0);

  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    config_dir: true,
    core_dir: true,
    templates_dir: true,
    agents_dir: true,
    src_dir: true,
    vscode_dir: false,
    amr: true,
  });
  const [copiedBreadcrumb, setCopiedBreadcrumb] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  // Automatically switch to diff view when an activeReviewPatch or activeReviewPatchSet is set
  useEffect(() => {
    if (activeReviewPatchSet) {
      setInspectorView('diff');
      setSelectedPatchSetIndex(0);
    } else if (activeReviewPatch) {
      setInspectorView('diff');
    }
  }, [activeReviewPatch, activeReviewPatchSet]);

  // Switch to doc view if a drive file was specifically clicked
  useEffect(() => {
    if (selectedDriveFile) {
      setInspectorView('doc');
    }
  }, [selectedDriveFile]);

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];
  const lines = (activeTab?.content || '').split('\n');
  const isToml = Boolean(activeTab?.name.endsWith('.toml'));

  // Live TOML Schema & AST Validation
  const tomlValidation: ValidationResult | null = useMemo(() => {
    if (!isToml || !activeTab?.content) return null;
    return validateTomlConfig(activeTab.content);
  }, [isToml, activeTab?.content]);

  // Selected patch set item for multi-file review
  const selectedPatchSetItem = useMemo(() => {
    if (activeReviewPatchSet && activeReviewPatchSet.patches.length > 0) {
      const idx = Math.min(selectedPatchSetIndex, activeReviewPatchSet.patches.length - 1);
      return activeReviewPatchSet.patches[idx];
    }
    return null;
  }, [activeReviewPatchSet, selectedPatchSetIndex]);

  // Patch set validation against current tabs and files
  const patchSetValidation = useMemo(() => {
    if (!activeReviewPatchSet) return { valid: true };
    return validatePatchSet(activeReviewPatchSet, tabs, files);
  }, [activeReviewPatchSet, tabs, files]);

  // Total addition and deletion stats for patch set
  const patchSetTotalStats = useMemo(() => {
    if (!activeReviewPatchSet) return { additions: 0, deletions: 0 };
    let additions = 0;
    let deletions = 0;
    for (const p of activeReviewPatchSet.patches) {
      const s = computeDiffStats(p.originalContent, p.proposedContent);
      additions += s.additions;
      deletions += s.deletions;
    }
    return { additions, deletions };
  }, [activeReviewPatchSet]);

  // Baseline original template content for comparison (or active patch / patch set original content)
  const originalBaselineContent = useMemo(() => {
    if (selectedPatchSetItem) {
      return selectedPatchSetItem.originalContent;
    }
    if (activeReviewPatch) {
      return activeReviewPatch.originalContent;
    }
    if (!activeTab) return '';
    const name = activeTab.name.toLowerCase();
    if (name === 'config.toml') return CONFIG_TOML_CONTENT;
    if (name === 'plan.md') return PLAN_MD_CONTENT;
    if (name === 'default.md') return DEFAULT_MD_CONTENT;
    if (name === 'collaborator.md' || name === 'collaboration.md') return COLLABORATOR_MD_CONTENT;
    if (name === 'render.rs') return RENDER_RS_CONTENT;
    if (name === 'lib.rs') return LIB_RS_CONTENT;
    if (name === 'apply_command.rs') return APPLY_COMMAND_RS_CONTENT;
    if (name === 'config.schema.json') return CONFIG_SCHEMA_JSON_CONTENT;

    return `// Original base version of ${activeTab.name}\n${activeTab.content}\n`;
  }, [activeTab, activeReviewPatch, selectedPatchSetItem]);

  // Modified content for diff view (either selectedPatchSetItem, activeReviewPatch.proposedContent, or activeTab.content)
  const modifiedDiffContent = useMemo(() => {
    if (selectedPatchSetItem) {
      return selectedPatchSetItem.proposedContent;
    }
    if (activeReviewPatch) {
      return activeReviewPatch.proposedContent;
    }
    return activeTab?.content || '';
  }, [activeTab?.content, activeReviewPatch, selectedPatchSetItem]);

  const monacoLanguage = useMemo(() => {
    const targetPath = selectedPatchSetItem?.path || activeReviewPatch?.path || activeTab?.path || '';
    const ext = targetPath.split('.').pop()?.toLowerCase();

    if (ext === 'rs') return 'rust';
    if (ext === 'toml') return 'ini';
    if (ext === 'json') return 'json';
    if (ext === 'md') return 'markdown';
    if (ext === 'ts' || ext === 'tsx') return 'typescript';

    switch (activeTab?.language) {
      case 'rust':
        return 'rust';
      case 'toml':
        return 'ini';
      case 'json':
        return 'json';
      case 'markdown':
        return 'markdown';
      case 'typescript':
      case 'tsx':
        return 'typescript';
      default:
        return 'plaintext';
    }
  }, [activeTab?.language, activeTab?.path, activeReviewPatch, selectedPatchSetItem]);

  // Check if buffer has changed relative to the patch's original content
  const isBufferStaleWarning = useMemo(() => {
    if (!activeReviewPatch || !activeTab) return false;
    if (activeTab.path === activeReviewPatch.path) {
      return activeTab.content !== activeReviewPatch.originalContent;
    }
    return false;
  }, [activeReviewPatch, activeTab]);

  if (!isOpen) return null;

  const toggleFolder = (folderId: string) => {
    setExpandedFolders(prev => ({ ...prev, [folderId]: !prev[folderId] }));
  };

  const handleCopyBreadcrumb = () => {
    if (activeTab?.path) {
      navigator.clipboard.writeText(activeTab.path);
      setCopiedBreadcrumb(true);
      setTimeout(() => setCopiedBreadcrumb(false), 2000);
    }
  };

  const handleFixToml = () => {
    if (onUpdateTabContent && activeTab) {
      const fixed = generateCanonicalToml();
      onUpdateTabContent(activeTab.id, fixed);
      setShowDiagnostics(false);
    }
  };

  const handleExecuteEngineTest = () => {
    setTestResult('Running render_layout test suite...');
    setTimeout(() => {
      setTestResult('PASS: test_default_mode_rendering (1.2ms) | PASS: test_apps_strip_when_disabled (0.8ms)');
      if (onRunTest) onRunTest();
    }, 450);
  };

  // Filter files
  const filteredFiles = files.filter(f =>
    f.name.toLowerCase().includes(filterQuery.toLowerCase()) ||
    (f.children && f.children.some(c => c.name.toLowerCase().includes(filterQuery.toLowerCase())))
  );

  const breadcrumbParts = activeTab?.path ? activeTab.path.split('/') : ['jarvis-app', 'config', 'config.toml'];

  const getLanguageBadge = (lang?: string) => {
    switch (lang) {
      case 'toml':
        return <span className="text-orange-400 font-bold text-[10px]">TOML</span>;
      case 'rust':
        return <span className="text-red-400 font-bold text-[10px]">RS</span>;
      case 'markdown':
        return <span className="text-sky-400 font-bold text-[10px]">MD</span>;
      case 'json':
      default:
        return <span className="text-yellow-400 font-bold text-[10px]">{'{ }'}</span>;
    }
  };

  return (
    <aside className="w-[450px] lg:w-[500px] shrink-0 bg-[#11131c] border-l border-[#222635] flex flex-col font-mono text-xs select-none z-20">
      
      {/* Tab Navigation Strip */}
      <div className="flex items-center bg-[#11131c] border-b border-[#222635] text-xs overflow-x-auto scrollbar-none">
        {/* New tab button */}
        <button
          onClick={onNewTab}
          className="px-3 py-2 border-r border-[#222635] text-gray-500 hover:text-gray-300 hover:bg-[#181a25] transition-colors cursor-pointer shrink-0"
        >
          New tab
        </button>

        {/* Opened Tabs */}
        {tabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          return (
            <div
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`px-3 py-2 border-r border-[#222635] flex items-center gap-2 cursor-pointer transition-colors shrink-0 ${
                isActive
                  ? 'bg-[#181a25] text-gray-200 font-medium'
                  : 'text-gray-500 hover:text-gray-300 hover:bg-[#141721]'
              }`}
            >
              {getLanguageBadge(tab.language)}
              <span className="truncate max-w-[120px]">{tab.name}</span>
              {tabs.length > 1 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onCloseTab(tab.id);
                  }}
                  className="p-0.5 hover:bg-[#222635] hover:text-red-400 rounded text-gray-500 transition-colors"
                  title="Close tab"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          );
        })}

        {/* Plus tab */}
        <button
          onClick={onNewTab}
          className="px-2.5 py-2 border-r border-[#222635] text-gray-500 hover:text-gray-300 hover:bg-[#181a25] transition-colors cursor-pointer shrink-0"
          title="Add Tab"
        >
          <Plus className="w-3 h-3" />
        </button>

        {/* Engine Test trigger */}
        <button
          onClick={handleExecuteEngineTest}
          className="ml-auto px-2.5 py-1.5 my-1 mr-2 rounded bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 hover:text-blue-300 border border-blue-500/30 flex items-center gap-1.5 text-[10px] font-semibold transition-colors"
          title="Run Rust Engine Test (render_layout & sanitize)"
        >
          <Play className="w-2.5 h-2.5 fill-current" />
          <span>Cargo Test</span>
        </button>
      </div>

      {/* Context Breadcrumb & View Mode Switcher */}
      <div className="flex items-center justify-between p-2 border-b border-[#222635] bg-[#141721] text-xs">
        <div className="text-gray-400 flex items-center gap-1.5 truncate text-[11px] min-w-0">
          {breadcrumbParts.map((part, idx) => (
            <React.Fragment key={idx}>
              <span
                className={`${
                  idx === breadcrumbParts.length - 1
                    ? 'text-gray-200 font-medium'
                    : 'hover:text-blue-400 cursor-pointer'
                }`}
              >
                {part}
              </span>
              {idx < breadcrumbParts.length - 1 && (
                <span className="text-gray-600 font-bold">&gt;</span>
              )}
            </React.Fragment>
          ))}
        </div>

        {/* View Mode Switcher & Tools */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* TOML Schema Validator Badge */}
          {isToml && tomlValidation && (
            <button
              onClick={() => setShowDiagnostics(!showDiagnostics)}
              className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded transition-colors ${
                tomlValidation.isValid
                  ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 hover:bg-emerald-900/40'
                  : 'text-amber-400 bg-amber-950/70 border border-amber-800/50 hover:bg-amber-900/50 animate-pulse'
              }`}
              title="Click to inspect config.schema.json validation"
            >
              {tomlValidation.isValid ? (
                <>
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span className="hidden sm:inline">Schema Valid</span>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  <span>{tomlValidation.errorCount + tomlValidation.warningCount} Issues</span>
                </>
              )}
            </button>
          )}

          <div className="flex items-center bg-[#181a25] border border-[#2c3142] rounded p-0.5 text-[10px]">
            <button
              onClick={() => setInspectorView('editor')}
              className={`px-2 py-0.5 rounded flex items-center gap-1 transition-colors ${
                inspectorView === 'editor'
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
              title="Standard Code Buffer View"
            >
              <Code2 className="w-3 h-3" />
              <span>Code</span>
            </button>
            <button
              onClick={() => setInspectorView('diff')}
              className={`px-2 py-0.5 rounded flex items-center gap-1 transition-colors ${
                inspectorView === 'diff'
                  ? 'bg-purple-600 text-white font-semibold'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
              title="Monaco Side-by-Side Diff View"
            >
              <GitCompare className="w-3 h-3" />
              <span>Diff</span>
            </button>
            <button
              onClick={() => setInspectorView('doc')}
              className={`px-2 py-0.5 rounded flex items-center gap-1 transition-colors ${
                inspectorView === 'doc'
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
              title="Google Drive & Document Previewer"
            >
              <Cloud className="w-3 h-3" />
              <span>Doc</span>
            </button>
            <button
              onClick={() => setInspectorView('timeline')}
              className={`px-2 py-0.5 rounded flex items-center gap-1 transition-colors ${
                inspectorView === 'timeline'
                  ? 'bg-amber-600 text-white font-semibold'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
              title="Execution Event Timeline & Telemetry Inspector"
            >
              <Activity className="w-3 h-3" />
              <span>Timeline</span>
              {timelineEvents.length > 0 && (
                <span className="text-[9px] px-1 py-0.2 rounded-full bg-black/40 font-mono">
                  {timelineEvents.length}
                </span>
              )}
            </button>
          </div>

          {/* If in Diff mode, allow toggle side-by-side vs inline */}
          {inspectorView === 'diff' && (
            <button
              onClick={() => setDiffSideBySide(!diffSideBySide)}
              className="p-1 text-gray-400 hover:text-white hover:bg-[#222635] rounded transition-colors"
              title={diffSideBySide ? 'Switch to Inline Diff' : 'Switch to Side-by-Side Diff'}
            >
              {diffSideBySide ? <Columns className="w-3 h-3 text-purple-400" /> : <AlignJustify className="w-3 h-3 text-purple-400" />}
            </button>
          )}

          <button
            onClick={handleCopyBreadcrumb}
            className="p-1 hover:bg-[#222635] text-gray-500 hover:text-gray-300 rounded transition-colors"
            title="Copy file path"
          >
            {copiedBreadcrumb ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* Diagnostics Drawer for TOML Schema Validation */}
      {showDiagnostics && tomlValidation && (
        <div className="bg-[#141721] border-b border-[#222635] p-3 text-xs flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 font-semibold text-gray-200 text-[11px]">
              <Settings className="w-3.5 h-3.5 text-blue-400" />
              <span>TOML Schema Diagnostics (config.schema.json)</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleFixToml}
                className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-semibold flex items-center gap-1 transition-colors"
                title="Reset to canonical valid config.toml"
              >
                <Wrench className="w-3 h-3" />
                <span>Auto-Fix TOML</span>
              </button>
              <button
                onClick={() => setShowDiagnostics(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
            {tomlValidation.diagnostics.length === 0 ? (
              <div className="text-emerald-400 text-[11px] flex items-center gap-1.5 py-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>All keys, array preserving rules, and enums conform 100% to schema.</span>
              </div>
            ) : (
              tomlValidation.diagnostics.map((diag) => (
                <div
                  key={diag.id}
                  className={`p-2 rounded border text-[11px] flex flex-col gap-0.5 ${
                    diag.severity === 'error'
                      ? 'bg-rose-950/40 border-rose-800/40 text-rose-300'
                      : 'bg-amber-950/40 border-amber-800/40 text-amber-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Line {diag.line}: {diag.message}</span>
                    <span className="text-[9px] uppercase px-1 rounded bg-black/40">
                      {diag.severity}
                    </span>
                  </div>
                  {diag.suggestion && (
                    <span className="text-gray-400 text-[10px] font-mono">
                      Suggestion: <code className="text-gray-200">{diag.suggestion}</code>
                    </span>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Test result banner if triggered */}
      {testResult && (
        <div className="px-3 py-1.5 bg-emerald-950/40 border-b border-emerald-800/40 text-[10px] text-emerald-300 flex items-center justify-between">
          <span className="truncate">{testResult}</span>
          <button onClick={() => setTestResult(null)} className="text-gray-400 hover:text-white ml-2">
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Diff Mode Header Notice or Active Staged Patch Review Banner */}
      {inspectorView === 'diff' && (
        <div className={`px-3 py-2 border-b flex flex-col gap-2 ${
          activeReviewPatchSet
            ? 'bg-gradient-to-r from-cyan-950/50 via-[#181a25] to-purple-950/50 border-cyan-500/40 text-cyan-200'
            : activeReviewPatch
            ? 'bg-gradient-to-r from-amber-950/40 via-[#181a25] to-purple-950/40 border-amber-500/30 text-amber-200'
            : 'bg-purple-950/30 border-purple-900/30 text-purple-300'
        }`}>
          {/* Active Patch Set Banner */}
          {activeReviewPatchSet ? (
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-cyan-400" />
                  <span className="font-semibold text-white text-xs">Reviewing Multi-File Patch Set:</span>
                  <span className="text-[10px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded font-semibold">
                    {activeReviewPatchSet.patches.length} Files
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono font-semibold">
                    +{patchSetTotalStats.additions}
                  </span>
                  <span className="text-[10px] text-rose-400 font-mono font-semibold">
                    -{patchSetTotalStats.deletions}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {onApprovePatchSet && (
                    <button
                      onClick={() => onApprovePatchSet(activeReviewPatchSet.patchSetId)}
                      disabled={!patchSetValidation.valid}
                      className={`px-2.5 py-1 rounded text-white font-semibold text-[10px] flex items-center gap-1 shadow-sm transition-colors ${
                        patchSetValidation.valid
                          ? 'bg-emerald-600 hover:bg-emerald-500 cursor-pointer'
                          : 'bg-gray-700 text-gray-400 cursor-not-allowed opacity-50'
                      }`}
                      title={
                        patchSetValidation.valid
                          ? 'Approve all changes and commit atomically'
                          : patchSetValidation.error || 'Blocked due to validation error'
                      }
                    >
                      <Check className="w-3 h-3" />
                      <span>Approve Entire Set</span>
                    </button>
                  )}
                  {onRejectPatchSet && (
                    <button
                      onClick={() => onRejectPatchSet(activeReviewPatchSet.patchSetId)}
                      className="px-2.5 py-1 rounded bg-rose-600/80 hover:bg-rose-500 text-white font-semibold text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
                      title="Reject patch set without modifying files"
                    >
                      <Ban className="w-3 h-3" />
                      <span>Reject Entire Set</span>
                    </button>
                  )}
                  {onCancelPatchSetReview && (
                    <button
                      onClick={onCancelPatchSetReview}
                      className="px-2 py-1 rounded bg-[#222635] hover:bg-[#2c3142] text-gray-300 text-[10px] transition-colors cursor-pointer"
                      title="Close diff review"
                    >
                      <span>Cancel</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="text-[11px] text-gray-300 pl-6">
                {activeReviewPatchSet.description}
              </div>

              {/* Affected Paths Navigation Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto py-1 pl-6">
                <span className="text-[10px] text-gray-400 font-semibold mr-1">File Diffs:</span>
                {activeReviewPatchSet.patches.map((p, idx) => {
                  const stats = computeDiffStats(p.originalContent, p.proposedContent);
                  const isSelected = selectedPatchSetIndex === idx;
                  return (
                    <button
                      key={p.patchId}
                      onClick={() => setSelectedPatchSetIndex(idx)}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono flex items-center gap-1 transition-colors border cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-900/60 text-cyan-200 border-cyan-500 shadow-sm font-semibold'
                          : 'bg-black/40 text-gray-400 border-gray-800 hover:text-gray-200'
                      }`}
                    >
                      <span>{p.path}</span>
                      <span className="text-[9px] text-emerald-400 font-mono">+{stats.additions}</span>
                      <span className="text-[9px] text-rose-400 font-mono">-{stats.deletions}</span>
                    </button>
                  );
                })}
              </div>

              {/* Stale / Validation Error Warning Banner */}
              {!patchSetValidation.valid && (
                <div className="flex items-center gap-1.5 text-amber-300 text-[10px] bg-amber-950/80 px-2.5 py-1 rounded border border-amber-600/50 ml-6">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                  <span>
                    <strong>Patch Set Blocked:</strong> {patchSetValidation.error}
                  </span>
                </div>
              )}
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <GitCompare className="w-3.5 h-3.5 text-purple-400" />
                  {activeReviewPatch ? (
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white text-xs">Reviewing Agent Patch:</span>
                      <span className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-black/50 text-cyan-300 border border-cyan-800/40">
                        {activeReviewPatch.path}
                      </span>
                      <span className="text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded font-semibold uppercase tracking-wider">
                        Pending Approval
                      </span>
                    </div>
                  ) : (
                    <span className="text-[11px]">
                      Monaco Diff: <strong>Original Template</strong> (Left) vs <strong>Active Buffer</strong> (Right)
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[9px] bg-purple-900/50 px-1.5 py-0.5 rounded text-purple-200">
                    {diffSideBySide ? 'Side-by-Side' : 'Inline'}
                  </span>

                  {/* Review Actions for Staged Single Agent Patch */}
                  {activeReviewPatch && (
                    <div className="flex items-center gap-1.5 ml-2">
                      {onApprovePatch && (
                        <button
                          onClick={() => onApprovePatch(activeReviewPatch.patchId)}
                          className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[10px] flex items-center gap-1 shadow-sm transition-colors cursor-pointer"
                          title="Approve changes and atomically update file buffer"
                        >
                          <Check className="w-3 h-3" />
                          <span>Approve Changes</span>
                        </button>
                      )}
                      {onRejectPatch && (
                        <button
                          onClick={() => onRejectPatch(activeReviewPatch.patchId)}
                          className="px-2.5 py-1 rounded bg-rose-600/80 hover:bg-rose-500 text-white font-semibold text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
                          title="Reject proposed changes without modifying files"
                        >
                          <Ban className="w-3 h-3" />
                          <span>Reject</span>
                        </button>
                      )}
                      {onCancelReview && (
                        <button
                          onClick={onCancelReview}
                          className="px-2 py-1 rounded bg-[#222635] hover:bg-[#2c3142] text-gray-300 text-[10px] transition-colors"
                          title="Close diff review and return to code buffer"
                        >
                          <span>Cancel</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Explanation & Buffer warnings */}
              {activeReviewPatch && (
                <div className="flex items-center justify-between text-[11px] text-gray-400 pl-5">
                  <span>{activeReviewPatch.explanation || 'Agent proposes the following code modification.'}</span>
                  {isBufferStaleWarning && (
                    <span className="flex items-center gap-1 text-amber-400 text-[10px] bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/50">
                      <AlertTriangle className="w-3 h-3" />
                      <span>Notice: Active tab buffer was edited since patch creation</span>
                    </span>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* Split Pane: Code & Explorer */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Sub-pane A: TelemetryTimeline OR DocumentPreviewer OR Monaco DiffEditor OR Code Viewer */}
        {inspectorView === 'timeline' ? (
          <TelemetryTimeline
            events={timelineEvents}
            onClearEvents={onClearTimelineEvents}
            onOpenFile={onOpenFile}
            onOpenPatchReview={onOpenPatchReview}
            onFocusTerminal={onFocusTerminal}
            files={files}
          />
        ) : inspectorView === 'doc' ? (
          <DocumentPreviewer
            file={selectedDriveFile || null}
            onSwitchToCodeMode={() => setInspectorView('editor')}
          />
        ) : inspectorView === 'diff' ? (
          <div className="flex-1 overflow-hidden bg-[#0d0f17] flex flex-col">
            <DiffEditor
              original={originalBaselineContent}
              modified={modifiedDiffContent}
              language={monacoLanguage}
              theme="vs-dark"
              options={{
                renderSideBySide: diffSideBySide,
                readOnly: true,
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                fontSize: 11.5,
                fontFamily: 'JetBrains Mono, Menlo, Monaco, "Courier New", monospace',
                automaticLayout: true,
                wordWrap: 'on',
              }}
              height="100%"
            />
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto bg-[#0d0f17] p-2.5 font-mono text-xs leading-6 flex select-text scrollbar-thin scrollbar-thumb-[#222635]">
            {/* Line Numbers */}
            <div className="text-gray-600 text-right pr-3.5 select-none flex flex-col font-mono text-[11px] border-r border-[#222635]/60 mr-3">
              {lines.map((_, i) => (
                <span key={i} className="min-w-[20px]">{i + 1}</span>
              ))}
            </div>

            {/* Syntax-colored code buffer */}
            <div className="text-gray-300 whitespace-pre overflow-x-auto flex-1 text-[11.5px] leading-6 font-mono">
              {lines.map((line, idx) => {
                // Highlight TOML headers [feature_flags], [agents], etc.
                if (line.trim().startsWith('[') && line.trim().endsWith(']')) {
                  return (
                    <div key={idx} className="text-purple-300 font-semibold">
                      {line}
                    </div>
                  );
                }
                // Highlight Rust keywords
                if (line.includes('pub struct ') || line.includes('pub fn ') || line.includes('impl ') || line.includes('match ')) {
                  return (
                    <div key={idx}>
                      <span className="text-amber-400">{line}</span>
                    </div>
                  );
                }
                // Highlight Markdown headings
                if (line.trim().startsWith('#')) {
                  return (
                    <div key={idx} className="text-cyan-300 font-bold">
                      {line}
                    </div>
                  );
                }
                // Highlight comments
                if (line.trim().startsWith('#') || line.trim().startsWith('//') || line.trim().startsWith('//!')) {
                  return (
                    <div key={idx} className="text-gray-500 italic">
                      {line}
                    </div>
                  );
                }
                // Highlight APPS tags
                if (line.includes('APPS_INSTRUCTIONS_OPEN_TAG')) {
                  return (
                    <div key={idx} className="text-emerald-400 font-mono">
                      {line}
                    </div>
                  );
                }
                // JSON key values
                if (line.includes('":')) {
                  const parts = line.split('":');
                  return (
                    <div key={idx}>
                      <span className="text-blue-300">{parts[0]}"</span>:
                      <span className="text-green-300">{parts.slice(1).join('":')}</span>
                    </div>
                  );
                }
                // TOML key-values
                if (line.includes(' = ')) {
                  const [k, ...v] = line.split(' = ');
                  return (
                    <div key={idx}>
                      <span className="text-blue-300">{k}</span> = <span className="text-green-300">{v.join(' = ')}</span>
                    </div>
                  );
                }
                return <div key={idx}>{line}</div>;
              })}
            </div>
          </div>
        )}

        {/* Sub-pane B: File Browser */}
        <div className="w-[190px] bg-[#11131c] border-l border-[#222635] flex flex-col shrink-0 overflow-hidden select-none">
          {/* Search Filter Header */}
          <div className="p-2 border-b border-[#222635]">
            <div className="flex items-center bg-[#181a25] border border-[#2c3142] rounded px-2 py-1 focus-within:border-blue-500/50">
              <Search className="w-3 h-3 text-gray-500 mr-1.5 shrink-0" />
              <input
                type="text"
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="Filter"
                className="bg-transparent text-xs outline-none w-full text-gray-200 placeholder-gray-500 font-mono"
              />
            </div>
          </div>

          {/* Directory & File Tree List */}
          <div className="flex-1 overflow-y-auto p-1.5 text-xs text-gray-400 space-y-0.5 scrollbar-thin scrollbar-thumb-[#222635]">
            {filteredFiles.map((item) => {
              const isDir = item.type === 'dir';
              const isExpanded = expandedFolders[item.id];
              const isCurrent = activeTab?.path === item.path;

              return (
                <div key={item.id} className="flex flex-col">
                  <div
                    onClick={() => {
                      if (isDir) {
                        toggleFolder(item.id);
                      } else {
                        onOpenFile(item);
                      }
                    }}
                    className={`flex items-center gap-1.5 py-1 px-1.5 rounded cursor-pointer transition-colors ${
                      isCurrent
                        ? 'text-gray-100 bg-[#222635] font-semibold'
                        : 'hover:bg-[#181a25] hover:text-gray-200'
                    }`}
                  >
                    {isDir ? (
                      <ChevronDown
                        className={`w-3 h-3 text-gray-500 shrink-0 transition-transform ${
                          isExpanded ? '' : '-rotate-90'
                        }`}
                      />
                    ) : (
                      getLanguageBadge(item.language)
                    )}
                    <span className="truncate">{item.name}</span>
                  </div>

                  {/* Render children if directory is expanded */}
                  {isDir && isExpanded && item.children && item.children.length > 0 && (
                    <div className="pl-3.5 flex flex-col space-y-0.5 border-l border-[#222635]/60 ml-2 my-0.5">
                      {item.children.map(child => {
                        const isChildDir = child.type === 'dir';
                        const isChildExpanded = expandedFolders[child.id];

                        return (
                          <div key={child.id} className="flex flex-col">
                            <div
                              onClick={() => {
                                if (isChildDir) {
                                  toggleFolder(child.id);
                                } else {
                                  onOpenFile(child);
                                }
                              }}
                              className={`flex items-center gap-1.5 py-0.5 px-1 rounded cursor-pointer transition-colors text-[11px] ${
                                activeTab?.path === child.path
                                  ? 'text-blue-300 bg-[#222635] font-medium'
                                  : 'text-gray-400 hover:text-gray-200 hover:bg-[#181a25]'
                              }`}
                            >
                              {isChildDir ? (
                                <ChevronDown
                                  className={`w-2.5 h-2.5 text-gray-500 shrink-0 transition-transform ${
                                    isChildExpanded ? '' : '-rotate-90'
                                  }`}
                                />
                              ) : (
                                getLanguageBadge(child.language)
                              )}
                              <span className="truncate">{child.name}</span>
                            </div>

                            {/* Second level nesting */}
                            {isChildDir && isChildExpanded && child.children && (
                              <div className="pl-3 flex flex-col space-y-0.5 border-l border-[#222635]/60 ml-1.5 my-0.5">
                                {child.children.map(subChild => (
                                  <div
                                    key={subChild.id}
                                    onClick={() => onOpenFile(subChild)}
                                    className={`flex items-center gap-1.5 py-0.5 px-1 rounded cursor-pointer transition-colors text-[10.5px] ${
                                      activeTab?.path === subChild.path
                                        ? 'text-blue-300 bg-[#222635] font-medium'
                                        : 'text-gray-400 hover:text-gray-200 hover:bg-[#181a25]'
                                    }`}
                                  >
                                    {getLanguageBadge(subChild.language)}
                                    <span className="truncate">{subChild.name}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </aside>
  );
};
