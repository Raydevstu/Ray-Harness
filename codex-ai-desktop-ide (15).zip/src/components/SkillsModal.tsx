import React, { useState } from 'react';
import { X, Sparkles, ShieldCheck, CheckCircle2, Lock, Unlock, Wrench, ShieldAlert } from 'lucide-react';
import { AgentSkill } from '../types';
import { INITIAL_SKILLS } from '../utils/skillRegistry';

interface SkillsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplySkill: (skillName: string) => void;
}

export const SkillsModal: React.FC<SkillsModalProps> = ({ isOpen, onClose, onApplySkill }) => {
  const [skills, setSkills] = useState<AgentSkill[]>(INITIAL_SKILLS);

  if (!isOpen) return null;

  const toggleStatus = (id: string) => {
    setSkills(prev =>
      prev.map(s =>
        s.id === id
          ? { ...s, status: s.status === 'approved' ? 'revoked' : 'approved' }
          : s
      )
    );
  };

  const getPermissionBadge = (perm: string, requiresApproval: boolean) => {
    if (requiresApproval) {
      return (
        <span className="text-[9px] px-1.5 py-0.5 rounded font-bold uppercase bg-amber-950/80 text-amber-300 border border-amber-800/60 flex items-center gap-1">
          <ShieldAlert className="w-2.5 h-2.5 text-amber-400" />
          <span>Approval Req</span>
        </span>
      );
    }
    return (
      <span className="text-[9px] px-1.5 py-0.5 rounded font-bold uppercase bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 flex items-center gap-1">
        <ShieldCheck className="w-2.5 h-2.5 text-emerald-400" />
        <span>{perm.replace('_', ' ')}</span>
      </span>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 font-mono text-xs select-text">
      <div className="w-full max-w-2xl bg-[#11131c] border border-[#2c3142] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#181a25] border-b border-[#222635]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h2 className="font-bold text-gray-100 text-sm tracking-wide">
              RAY HARNESS // ACTIVE AGENT SKILL REGISTRY
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#222635] rounded text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-3 gap-3 p-3 bg-[#141721] border-b border-[#222635] text-[11px]">
          <div className="bg-[#181a25] p-2 rounded border border-[#222635]">
            <span className="text-gray-500 block text-[10px]">TOTAL SKILLS</span>
            <span className="text-blue-400 font-bold text-sm">{skills.length}</span>
          </div>
          <div className="bg-[#181a25] p-2 rounded border border-[#222635]">
            <span className="text-gray-500 block text-[10px]">APPROVED</span>
            <span className="text-emerald-400 font-bold text-sm">
              {skills.filter(s => s.status === 'approved').length}
            </span>
          </div>
          <div className="bg-[#181a25] p-2 rounded border border-[#222635]">
            <span className="text-gray-500 block text-[10px]">TOTAL REGISTERED TOOLS</span>
            <span className="text-purple-400 font-bold text-sm">
              {skills.reduce((acc, s) => acc + s.tools.length, 0)}
            </span>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {skills.map((skill) => {
            const isApproved = skill.status === 'approved';
            return (
              <div
                key={skill.id}
                className={`p-3.5 rounded-lg border transition-all ${
                  isApproved
                    ? 'bg-[#181a25]/60 border-[#2c3142]'
                    : 'bg-rose-950/10 border-rose-900/30'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5 flex-wrap gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-gray-200 text-sm">{skill.name}</span>
                    <span className="text-[10px] text-gray-500">v{skill.version}</span>
                    {getPermissionBadge(skill.requiredPermission, skill.requiresApproval)}
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                        isApproved
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                          : 'bg-rose-950/60 text-rose-400 border border-rose-800/40'
                      }`}
                    >
                      {skill.status}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleStatus(skill.id)}
                      className="px-2 py-1 rounded bg-[#222635] hover:bg-[#2c3142] text-[10px] text-gray-300 transition-colors"
                    >
                      {isApproved ? 'Revoke Skill' : 'Approve Skill'}
                    </button>
                    <button
                      onClick={() => {
                        onApplySkill(`@skill:${skill.id}`);
                        onClose();
                      }}
                      className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-semibold transition-colors"
                    >
                      Inject Context
                    </button>
                  </div>
                </div>

                <p className="text-gray-400 text-[11px] leading-relaxed mb-2">
                  {skill.description}
                </p>

                <div className="space-y-1 bg-[#10121a] p-2 rounded border border-[#202538]">
                  <div className="text-[10px] text-gray-500 flex items-center justify-between mb-1">
                    <span className="font-semibold text-gray-400">Tools Provided ({skill.tools.length}):</span>
                    <span>Allowed Roles: <strong className="text-gray-300">{skill.allowedRoles.join(', ')}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {skill.tools.map(t => (
                      <span
                        key={t.id}
                        className="px-2 py-0.5 rounded bg-[#181a25] text-cyan-300 border border-cyan-900/50 text-[10px] flex items-center gap-1"
                        title={t.description}
                      >
                        <Wrench className="w-2.5 h-2.5 text-cyan-400" />
                        <span>{t.id}</span>
                        {t.isMutating && <span className="text-amber-400 text-[9px] font-bold">(Mutating)</span>}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#181a25] border-t border-[#222635] flex items-center justify-between text-gray-500 text-[11px]">
          <span>Skill tools execute with permission bounds and structured telemetry.</span>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-[#222635] hover:bg-[#2c3142] text-gray-200 rounded transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
