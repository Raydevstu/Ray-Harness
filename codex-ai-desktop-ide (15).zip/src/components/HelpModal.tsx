import React from 'react';
import { X, HelpCircle, Terminal, Keyboard, Cpu, Sparkles } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 font-mono text-xs">
      <div className="w-full max-w-xl bg-[#11131c] border border-[#2c3142] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#181a25] border-b border-[#222635]">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-blue-400" />
            <h2 className="font-bold text-gray-100 text-sm">
              CODEX / DEEPSEEK DESKTOP IDE GUIDE
            </h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-[#222635] text-gray-400 hover:text-white rounded">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 overflow-y-auto">
          <div>
            <h3 className="text-gray-200 font-semibold mb-1 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-purple-400" />
              <span>Deep Thinking & Gemini AI Engine</span>
            </h3>
            <p className="text-gray-400 text-xs leading-relaxed">
              When complex architectural or coding queries are submitted, toggle <strong>Thinking Mode</strong> to engage <code>gemini-3.1-pro-preview</code> with <code>ThinkingLevel.HIGH</code>. Fast tasks run on <code>gemini-3.1-flash-lite</code> (5.6 Luna Light preset).
            </p>
          </div>

          <div>
            <h3 className="text-gray-200 font-semibold mb-1 flex items-center gap-1.5">
              <Keyboard className="w-3.5 h-3.5 text-blue-400" />
              <span>Keyboard Shortcuts</span>
            </h3>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-gray-400 mt-2">
              <div className="bg-[#181a25] p-2 rounded border border-[#222635]">
                <kbd className="text-gray-200 font-bold">Enter</kbd> : Send prompt
              </div>
              <div className="bg-[#181a25] p-2 rounded border border-[#222635]">
                <kbd className="text-gray-200 font-bold">Shift+Enter</kbd> : New line
              </div>
              <div className="bg-[#181a25] p-2 rounded border border-[#222635]">
                <kbd className="text-gray-200 font-bold">Ctrl+B</kbd> : Toggle sidebar
              </div>
              <div className="bg-[#181a25] p-2 rounded border border-[#222635]">
                <kbd className="text-gray-200 font-bold">Ctrl+J</kbd> : Toggle code editor
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-gray-200 font-semibold mb-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Gemini 3.1 Flash Text-To-Speech (TTS)</span>
            </h3>
            <p className="text-gray-400 text-xs leading-relaxed">
              Click the speaker icon in the prompt dock or beside any AI response to listen via <code>gemini-3.1-flash-tts-preview</code>.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#181a25] border-t border-[#222635] flex justify-between items-center text-[10px] text-gray-500">
          <span>Logged in as Hurera K (Pro Developer)</span>
          <button onClick={onClose} className="px-3 py-1 bg-[#222635] hover:bg-[#2c3142] text-gray-200 rounded">
            Got it
          </button>
        </div>

      </div>
    </div>
  );
};
