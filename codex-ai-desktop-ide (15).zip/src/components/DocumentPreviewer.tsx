import React, { useState } from 'react';
import {
  FileText,
  FileSpreadsheet,
  Presentation,
  FileCode,
  ExternalLink,
  Download,
  Copy,
  Check,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Cloud,
  Eye,
  Code2,
  Lock,
  Share2,
  Calendar,
  User,
  HardDrive,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { DriveFileItem } from '../services/GoogleDriveService';

interface DocumentPreviewerProps {
  file: DriveFileItem | null;
  onClose?: () => void;
  onSwitchToCodeMode?: () => void;
}

export const DocumentPreviewer: React.FC<DocumentPreviewerProps> = ({
  file,
  onClose,
  onSwitchToCodeMode,
}) => {
  const [zoomLevel, setZoomLevel] = useState(100);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [viewMode, setViewMode] = useState<'preview' | 'source'>('preview');
  const [copied, setCopied] = useState(false);
  const [iframeError, setIframeError] = useState(false);

  if (!file) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-gray-500 font-mono text-xs bg-[#0d0f17]">
        <Cloud className="w-10 h-10 text-gray-600 mb-3 animate-pulse" />
        <p className="text-gray-300 font-semibold mb-1">No Google Drive Document Selected</p>
        <p className="text-gray-500 max-w-sm text-[11px] leading-relaxed">
          Select any Google Doc, Sheet, Slide, or PDF from the Google Drive cloud tree in the left sidebar to preview live content.
        </p>
      </div>
    );
  }

  const handleCopyContent = () => {
    if (file.contentPreview) {
      navigator.clipboard.writeText(file.contentPreview);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getFileIcon = () => {
    switch (file.iconType) {
      case 'doc':
        return <FileText className="w-4 h-4 text-blue-400" />;
      case 'sheet':
        return <FileSpreadsheet className="w-4 h-4 text-emerald-400" />;
      case 'slide':
        return <Presentation className="w-4 h-4 text-amber-400" />;
      case 'pdf':
        return <FileText className="w-4 h-4 text-rose-400" />;
      default:
        return <FileCode className="w-4 h-4 text-cyan-400" />;
    }
  };

  const getBadgeColor = () => {
    switch (file.iconType) {
      case 'doc':
        return 'bg-blue-950/80 text-blue-300 border-blue-800/50';
      case 'sheet':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-800/50';
      case 'slide':
        return 'bg-amber-950/80 text-amber-300 border-amber-800/50';
      case 'pdf':
        return 'bg-rose-950/80 text-rose-300 border-rose-800/50';
      default:
        return 'bg-cyan-950/80 text-cyan-300 border-cyan-800/50';
    }
  };

  return (
    <div className={`flex-1 flex flex-col bg-[#0d0f17] font-mono text-xs overflow-hidden ${isFullscreen ? 'fixed inset-0 z-50 p-6 bg-[#0a0c13]' : ''}`}>
      {/* Document Header & Metadata Bar */}
      <div className="p-3 border-b border-[#222635] bg-[#11131c] flex flex-wrap items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <div className="p-1.5 rounded bg-[#181a25] border border-[#2c3142]">
            {getFileIcon()}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-gray-200 truncate max-w-md text-xs">{file.name}</span>
              <span className={`text-[9px] uppercase px-1.5 py-0.5 rounded border ${getBadgeColor()}`}>
                {file.iconType}
              </span>
              {file.isShared && (
                <span className="text-[9px] text-gray-400 flex items-center gap-0.5 bg-[#181a25] px-1.5 py-0.5 rounded border border-[#2c3142]">
                  <Share2 className="w-2.5 h-2.5 text-blue-400" /> Shared
                </span>
              )}
            </div>
            <div className="flex items-center gap-3 text-[10px] text-gray-500 mt-0.5">
              <span className="flex items-center gap-1">
                <User className="w-2.5 h-2.5 text-gray-400" /> {file.owner}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-2.5 h-2.5 text-gray-400" /> {file.modifiedTime}
              </span>
              {file.size && (
                <span className="flex items-center gap-1">
                  <HardDrive className="w-2.5 h-2.5 text-gray-400" /> {file.size}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5">
          {/* Mode switch: Preview vs Source */}
          <div className="flex items-center bg-[#181a25] border border-[#2c3142] rounded-md p-0.5 text-[10px]">
            <button
              onClick={() => setViewMode('preview')}
              className={`flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${
                viewMode === 'preview'
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Eye className="w-3 h-3" />
              <span>Preview</span>
            </button>
            <button
              onClick={() => setViewMode('source')}
              className={`flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${
                viewMode === 'source'
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Code2 className="w-3 h-3" />
              <span>Raw Text</span>
            </button>
          </div>

          {/* Zoom buttons */}
          <div className="flex items-center bg-[#181a25] border border-[#2c3142] rounded-md p-0.5 text-[10px]">
            <button
              onClick={() => setZoomLevel(prev => Math.max(prev - 15, 60))}
              className="p-1 text-gray-400 hover:text-white rounded"
              title="Zoom Out"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <span className="px-1.5 text-gray-300 font-mono text-[10px] min-w-[36px] text-center">
              {zoomLevel}%
            </span>
            <button
              onClick={() => setZoomLevel(prev => Math.min(prev + 15, 180))}
              className="p-1 text-gray-400 hover:text-white rounded"
              title="Zoom In"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
            <button
              onClick={() => setZoomLevel(100)}
              className="p-1 text-gray-400 hover:text-white rounded ml-0.5"
              title="Reset Zoom"
            >
              <RotateCcw className="w-2.5 h-2.5" />
            </button>
          </div>

          {/* Copy content button */}
          <button
            onClick={handleCopyContent}
            className="flex items-center gap-1 px-2 py-1 rounded bg-[#181a25] hover:bg-[#222635] text-gray-300 hover:text-white border border-[#2c3142] text-[10px] transition-colors"
            title="Copy Document Text"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-gray-400" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>

          {/* Open External in Google Drive / Workspace */}
          <a
            href={file.webViewLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 px-2 py-1 rounded bg-[#181a25] hover:bg-[#222635] text-blue-400 hover:text-blue-300 border border-blue-500/30 text-[10px] transition-colors"
            title="Open in Google Drive tab"
          >
            <ExternalLink className="w-3 h-3" />
            <span className="hidden sm:inline">Open in Drive</span>
          </a>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => setIsFullscreen(prev => !prev)}
            className="p-1.5 rounded bg-[#181a25] hover:bg-[#222635] text-gray-400 hover:text-white border border-[#2c3142] transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Preview'}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Document Content Canvas */}
      <div className="flex-1 overflow-auto p-4 flex justify-center items-start bg-[#0a0c13]/70 scrollbar-thin scrollbar-thumb-[#222635]">
        <div
          style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}
          className="transition-transform duration-150 ease-out w-full max-w-4xl"
        >
          {viewMode === 'preview' ? (
            <div className="bg-[#131622] border border-[#2c3142] rounded-xl shadow-2xl p-6 md:p-8 text-gray-200">
              {/* Document Header banner */}
              <div className="border-b border-[#222635] pb-4 mb-6 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
                  <span className="text-[11px] text-gray-400 font-semibold uppercase tracking-wider">
                    Google Drive Cloud Artifact
                  </span>
                </div>
                <span className="text-[10px] text-gray-500 font-mono">ID: {file.id}</span>
              </div>

              {/* Rendered Document Body */}
              <div className="prose prose-invert max-w-none text-xs leading-relaxed font-sans space-y-4 text-gray-300">
                <ReactMarkdown
                  components={{
                    h1: ({ children }) => <h1 className="text-lg font-bold text-white border-b border-[#222635] pb-2 font-mono">{children}</h1>,
                    h2: ({ children }) => <h2 className="text-base font-bold text-blue-300 mt-4 font-mono">{children}</h2>,
                    h3: ({ children }) => <h3 className="text-sm font-semibold text-purple-300 mt-3 font-mono">{children}</h3>,
                    p: ({ children }) => <p className="leading-relaxed text-gray-300 font-sans">{children}</p>,
                    ul: ({ children }) => <ul className="list-disc pl-5 space-y-1 font-sans">{children}</ul>,
                    li: ({ children }) => <li className="text-gray-300">{children}</li>,
                    code: ({ children }) => <code className="bg-[#181a25] text-amber-300 px-1 py-0.5 rounded font-mono text-[11px] border border-[#2c3142]">{children}</code>,
                  }}
                >
                  {file.contentPreview || '# Empty Document\nNo preview content available.'}
                </ReactMarkdown>
              </div>

              {/* Iframe fallback notice */}
              <div className="mt-8 pt-4 border-t border-[#222635] flex items-center justify-between text-[11px] text-gray-500">
                <div className="flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Authenticated via Google Identity Services (OAuth2 Bearer token)</span>
                </div>
                <a
                  href={file.webViewLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:underline flex items-center gap-1 text-[10px]"
                >
                  Edit in Google Docs <ExternalLink className="w-2.5 h-2.5" />
                </a>
              </div>
            </div>
          ) : (
            <div className="bg-[#11131c] border border-[#2c3142] rounded-xl p-4 shadow-xl">
              <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#222635] text-gray-400 text-[11px]">
                <span>Raw Character Stream ({file.contentPreview?.length || 0} bytes)</span>
                <button
                  onClick={handleCopyContent}
                  className="flex items-center gap-1 text-blue-400 hover:text-blue-300"
                >
                  {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy All'}</span>
                </button>
              </div>
              <pre className="text-gray-300 text-xs font-mono leading-relaxed whitespace-pre-wrap select-text">
                {file.contentPreview || '(No raw content)'}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
