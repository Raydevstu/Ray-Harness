import React, { useState, useEffect } from 'react';
import {
  Sidebar,
  Share,
  Layout,
  FileJson,
  Copy,
  ThumbsUp,
  ThumbsDown,
  Volume2,
  VolumeX,
  Check,
  Maximize2,
  Minimize2,
  BrainCircuit,
  Wrench,
  Loader2,
  RotateCw,
  Sparkles,
  GitBranch,
  Terminal,
  ShieldAlert,
  Layers,
  ChevronRight,
  Command,
  Eye,
  GitCompare,
  FileCode,
  CheckCircle2,
  Ban,
  ArrowRight,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Message, AgentInfo, AgentMessage, AgentRole, FilePatch, FilePatchSet, FileItem, TimelineEvent } from '../types';
import { AgentModeWorkspace } from './AgentModeWorkspace';
import { TemplateLivePreview } from './TemplateLivePreview';
import { InteractiveTerminal } from './InteractiveTerminal';
import { AgentStatusBar } from './AgentStatusBar';
import { INITIAL_AGENTS, INITIAL_AGENT_MESSAGES } from '../data/mockFiles';
import { extractPatchesFromMessage, computeDiffStats } from '../utils/patchParser';

interface CenterWorkspaceProps {
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  isInspectorOpen: boolean;
  onToggleInspector: () => void;
  onShare: () => void;
  onLayoutChange: () => void;
  messages: Message[];
  isStreaming: boolean;
  activeThought: string | null;
  onPlayTTS: (text: string) => void;
  isAudioPlaying: boolean;
  collaborationMode?: 'default' | 'plan' | 'agent';
  onSwitchMode?: (mode: 'default' | 'plan' | 'agent') => void;
  planningPhase?: string;
  planObjective?: string;
  activeAgent?: AgentRole;
  onSelectAgent?: (agent: AgentRole) => void;
  agents?: AgentInfo[];
  agentMessages?: AgentMessage[];
  onAddAgentMessage?: (msg: AgentMessage) => void;
  onApproveAgentMessage?: (id: string) => void;
  onOpenCommandPalette?: () => void;
  onOpenPatchReview?: (patch: FilePatch) => void;
  onApprovePatch?: (patchId: string) => void;
  onRejectPatch?: (patchId: string) => void;
  onOpenPatchSetReview?: (patchSet: FilePatchSet) => void;
  onApprovePatchSet?: (patchSetId: string) => void;
  onRejectPatchSet?: (patchSetId: string) => void;
  pendingPatchStatusMap?: Record<string, 'pending' | 'approved' | 'rejected'>;
  files?: FileItem[];
  onRecordTelemetry?: (
    event: Omit<TimelineEvent, 'id' | 'timestamp'> & { id?: string; timestamp?: string; createdAt?: number }
  ) => string;
  onRecordCommandEvent?: (event: {
    type: string;
    category: 'terminal';
    status: 'running' | 'completed' | 'failed';
    title: string;
    description?: string;
    commandSummary: string;
    durationMs?: number;
    error?: string;
    source?: 'terminal' | 'chat' | 'agent' | 'gemini' | 'system';
    metadata?: Record<string, unknown>;
  }) => void;
  isTerminalOpen?: boolean;
  onSetTerminalOpen?: (open: boolean) => void;
}

export const CenterWorkspace: React.FC<CenterWorkspaceProps> = ({
  isSidebarOpen,
  onToggleSidebar,
  isInspectorOpen,
  onToggleInspector,
  onShare,
  onLayoutChange,
  messages,
  isStreaming,
  activeThought,
  onPlayTTS,
  isAudioPlaying,
  collaborationMode = 'plan',
  onSwitchMode,
  planningPhase = 'PHASE 3: Implementation Spec',
  planObjective = 'Build identical Codex UI layout, functions, feature flags, and wiring config in Jarvis app',
  activeAgent = 'code_executor',
  onSelectAgent,
  agents = INITIAL_AGENTS,
  agentMessages = INITIAL_AGENT_MESSAGES,
  onAddAgentMessage,
  onApproveAgentMessage,
  onOpenCommandPalette,
  onOpenPatchReview,
  onApprovePatch,
  onRejectPatch,
  onOpenPatchSetReview,
  onApprovePatchSet,
  onRejectPatchSet,
  pendingPatchStatusMap = {},
  files = [],
  onRecordTelemetry,
  onRecordCommandEvent,
  isTerminalOpen: controlledTerminalOpen,
  onSetTerminalOpen,
}) => {
  const [copiedPreset, setCopiedPreset] = useState(false);
  const [presetExpanded, setPresetExpanded] = useState(false);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});
  const [dislikedMap, setDislikedMap] = useState<Record<string, boolean>>({});
  const [isLivePreviewOpen, setIsLivePreviewOpen] = useState(false);
  const [internalTerminalOpen, setInternalTerminalOpen] = useState(false);

  const isTerminalOpen = controlledTerminalOpen !== undefined ? controlledTerminalOpen : internalTerminalOpen;
  const setIsTerminalOpen = (open: boolean | ((prev: boolean) => boolean)) => {
    if (typeof open === 'function') {
      const nextVal = open(isTerminalOpen);
      if (onSetTerminalOpen) onSetTerminalOpen(nextVal);
      else setInternalTerminalOpen(nextVal);
    } else {
      if (onSetTerminalOpen) onSetTerminalOpen(open);
      else setInternalTerminalOpen(open);
    }
  };

  // Global shortcut: Ctrl+` to toggle in-browser terminal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === '`') {
        e.preventDefault();
        setIsTerminalOpen((prev: boolean) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isTerminalOpen]);

  const handleCopyPreset = () => {
    const text = `Standard preset\n+ Ollama\n+ model-aware context budget\n+ filesystem/search`;
    navigator.clipboard.writeText(text);
    setCopiedPreset(true);
    setTimeout(() => setCopiedPreset(false), 2000);
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(id);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const toggleLike = (id: string) => {
    setLikedMap(prev => ({ ...prev, [id]: !prev[id] }));
    if (dislikedMap[id]) {
      setDislikedMap(prev => ({ ...prev, [id]: false }));
    }
  };

  const toggleDislike = (id: string) => {
    setDislikedMap(prev => ({ ...prev, [id]: !prev[id] }));
    if (likedMap[id]) {
      setLikedMap(prev => ({ ...prev, [id]: false }));
    }
  };

  return (
    <main className="flex-1 flex flex-col bg-[#0d0f17] relative min-w-[380px] font-mono text-sm overflow-hidden select-text">
      {/* Header */}
      <header className="flex items-center justify-between p-3 border-b border-[#222635] bg-[#0d0f17]/90 backdrop-blur z-10">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          {!isSidebarOpen && (
            <button
              onClick={onToggleSidebar}
              className="p-1 rounded hover:bg-[#222635] text-gray-400 hover:text-white transition-colors mr-1"
              title="Open Sidebar"
            >
              <Sidebar className="w-4 h-4" />
            </button>
          )}
          <h1 className="font-semibold truncate text-gray-200 flex items-center text-xs tracking-wide">
            <span className="text-gray-500 mr-2 font-mono">&lt;-</span>
            <span>HOW CAN I ADD FOLDER ...</span>
          </h1>

          {/* Mode Switcher Pill */}
          {onSwitchMode && (
            <div className="flex items-center bg-[#181a25] border border-[#2c3142] rounded-md p-0.5 ml-2 text-[10px]">
              <button
                onClick={() => onSwitchMode('default')}
                className={`px-2 py-0.5 rounded ${
                  collaborationMode === 'default'
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Default
              </button>
              <button
                onClick={() => onSwitchMode('plan')}
                className={`px-2 py-0.5 rounded ${
                  collaborationMode === 'plan'
                    ? 'bg-purple-600 text-white font-semibold'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Plan Mode
              </button>
              <button
                onClick={() => onSwitchMode('agent')}
                className={`px-2 py-0.5 rounded ${
                  collaborationMode === 'agent'
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Agents
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* Live Template Preview Toggle */}
          <button
            onClick={() => setIsLivePreviewOpen(prev => !prev)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs transition-colors border ${
              isLivePreviewOpen
                ? 'bg-purple-600 text-white border-purple-500 font-semibold shadow-sm'
                : 'bg-[#181a25] hover:bg-[#222635] text-purple-400 hover:text-purple-300 border-[#2c3142]'
            }`}
            title="Toggle Live Markdown Template Preview (plan.md / collaborator.md / default.md)"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Preview</span>
          </button>

          {/* Integrated xterm.js Terminal Toggle */}
          <button
            onClick={() => setIsTerminalOpen(prev => !prev)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs transition-colors border ${
              isTerminalOpen
                ? 'bg-cyan-600 text-white border-cyan-500 font-semibold shadow-sm'
                : 'bg-[#181a25] hover:bg-[#222635] text-cyan-400 hover:text-cyan-300 border-[#2c3142]'
            }`}
            title="Toggle In-Browser xterm.js Terminal (Ctrl+`)"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Terminal</span>
            <kbd className="text-[9px] bg-[#10121a] text-gray-400 px-1 py-0.2 rounded border border-[#2c3142]">^`</kbd>
          </button>

          {onOpenCommandPalette && (
            <button
              onClick={onOpenCommandPalette}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs bg-[#181a25] hover:bg-[#222635] text-gray-300 hover:text-white transition-colors border border-[#2c3142]"
              title="Open Command Palette (Ctrl+K / ⌘K)"
            >
              <Command className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">Commands</span>
              <kbd className="text-[9px] bg-[#10121a] text-gray-400 px-1 py-0.2 rounded border border-[#2c3142]">⌘K</kbd>
            </button>
          )}
          <button
            onClick={onShare}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs hover:bg-[#222635] text-gray-400 hover:text-white transition-colors border border-transparent hover:border-[#2c3142]"
          >
            <Share className="w-3.5 h-3.5" />
            <span>Share</span>
          </button>
          <button
            onClick={onLayoutChange}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs hover:bg-[#222635] text-gray-400 hover:text-white transition-colors border border-transparent hover:border-[#2c3142]"
          >
            <Layout className="w-3.5 h-3.5" />
            <span>Layout</span>
          </button>
          {!isInspectorOpen && (
            <button
              onClick={onToggleInspector}
              className="flex items-center gap-1 px-2 py-1 rounded-md text-xs bg-[#181a25] text-blue-400 hover:bg-[#222635] border border-blue-500/20"
              title="Show Inspector"
            >
              <span>Editor</span>
            </button>
          )}
        </div>
      </header>

      {/* Mode Status Banner */}
      {collaborationMode === 'plan' && (
        <div className="px-4 py-2 bg-purple-950/20 border-b border-purple-900/30 text-[11px] text-purple-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
            <span className="font-semibold uppercase tracking-wider">{planningPhase}</span>
            <span className="text-gray-500">|</span>
            <span className="truncate max-w-xl text-gray-300">{planObjective}</span>
          </div>
          <span className="text-[10px] text-purple-400 bg-purple-900/40 px-2 py-0.5 rounded border border-purple-700/40">
            Decision Complete
          </span>
        </div>
      )}

      {/* Live Markdown Template Preview Split-Pane */}
      {isLivePreviewOpen && (
        <div className="h-80 w-full shrink-0 border-b border-[#222635]">
          <TemplateLivePreview
            isOpen={isLivePreviewOpen}
            onClose={() => setIsLivePreviewOpen(false)}
            collaborationMode={collaborationMode}
            planningPhase={planningPhase}
            planObjective={planObjective}
            activeAgent={activeAgent}
          />
        </div>
      )}

      {/* Dedicated Workspace Body for Agent Mode vs Default/Plan Execution Stream */}
      {collaborationMode === 'agent' ? (
        <AgentModeWorkspace
          activeAgent={activeAgent}
          onSelectAgent={onSelectAgent || (() => {})}
          agents={agents}
          agentMessages={agentMessages}
          onAddAgentMessage={onAddAgentMessage || (() => {})}
          onApproveMessage={onApproveAgentMessage}
          onOpenCommandPalette={onOpenCommandPalette}
          onOpenPatchReview={onOpenPatchReview}
          onApprovePatch={onApprovePatch}
          onRejectPatch={onRejectPatch}
          onOpenPatchSetReview={onOpenPatchSetReview}
          onApprovePatchSet={onApprovePatchSet}
          onRejectPatchSet={onRejectPatchSet}
          files={files}
          onRecordTelemetry={onRecordTelemetry}
        />
      ) : (
        /* AI Execution Stream Viewport */
        <div className="flex-1 overflow-y-auto p-4 lg:p-8 flex flex-col gap-6 pb-48 scrollbar-thin scrollbar-thumb-[#222635]">
        
        {/* Baseline Specification Content (Strict Coordinate Match) */}
        <div className="flex flex-col gap-6 max-w-3xl">
          {/* Callout instruction block */}
          <div className="bg-yellow-500/10 border border-yellow-500/30 text-yellow-200/90 px-3.5 py-2.5 rounded-md text-xs font-semibold max-w-2xl flex items-center gap-2 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
            <span>Do not enable yet</span>
          </div>

          {/* Checklist Guide */}
          <div className="text-xs">
            <p className="mb-2 text-gray-300 font-medium">
              Keep these disabled until independently qualified:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-gray-400">
              <li>dsh-evolve</li>
              <li>dsh-mnemon</li>
              <li>OpenViking</li>
              <li>Zilliz MemSearch</li>
              <li>multiple memory providers together</li>
              <li>experimental model-routing plugins</li>
              <li>unverified third-party sidebar plugins</li>
              <li>the deepseek-ai/deepseek-harness marketplace</li>
            </ul>
          </div>

          {/* Recommended Principle & Preset Code Block */}
          <div>
            <p className="mb-2.5 text-xs text-gray-400 leading-relaxed">
              <span className="text-gray-200 font-medium">Recommended principle</span>
              <br />
              For DeepSeek 7B, every additional plugin...
            </p>

            <div className="bg-[#11131c] border border-[#222635] rounded-md overflow-hidden shadow-md">
              <div className="flex items-center justify-between bg-[#181a25] px-3 py-2 text-xs border-b border-[#222635] select-none">
                <span className="flex items-center gap-2 text-gray-300">
                  <FileJson className="w-3.5 h-3.5 text-blue-400" />
                  <span>Plain text</span>
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={handleCopyPreset}
                    className="hover:text-white text-gray-400 flex items-center gap-1 transition-colors"
                  >
                    {copiedPreset ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedPreset ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={() => setPresetExpanded(!presetExpanded)}
                    className="hover:text-white text-gray-400 flex items-center gap-1 transition-colors"
                  >
                    {presetExpanded ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
                    <span>{presetExpanded ? 'Collapse' : 'Expand'}</span>
                  </button>
                </div>
              </div>
              <div className={`p-3 font-mono text-xs leading-relaxed text-blue-300 transition-all ${presetExpanded ? 'bg-black/30' : ''}`}>
                Standard preset<br />
                + Ollama<br />
                + model-aware context budget<br />
                + filesystem/search
              </div>
            </div>

            {/* Baseline Feedback Actions */}
            <div className="flex items-center gap-3 mt-2.5 text-gray-500 text-xs select-none">
              <button
                onClick={handleCopyPreset}
                className="hover:text-gray-300 p-1 rounded transition-colors"
                title="Copy Preset"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => toggleLike('spec-baseline')}
                className={`hover:text-gray-300 p-1 rounded transition-colors ${likedMap['spec-baseline'] ? 'text-blue-400' : ''}`}
                title="Helpful"
              >
                <ThumbsUp className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => toggleDislike('spec-baseline')}
                className={`hover:text-gray-300 p-1 rounded transition-colors ${dislikedMap['spec-baseline'] ? 'text-rose-400' : ''}`}
                title="Unhelpful"
              >
                <ThumbsDown className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onPlayTTS("Standard preset with Ollama, model-aware context budget, and filesystem search.")}
                className={`hover:text-gray-300 p-1 rounded transition-colors ${isAudioPlaying ? 'text-cyan-400 animate-pulse' : ''}`}
                title="Listen with Gemini TTS"
              >
                <Volume2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic Interactive Conversation Feed */}
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          const isLiked = likedMap[msg.id];
          const isDisliked = dislikedMap[msg.id];
          const isCopied = copiedMsgId === msg.id;

          return (
            <div
              key={msg.id}
              className={`max-w-3xl flex flex-col gap-2 ${
                isUser ? 'ml-auto text-right' : ''
              }`}
            >
              {/* User Bubble */}
              {isUser ? (
                <div className="bg-[#1e2230] border border-[#2c354d] text-gray-100 px-4 py-2.5 rounded-xl rounded-tr-sm inline-block text-left text-xs max-w-xl shadow-sm">
                  {msg.content}
                </div>
              ) : (
                /* Assistant Turn */
                <div className="flex flex-col gap-3 text-left">
                  {/* Model & Thinking Header */}
                  {msg.isHighThinking && (
                    <div className="flex items-center gap-2 text-[11px] text-purple-300 bg-purple-950/40 border border-purple-800/40 px-2.5 py-1 rounded-md w-fit">
                      <BrainCircuit className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
                      <span className="font-semibold">Deep Thinking Mode Active</span>
                      <span className="text-[10px] text-purple-400/80">
                        ({msg.modelUsed || 'gemini-3.1-pro-preview'} · ThinkingLevel.HIGH)
                      </span>
                    </div>
                  )}

                  {/* Thought block if present */}
                  {msg.thought && (
                    <div className="bg-[#141721] border border-[#222635] rounded-md p-3 text-xs text-gray-400 space-y-1.5">
                      <div className="flex items-center gap-1.5 text-gray-500 text-[10px] uppercase font-bold tracking-wider">
                        <Sparkles className="w-3 h-3 text-cyan-400" />
                        <span>Reasoning Trace</span>
                      </div>
                      <div className="text-gray-300 leading-relaxed font-mono text-[11px] whitespace-pre-wrap">
                        {msg.thought}
                      </div>
                    </div>
                  )}

                  {/* Rendered Markdown Body */}
                  <div className="bg-[#141721]/80 border border-[#222635] p-4 rounded-lg text-gray-200 text-xs leading-relaxed">
                    <ReactMarkdown
                      components={{
                        h1: ({ children }) => <h1 className="text-base font-bold text-gray-100 my-2">{children}</h1>,
                        h2: ({ children }) => <h2 className="text-sm font-bold text-gray-200 mt-3 mb-1.5">{children}</h2>,
                        h3: ({ children }) => <h3 className="text-xs font-semibold text-gray-300 mt-2 mb-1">{children}</h3>,
                        ul: ({ children }) => <ul className="list-disc pl-5 my-2 space-y-1 text-gray-300">{children}</ul>,
                        ol: ({ children }) => <ol className="list-decimal pl-5 my-2 space-y-1 text-gray-300">{children}</ol>,
                        code: ({ children, className }) => {
                          const isBlock = Boolean(className);
                          return isBlock ? (
                            <pre className="bg-[#0b0d14] p-3 rounded border border-[#222635] overflow-x-auto my-2 text-cyan-300 text-[11px] font-mono leading-5">
                              <code>{children}</code>
                            </pre>
                          ) : (
                            <code className="bg-[#1d2130] text-blue-300 px-1.5 py-0.5 rounded text-[11px] border border-[#2b3248]">
                              {children}
                            </code>
                          );
                        },
                      }}
                    >
                      {msg.content}
                    </ReactMarkdown>
                  </div>

                  {/* Proposed File Patches & Review Action Cards */}
                  {(() => {
                    const patches = msg.patchProposal
                      ? [msg.patchProposal]
                      : extractPatchesFromMessage(msg.content);

                    if (!patches || patches.length === 0) return null;

                    return (
                      <div className="space-y-2.5 my-2">
                        {patches.map((patch) => {
                          const status = pendingPatchStatusMap[patch.patchId] || patch.status || 'pending';
                          const stats = computeDiffStats(patch.originalContent, patch.proposedContent);

                          return (
                            <div
                              key={patch.patchId}
                              className={`p-3.5 rounded-lg border transition-all ${
                                status === 'approved'
                                  ? 'bg-emerald-950/25 border-emerald-800/40 text-emerald-300'
                                  : status === 'rejected'
                                  ? 'bg-rose-950/25 border-rose-800/40 text-rose-300'
                                  : 'bg-gradient-to-r from-[#141824] via-[#171b28] to-[#1c1828] border-amber-500/40 shadow-md'
                              }`}
                            >
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                                <div className="flex items-start gap-2.5">
                                  <div className="p-1.5 rounded bg-blue-950/60 border border-blue-800/50 text-blue-400 mt-0.5 shrink-0">
                                    <FileCode className="w-4 h-4" />
                                  </div>
                                  <div className="space-y-0.5">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <span className="text-xs font-semibold text-white">
                                        Proposed File Patch
                                      </span>
                                      <span className="text-[11px] font-mono text-cyan-300 bg-[#0b0d14] px-1.5 py-0.5 rounded border border-[#222635]">
                                        {patch.path}
                                      </span>
                                    </div>
                                    <div className="text-[11px] text-gray-400 flex items-center gap-2 flex-wrap">
                                      <span>{patch.explanation || 'Agent requested code modification'}</span>
                                      <span className="text-gray-600">•</span>
                                      <span className="text-emerald-400 font-mono">+{stats.additions}</span>
                                      <span className="text-rose-400 font-mono">-{stats.deletions}</span>
                                    </div>
                                  </div>
                                </div>

                                {/* Action controls based on patch status */}
                                <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                                  {status === 'approved' ? (
                                    <span className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2.5 py-1 rounded font-medium">
                                      <CheckCircle2 className="w-3.5 h-3.5" />
                                      <span>Changes Approved & Applied</span>
                                    </span>
                                  ) : status === 'rejected' ? (
                                    <span className="flex items-center gap-1.5 text-xs text-rose-400 bg-rose-950/60 border border-rose-800 px-2.5 py-1 rounded font-medium">
                                      <Ban className="w-3.5 h-3.5" />
                                      <span>Changes Rejected</span>
                                    </span>
                                  ) : (
                                    <>
                                      {onOpenPatchReview && (
                                        <button
                                          onClick={() => onOpenPatchReview(patch)}
                                          className="px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
                                        >
                                          <GitCompare className="w-3.5 h-3.5" />
                                          <span>Review Changes</span>
                                        </button>
                                      )}
                                      {onApprovePatch && (
                                        <button
                                          onClick={() => onApprovePatch(patch.patchId)}
                                          className="px-2.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
                                          title="Directly approve and apply"
                                        >
                                          <Check className="w-3.5 h-3.5" />
                                          <span>Approve</span>
                                        </button>
                                      )}
                                      {onRejectPatch && (
                                        <button
                                          onClick={() => onRejectPatch(patch.patchId)}
                                          className="px-2.5 py-1.5 rounded bg-[#222635] hover:bg-[#2e3447] text-gray-300 text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
                                          title="Reject this proposal"
                                        >
                                          <Ban className="w-3.5 h-3.5 text-rose-400" />
                                          <span>Reject</span>
                                        </button>
                                      )}
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })()}

                  {/* Message Action Footer */}
                  <div className="flex items-center gap-2.5 text-gray-500 text-xs">
                    <button
                      onClick={() => handleCopyText(msg.id, msg.content)}
                      className="hover:text-gray-300 p-1 rounded transition-colors"
                      title="Copy response"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      onClick={() => toggleLike(msg.id)}
                      className={`hover:text-gray-300 p-1 rounded transition-colors ${isLiked ? 'text-blue-400' : ''}`}
                      title="Helpful"
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => toggleDislike(msg.id)}
                      className={`hover:text-gray-300 p-1 rounded transition-colors ${isDisliked ? 'text-rose-400' : ''}`}
                      title="Unhelpful"
                    >
                      <ThumbsDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onPlayTTS(msg.content)}
                      className={`hover:text-gray-300 p-1 rounded transition-colors ${isAudioPlaying ? 'text-cyan-400 animate-pulse' : ''}`}
                      title="Listen with Gemini TTS"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] text-gray-600 ml-auto">{msg.timestamp}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Streaming Thought / Tool Calling Indicator */}
        {isStreaming && (
          <div className="bg-[#141721] border border-blue-500/30 rounded-lg p-3.5 text-xs flex flex-col gap-2 max-w-2xl animate-pulse">
            <div className="flex items-center gap-2 text-blue-400 font-semibold text-[11px]">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Generating response with Gemini 3.1 Pro engine...</span>
            </div>
            {activeThought && (
              <p className="text-gray-400 text-[11px] leading-relaxed pl-5 font-mono">
                {activeThought}
              </p>
            )}
          </div>
        )}

      </div>
      )}

      {/* In-Browser xterm.js Terminal */}
      <InteractiveTerminal
        isOpen={isTerminalOpen}
        onClose={() => setIsTerminalOpen(false)}
        onRecordCommandEvent={onRecordCommandEvent}
      />

      {/* Persistent Agent Health & Telemetry Status Bar */}
      <AgentStatusBar
        activeAgent={activeAgent}
        onSelectAgent={onSelectAgent || (() => {})}
        agents={agents}
        onOpenAgentMode={() => onSwitchMode && onSwitchMode('agent')}
        onRunTests={() => setIsTerminalOpen(true)}
        isStreaming={isStreaming}
      />
    </main>
  );
};
