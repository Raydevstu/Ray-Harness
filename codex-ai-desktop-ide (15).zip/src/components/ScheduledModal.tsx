import React from 'react';
import { X, Clock, Play, CheckCircle2, AlertCircle } from 'lucide-react';

interface ScheduledModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ScheduledModal: React.FC<ScheduledModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const tasks = [
    {
      id: 'cron-1',
      name: 'Workspace Context Sweep & Ast Indexing',
      schedule: 'Every 30 minutes',
      lastRun: '14m ago',
      status: 'success',
    },
    {
      id: 'cron-2',
      name: 'Memory Graph Neural Sync (Space-Z / AMR)',
      schedule: 'Every hour',
      lastRun: '42m ago',
      status: 'success',
    },
    {
      id: 'cron-3',
      name: 'Dangling Cache & Container Prune',
      schedule: 'Daily at 00:00 UTC',
      lastRun: 'Yesterday',
      status: 'idle',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 font-mono text-xs">
      <div className="w-full max-w-xl bg-[#11131c] border border-[#2c3142] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#181a25] border-b border-[#222635]">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h2 className="font-bold text-gray-100 text-sm tracking-wide">
              SCHEDULED TASKS & CRON RUNNERS
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#222635] rounded text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Task List */}
        <div className="p-4 space-y-3">
          {tasks.map(t => (
            <div
              key={t.id}
              className="p-3.5 bg-[#181a25] border border-[#2c3142] rounded-lg hover:border-amber-500/40 transition-colors"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-gray-200">{t.name}</span>
                <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> {t.status}
                </span>
              </div>
              <div className="flex items-center justify-between text-gray-400 text-[11px] mt-2">
                <span>Frequency: {t.schedule}</span>
                <span className="text-gray-500">Last run: {t.lastRun}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#181a25] border-t border-[#222635] flex items-center justify-between">
          <span className="text-gray-500 text-[11px]">3 background runners active</span>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-[#222635] hover:bg-[#2c3142] text-gray-200 rounded"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
