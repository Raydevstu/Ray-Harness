import React, { useState } from 'react';
import {
  Cpu,
  Terminal,
  Layers,
  ShieldCheck,
  Activity,
  CheckCircle2,
  ChevronUp,
  ChevronDown,
  RefreshCw,
  Play,
  Sliders,
  ExternalLink,
  Wifi,
} from 'lucide-react';
import { AgentInfo, AgentRole } from '../types';

interface AgentStatusBarProps {
  activeAgent: AgentRole;
  onSelectAgent: (agent: AgentRole) => void;
  agents: AgentInfo[];
  onOpenAgentMode?: () => void;
  onRunTests?: () => void;
  isStreaming?: boolean;
}

export const AgentStatusBar: React.FC<AgentStatusBarProps> = ({
  activeAgent,
  onSelectAgent,
  agents,
  onOpenAgentMode,
  onRunTests,
  isStreaming = false,
}) => {
  const [expanded, setExpanded] = useState(false);

  const selectedAgentInfo = agents.find(a => a.id === activeAgent) || agents[0];

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'code_executor':
        return <Terminal className="w-3 h-3 text-cyan-400" />;
      case 'architect':
        return <Layers className="w-3 h-3 text-indigo-400" />;
      case 'reviewer':
        return <ShieldCheck className="w-3 h-3 text-amber-400" />;
      case 'collaborator':
      default:
        return <Cpu className="w-3 h-3 text-emerald-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
        return 'bg-cyan-400 text-cyan-300';
      case 'syncing':
        return 'bg-emerald-400 text-emerald-300';
      case 'waiting':
        return 'bg-amber-400 text-amber-300';
      default:
        return 'bg-blue-400 text-blue-300';
    }
  };

  return (
    <footer className="w-full bg-[#0c0e15] border-t border-[#1f2433] z-20 font-mono text-[11px] text-gray-400 select-none shrink-0">
      {/* Expanded Telemetry Drawer */}
      {expanded && (
        <div className="p-3 bg-[#11141f] border-b border-[#1f2433] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 animate-in slide-in-from-bottom-2 duration-150">
          {agents.map(agent => {
            const isCurrent = agent.id === activeAgent;
            return (
              <div
                key={agent.id}
                onClick={() => onSelectAgent(agent.id)}
                className={`p-2 rounded-md border cursor-pointer transition-colors ${
                  isCurrent
                    ? 'bg-[#181d2c] border-emerald-500/50 text-gray-100 shadow-sm'
                    : 'bg-[#141722] border-[#222738] hover:border-[#2f354c] text-gray-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    {getRoleIcon(agent.id)}
                    <span className="font-semibold text-xs text-gray-200">{agent.name}</span>
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 uppercase">
                    {agent.status}
                  </span>
                </div>
                <p className="text-[10px] text-gray-400 line-clamp-1 mb-1">
                  {agent.currentTask}
                </p>
                <div className="flex items-center justify-between text-[9px] text-gray-500 pt-1 border-t border-[#1e2333]">
                  <span>{agent.model}</span>
                  <span>{agent.concurrency} thread{agent.concurrency > 1 ? 's' : ''}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Main Persistent Bar Strip */}
      <div className="flex items-center justify-between px-3 py-1.5 min-h-[30px]">
        {/* Left: Active Agent & Live State */}
        <div className="flex items-center gap-3 min-w-0">
          {/* Active Agent Selector */}
          <div className="flex items-center gap-1.5 bg-[#141722] px-2 py-0.5 rounded border border-[#23283a]">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isStreaming ? 'bg-cyan-400' : 'bg-emerald-400'}`} />
              <span className={`relative inline-flex rounded-full h-2 w-2 ${isStreaming ? 'bg-cyan-500' : 'bg-emerald-500'}`} />
            </span>
            <span className="text-gray-500 text-[10px]">AGENT:</span>
            <div className="flex items-center gap-1">
              {getRoleIcon(activeAgent)}
              <select
                value={activeAgent}
                onChange={e => onSelectAgent(e.target.value as AgentRole)}
                className="bg-transparent text-gray-200 font-semibold cursor-pointer outline-none text-[11px]"
              >
                {agents.map(a => (
                  <option key={a.id} value={a.id} className="bg-[#141722] text-gray-200">
                    {a.name} ({a.id})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Current Activity Status */}
          <div className="hidden md:flex items-center gap-2 truncate text-gray-300">
            <span className="text-gray-600">|</span>
            <span className="text-gray-500">TASK:</span>
            <span className="truncate max-w-[280px] lg:max-w-md text-[11px] text-cyan-300/90 font-mono">
              {isStreaming ? 'Synthesizing response & AST diff...' : selectedAgentInfo?.currentTask || 'Idle - awaiting dispatch'}
            </span>
          </div>
        </div>

        {/* Right: Metrics, Quick Actions & Drawer Toggle */}
        <div className="flex items-center gap-2.5 shrink-0 text-[10px]">
          {/* Health & Latency */}
          <div className="hidden lg:flex items-center gap-1.5 text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 px-2 py-0.5 rounded">
            <Wifi className="w-3 h-3 text-emerald-400" />
            <span>SWARM: HEALTHY</span>
            <span className="text-emerald-500/70">(28ms)</span>
          </div>

          {/* Concurrency Gauge */}
          <div className="hidden sm:flex items-center gap-1.5 bg-[#141722] border border-[#23283a] px-2 py-0.5 rounded text-gray-300">
            <Cpu className="w-3 h-3 text-purple-400" />
            <span>THREADS: <strong className="text-purple-300">4 / 8</strong></span>
          </div>

          {/* Quick Cargo Test Run */}
          {onRunTests && (
            <button
              onClick={onRunTests}
              className="flex items-center gap-1 px-2 py-0.5 bg-[#141722] hover:bg-[#1f2435] text-gray-300 hover:text-white rounded border border-[#23283a] transition-colors"
              title="Run cargo test validation"
            >
              <Play className="w-2.5 h-2.5 text-emerald-400 fill-emerald-400" />
              <span className="hidden sm:inline">Tests</span>
            </button>
          )}

          {/* Jump to Agent Mode Hub */}
          {onOpenAgentMode && (
            <button
              onClick={onOpenAgentMode}
              className="flex items-center gap-1 px-2 py-0.5 bg-blue-900/30 hover:bg-blue-800/40 text-blue-300 rounded border border-blue-700/40 transition-colors"
              title="Open Agent Mode Orchestration View"
            >
              <span>Hub</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </button>
          )}

          {/* Toggle Fleet Telemetry Drawer */}
          <button
            onClick={() => setExpanded(prev => !prev)}
            className="flex items-center gap-1 p-1 text-gray-400 hover:text-gray-200 hover:bg-[#1c2030] rounded transition-colors"
            title={expanded ? 'Collapse Agent Fleet' : 'Expand Agent Fleet'}
          >
            {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </footer>
  );
};
