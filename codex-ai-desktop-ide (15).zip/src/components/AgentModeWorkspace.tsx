import React, { useState } from 'react';
import {
  Bot,
  Cpu,
  Layers,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Send,
  Terminal,
  ArrowRight,
  AlertCircle,
  Filter,
  Sparkles,
  Plus,
  RefreshCw,
  Sliders,
  Command,
  FileCode,
  Check,
  ChevronDown,
  User,
  GitCompare,
  Ban,
  Wrench,
  ShieldAlert,
  Play,
} from 'lucide-react';
import { AgentInfo, AgentMessage, AgentRole, FilePatch, FilePatchSet, FileItem, AgentToolResult, TimelineEvent } from '../types';
import { getSkillsForRole } from '../utils/skillRegistry';
import { executeAgentTool } from '../utils/agentSkillExecutor';

interface AgentModeWorkspaceProps {
  activeAgent: AgentRole;
  onSelectAgent: (agent: AgentRole) => void;
  agents: AgentInfo[];
  agentMessages: AgentMessage[];
  onAddAgentMessage: (msg: AgentMessage) => void;
  onApproveMessage?: (id: string) => void;
  onOpenCommandPalette?: () => void;
  onOpenPatchReview?: (patch: FilePatch) => void;
  onApprovePatch?: (patchId: string) => void;
  onRejectPatch?: (patchId: string) => void;
  onOpenPatchSetReview?: (patchSet: FilePatchSet) => void;
  onApprovePatchSet?: (patchSetId: string) => void;
  onRejectPatchSet?: (patchSetId: string) => void;
  files?: FileItem[];
  onRecordTelemetry?: (
    event: Omit<TimelineEvent, 'id' | 'timestamp'> & { id?: string; timestamp?: string; createdAt?: number }
  ) => string;
}

export const AgentModeWorkspace: React.FC<AgentModeWorkspaceProps> = ({
  activeAgent,
  onSelectAgent,
  agents,
  agentMessages,
  onAddAgentMessage,
  onApproveMessage,
  onOpenCommandPalette,
  onOpenPatchReview,
  onApprovePatch,
  onRejectPatch,
  onOpenPatchSetReview,
  onApprovePatchSet,
  onRejectPatchSet,
  files = [],
  onRecordTelemetry,
}) => {
  const [filterAgent, setFilterAgent] = useState<'all' | AgentRole>('all');
  const [taskInput, setTaskInput] = useState('');
  const [selectedTargetAgent, setSelectedTargetAgent] = useState<AgentRole>('code_executor');
  const [isDispatching, setIsDispatching] = useState(false);
  const [approvedIds, setApprovedIds] = useState<Record<string, boolean>>({});
  const [executingToolId, setExecutingToolId] = useState<string | null>(null);
  const [lastToolResult, setLastToolResult] = useState<AgentToolResult | null>(null);

  const activeRoleSkills = getSkillsForRole(activeAgent);

  const handleExecuteToolDirectly = async (skillId: string, toolId: string, customParams?: Record<string, unknown>) => {
    setExecutingToolId(toolId);
    setLastToolResult(null);

    const correlationId = `tool_${toolId}_${Date.now()}`;
    const defaultParams: Record<string, unknown> = customParams || {};

    if (toolId === 'read_file_content' && !defaultParams.filePath) {
      defaultParams.filePath = 'config/config.toml';
    } else if (toolId === 'search_codebase' && !defaultParams.query) {
      defaultParams.query = 'ui_mode';
    } else if (toolId === 'execute_terminal_command' && !defaultParams.command) {
      defaultParams.command = 'cargo check --bin jarvis-tests';
    } else if (toolId === 'propose_file_patch' && !defaultParams.filePath) {
      defaultParams.filePath = 'config/config.toml';
      defaultParams.proposedContent = `# Config edit via ${activeAgent} skill execution\nui_mode = "agent"\nnotify = ["terminal-notifier"]\n`;
      defaultParams.explanation = `Skill-driven patch proposal from ${activeAgent}`;
    } else if (toolId === 'propose_patch_set' && !defaultParams.patches) {
      defaultParams.description = 'Atomic multi-file update via agent skill';
      defaultParams.patches = [
        {
          filePath: 'config/config.toml',
          proposedContent: `# Atomic update\nui_mode = "agent"\nnotify = ["terminal-notifier"]\n`,
          explanation: 'Update config.toml in multi-file patch set',
        },
        {
          filePath: 'jarvis-app/core/templates/plan.md',
          proposedContent: `# Updated Plan\nMulti-file patch set verified.\n`,
          explanation: 'Update plan.md in multi-file patch set',
        },
      ];
    }

    const res = await executeAgentTool(
      {
        skillId,
        toolId,
        parameters: defaultParams,
        context: {
          agentRole: activeAgent,
          correlationId,
          files,
        },
      },
      {
        onRecordTelemetry,
        onProposePatch: patch => {
          if (onOpenPatchReview) onOpenPatchReview(patch);
        },
        onProposePatchSet: patchSet => {
          if (onOpenPatchSetReview) onOpenPatchSetReview(patchSet);
        },
      }
    );

    setExecutingToolId(null);
    setLastToolResult(res);

    // Also record an agent message in the thread summarizing tool output
    const msg: AgentMessage = {
      id: `msg_tool_${Date.now()}`,
      fromAgent: activeAgent,
      toAgent: 'collaborator',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      subject: `Tool Executed: ${toolId}`,
      body: res.summary,
      status: res.success ? (res.requiresApproval ? 'pending' : 'completed') : 'rejected',
      codeSnippet: res.data ? JSON.stringify(res.data, null, 2) : undefined,
      actionRequired: res.requiresApproval,
    };
    onAddAgentMessage(msg);
  };

  const handleDispatchTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskInput.trim()) return;

    const newMsg: AgentMessage = {
      id: `msg_ag_${Date.now()}`,
      fromAgent: 'user',
      toAgent: selectedTargetAgent,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      subject: `Developer Instruction to ${selectedTargetAgent}`,
      body: taskInput.trim(),
      status: 'in_progress',
    };

    onAddAgentMessage(newMsg);
    setTaskInput('');
    setIsDispatching(true);

    // Simulate agent acknowledgment response after 1s
    setTimeout(() => {
      setIsDispatching(false);
      const ackMsg: AgentMessage = {
        id: `msg_ag_${Date.now() + 1}`,
        fromAgent: selectedTargetAgent,
        toAgent: 'collaborator',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        subject: `Acknowledged: Instruction Received`,
        body: `Processing dispatch with ${selectedTargetAgent} worktree tools. Validating against config.schema.json.`,
        status: 'completed',
      };
      onAddAgentMessage(ackMsg);
    }, 1100);
  };

  const handleApprove = (id: string, patchId?: string) => {
    setApprovedIds(prev => ({ ...prev, [id]: true }));
    onApproveMessage?.(id);
    if (patchId && onApprovePatch) {
      onApprovePatch(patchId);
    }
  };

  const handleReject = (id: string, patchId?: string) => {
    if (patchId && onRejectPatch) {
      onRejectPatch(patchId);
    }
  };

  const filteredMessages = agentMessages.filter(m => {
    if (filterAgent === 'all') return true;
    return m.fromAgent === filterAgent || m.toAgent === filterAgent;
  });

  const getAgentColor = (role: string) => {
    switch (role) {
      case 'code_executor':
        return 'text-cyan-400 bg-cyan-950/40 border-cyan-800/50';
      case 'architect':
        return 'text-indigo-400 bg-indigo-950/40 border-indigo-800/50';
      case 'reviewer':
        return 'text-amber-400 bg-amber-950/40 border-amber-800/50';
      case 'collaborator':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/50';
      default:
        return 'text-blue-400 bg-blue-950/40 border-blue-800/50';
    }
  };

  const getAgentIcon = (role: string) => {
    switch (role) {
      case 'code_executor':
        return <Terminal className="w-3.5 h-3.5 text-cyan-400" />;
      case 'architect':
        return <Layers className="w-3.5 h-3.5 text-indigo-400" />;
      case 'reviewer':
        return <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />;
      case 'collaborator':
        return <Cpu className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <User className="w-3.5 h-3.5 text-blue-400" />;
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#0d0f17] text-gray-200 font-mono text-xs">
      
      {/* Top Telemetry & Fleet Status Strip */}
      <div className="p-4 border-b border-[#222635] bg-[#11131c]/90 backdrop-blur shrink-0">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-500/50" />
            <h2 className="font-semibold text-sm text-gray-100 flex items-center gap-2">
              <span>Agent Swarm Orchestration Hub</span>
              <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800/60 px-2 py-0.5 rounded font-sans font-medium">
                4 Roles Online
              </span>
            </h2>
          </div>

          <div className="flex items-center gap-2">
            {onOpenCommandPalette && (
              <button
                onClick={onOpenCommandPalette}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-[#181a25] hover:bg-[#222635] text-gray-300 hover:text-white rounded border border-[#2c3142] text-[11px] transition-colors"
                title="Open Command Palette (Ctrl+K)"
              >
                <Command className="w-3.5 h-3.5 text-blue-400" />
                <span>Commands</span>
                <kbd className="text-[9px] bg-[#10121a] text-gray-400 px-1 rounded border border-[#2c3142]">⌘K</kbd>
              </button>
            )}
            <span className="text-[11px] text-gray-400 bg-[#161822] px-2.5 py-1 rounded border border-[#222635]">
              Concurrency: <strong className="text-emerald-400">4 / 8 threads</strong>
            </span>
          </div>
        </div>

        {/* Fleet Agent Status Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {agents.map((agent) => {
            const isSelected = activeAgent === agent.id;
            return (
              <div
                key={agent.id}
                onClick={() => onSelectAgent(agent.id)}
                className={`p-2.5 rounded-lg border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#181d2a] border-emerald-500/60 shadow-md shadow-emerald-950/40 ring-1 ring-emerald-500/30'
                    : 'bg-[#141721] border-[#222635] hover:border-[#2f354a]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    {getAgentIcon(agent.id)}
                    <span className="font-semibold text-gray-100">{agent.name}</span>
                  </div>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded uppercase font-semibold ${
                      agent.status === 'running'
                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                        : agent.status === 'syncing'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : agent.status === 'waiting'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-[#1e2230] text-gray-400 border border-[#2c354d]'
                    }`}
                  >
                    {agent.status}
                  </span>
                </div>

                <p className="text-[10px] text-gray-400 line-clamp-1 mb-1.5">
                  {agent.currentTask}
                </p>

                <div className="flex items-center justify-between text-[10px] text-gray-500 pt-1 border-t border-[#1e2230]">
                  <span>{agent.model}</span>
                  <span>{agent.concurrency} worker{agent.concurrency > 1 ? 's' : ''}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Active Role Skill & Tool Capabilities Strip */}
        <div className="mt-3 pt-2.5 border-t border-[#222635]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-semibold text-gray-300 flex items-center gap-1.5">
              <Wrench className="w-3.5 h-3.5 text-cyan-400" />
              <span>Assigned Skills & Executable Tools for <strong className="text-emerald-400 font-mono">[{activeAgent}]</strong></span>
            </span>
            <span className="text-[10px] text-gray-500">
              {activeRoleSkills.length} Skills / {activeRoleSkills.reduce((a, b) => a + b.tools.length, 0)} Tools Available
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {activeRoleSkills.map(skill => (
              <div
                key={skill.id}
                className="p-2 bg-[#0e101a] border border-[#222635] rounded text-[11px] space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-gray-200">{skill.name}</span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#181a25] text-cyan-400 border border-cyan-900/40 uppercase font-mono">
                    {skill.category}
                  </span>
                </div>
                <p className="text-[10px] text-gray-400 line-clamp-1">{skill.description}</p>
                <div className="flex items-center gap-1 flex-wrap pt-1 border-t border-[#1a1d2e]">
                  {skill.tools.map(t => (
                    <div
                      key={t.id}
                      className="w-full bg-[#141722] p-1.5 rounded border border-[#202538] flex items-center justify-between gap-1"
                    >
                      <div className="flex items-center gap-1 truncate">
                        <span className="text-gray-300 font-mono text-[10px] truncate">{t.id}</span>
                        {t.requiresApproval ? (
                          <span className="text-[9px] text-amber-400 font-semibold px-1 rounded bg-amber-950/60 border border-amber-800/40">
                            Approval
                          </span>
                        ) : (
                          <span className="text-[9px] text-emerald-400 font-semibold px-1 rounded bg-emerald-950/60 border border-emerald-800/40">
                            {t.permissionLevel}
                          </span>
                        )}
                      </div>
                      <button
                        onClick={() => handleExecuteToolDirectly(skill.id, t.id)}
                        disabled={executingToolId === t.id}
                        className="px-2 py-0.5 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-800 text-white text-[10px] font-semibold rounded flex items-center gap-1 transition-colors shrink-0"
                      >
                        {executingToolId === t.id ? (
                          <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                        ) : (
                          <Play className="w-2.5 h-2.5" />
                        )}
                        <span>{executingToolId === t.id ? 'Running' : 'Run'}</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Last Tool Result Feedback Card */}
          {lastToolResult && (
            <div className="mt-2.5 p-2 bg-[#10131d] border border-blue-900/60 rounded flex items-start justify-between gap-2 text-[11px]">
              <div className="space-y-1 flex-1">
                <div className="flex items-center gap-2">
                  <span className={`font-bold uppercase text-[9px] px-1.5 py-0.5 rounded ${
                    lastToolResult.success ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'
                  }`}>
                    {lastToolResult.success ? 'Tool Completed' : 'Tool Failed / Rejected'}
                  </span>
                  <span className="text-gray-300 font-semibold">{lastToolResult.toolId}</span>
                  <span className="text-gray-500 font-mono text-[10px]">({lastToolResult.correlationId})</span>
                  {lastToolResult.durationMs !== undefined && (
                    <span className="text-emerald-400 font-semibold">{lastToolResult.durationMs}ms</span>
                  )}
                </div>
                <p className="text-gray-300">{lastToolResult.summary}</p>
              </div>
              <button
                onClick={() => setLastToolResult(null)}
                className="text-gray-500 hover:text-gray-300 text-xs px-1"
              >
                ×
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Center Section: Filter Header & Ongoing Agent Communications Thread */}
      <div className="flex-1 flex flex-col overflow-hidden">
        
        {/* Communications Thread Filter Bar */}
        <div className="px-4 py-2 bg-[#12141f] border-b border-[#222635] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-gray-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Inter-Agent Communication Thread</span>
            </span>
            <span className="text-[10px] text-gray-500">
              ({filteredMessages.length} events logged)
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-[10px]">
            <span className="text-gray-500 flex items-center gap-1">
              <Filter className="w-3 h-3" />
              <span>Filter:</span>
            </span>
            {(['all', 'collaborator', 'code_executor', 'architect', 'reviewer'] as const).map(role => (
              <button
                key={role}
                onClick={() => setFilterAgent(role)}
                className={`px-2 py-0.5 rounded transition-colors ${
                  filterAgent === role
                    ? 'bg-blue-600 text-white font-medium'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-[#1e2230]'
                }`}
              >
                {role === 'all' ? 'All' : role}
              </button>
            ))}
          </div>
        </div>

        {/* Scrollable Agent Events Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 scrollbar-thin scrollbar-thumb-[#222635]">
          {filteredMessages.map((msg) => {
            const isApproved = approvedIds[msg.id] || msg.status === 'approved';
            return (
              <div
                key={msg.id}
                className="bg-[#141721] border border-[#222635] rounded-lg p-3 hover:border-[#2f354a] transition-colors shadow-sm"
              >
                {/* Event Header */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {/* From Agent Badge */}
                    <span className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold border ${getAgentColor(msg.fromAgent)}`}>
                      {getAgentIcon(msg.fromAgent)}
                      <span>{msg.fromAgent}</span>
                    </span>

                    <ArrowRight className="w-3 h-3 text-gray-500" />

                    {/* To Agent Badge */}
                    <span className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold border ${getAgentColor(msg.toAgent)}`}>
                      {getAgentIcon(msg.toAgent)}
                      <span>{msg.toAgent}</span>
                    </span>

                    <span className="font-medium text-xs text-gray-200 ml-1">
                      {msg.subject}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-[10px] text-gray-500">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{msg.timestamp}</span>
                    </span>
                    {msg.status && (
                      <span
                        className={`px-1.5 py-0.5 rounded font-medium ${
                          isApproved || msg.status === 'approved'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : msg.status === 'completed'
                            ? 'bg-blue-950 text-blue-300 border border-blue-800'
                            : msg.status === 'in_progress'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-gray-800 text-gray-300'
                        }`}
                      >
                        {isApproved ? 'approved' : msg.status}
                      </span>
                    )}
                  </div>
                </div>

                {/* Event Payload Body */}
                <p className="text-gray-300 text-xs leading-relaxed pl-1 mb-2">
                  {msg.body}
                </p>

                {/* Code or Config snippet if included */}
                {msg.codeSnippet && (
                  <div className="mt-2 mb-2 bg-[#0c0e15] border border-[#222635] rounded p-2.5 overflow-x-auto text-[11px] text-cyan-300 font-mono">
                    <pre>
                      <code>{msg.codeSnippet}</code>
                    </pre>
                  </div>
                )}

                {/* Action Required Banner / Approval Gate */}
                {msg.actionRequired && !isApproved && (
                  <div className="mt-2.5 p-2.5 bg-amber-950/30 border border-amber-700/50 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-amber-200">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                      <span className="text-[11px]">
                        <strong>Human Approval Required</strong>: Changeset touches system configuration & render pipeline.
                      </span>
                    </div>
                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      {onOpenPatchReview && (
                        <button
                          onClick={() => {
                            const mockPatch: FilePatch = {
                              type: 'file_patch',
                              patchId: `patch_${msg.id}`,
                              path: 'jarvis-app/config/config.toml',
                              originalContent: `# Codex & Jarvis Collaboration Config\nui_mode = "plan"\nmodel = "gemini-3.1-pro-preview"\napproval_policy = "on-request"`,
                              proposedContent: `# Codex & Jarvis Collaboration Config\nui_mode = "agent"\nmodel = "gemini-3.1-pro-preview"\napproval_policy = "on-request"\nnotify = ["terminal-notifier", "-title", "Codex IDE"]`,
                              explanation: msg.subject,
                            };
                            onOpenPatchReview(mockPatch);
                          }}
                          className="px-2.5 py-1 bg-purple-950/80 hover:bg-purple-900 border border-purple-700/60 text-purple-200 rounded font-medium text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <GitCompare className="w-3 h-3 text-purple-400" />
                          <span>Review Diff</span>
                        </button>
                      )}
                      <button
                        onClick={() => handleApprove(msg.id, `patch_${msg.id}`)}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-medium text-[10px] flex items-center gap-1 transition-colors shadow-sm cursor-pointer"
                      >
                        <Check className="w-3 h-3" />
                        <span>Approve</span>
                      </button>
                      <button
                        onClick={() => handleReject(msg.id, `patch_${msg.id}`)}
                        className="px-2.5 py-1 bg-rose-950/60 hover:bg-rose-900 border border-rose-800/60 text-rose-300 rounded font-medium text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Ban className="w-3 h-3 text-rose-400" />
                        <span>Reject</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Bottom Interactive Agent Dispatch Dock */}
        <div className="p-3 bg-[#11131c] border-t border-[#222635] shrink-0">
          <form onSubmit={handleDispatchTask} className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-[#181a25] border border-[#2c3142] rounded-md px-2 py-1 text-[11px] text-gray-300">
              <span className="text-gray-500">To:</span>
              <select
                value={selectedTargetAgent}
                onChange={e => setSelectedTargetAgent(e.target.value as AgentRole)}
                className="bg-transparent text-gray-200 outline-none cursor-pointer"
              >
                <option value="code_executor">code_executor</option>
                <option value="architect">architect</option>
                <option value="reviewer">reviewer</option>
                <option value="collaborator">collaborator</option>
              </select>
            </div>

            <input
              type="text"
              value={taskInput}
              onChange={e => setTaskInput(e.target.value)}
              placeholder="Dispatch instruction to agent (e.g. Verify render.rs array order preservation)..."
              className="flex-1 bg-[#181a25] border border-[#2c3142] focus:border-blue-500 rounded-md px-3 py-1.5 text-xs text-gray-100 placeholder-gray-500 outline-none transition-colors"
            />

            <button
              type="submit"
              disabled={isDispatching || !taskInput.trim()}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-[#222635] disabled:text-gray-500 text-white rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              {isDispatching ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Dispatching...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Dispatch</span>
                </>
              )}
            </button>
          </form>

          {/* Quick Dispatch Presets */}
          <div className="flex items-center gap-2 mt-2 text-[10px] text-gray-500">
            <span>Quick dispatches:</span>
            <button
              onClick={() => {
                setTaskInput('Reviewer: Run zero-trust diff analysis on collaborator.md');
                setSelectedTargetAgent('reviewer');
              }}
              className="hover:text-gray-300 bg-[#161822] px-2 py-0.5 rounded border border-[#222635] transition-colors"
            >
              Audit collaborator.md
            </button>
            <button
              onClick={() => {
                setTaskInput('Architect: Verify array ordering for notify and args in config.schema.json');
                setSelectedTargetAgent('architect');
              }}
              className="hover:text-gray-300 bg-[#161822] px-2 py-0.5 rounded border border-[#222635] transition-colors"
            >
              Verify Schema Locks
            </button>
            <button
              onClick={() => {
                setTaskInput('Collaborator: Broadcast consensus telemetry to IDE window');
                setSelectedTargetAgent('collaborator');
              }}
              className="hover:text-gray-300 bg-[#161822] px-2 py-0.5 rounded border border-[#222635] transition-colors"
            >
              Broadcast Consensus
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
