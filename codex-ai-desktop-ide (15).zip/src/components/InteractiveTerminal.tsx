import React, { useEffect, useRef, useState } from 'react';
import { Terminal as Xterm } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import '@xterm/xterm/css/xterm.css';
import {
  Terminal as TerminalIcon,
  Maximize2,
  Minimize2,
  X,
  Play,
  Trash2,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface InteractiveTerminalProps {
  isOpen: boolean;
  onClose: () => void;
  height?: number;
  onRecordCommandEvent?: (event: {
    id?: string;
    type: string;
    category: 'terminal';
    status: 'running' | 'completed' | 'failed';
    title: string;
    description?: string;
    commandSummary: string;
    durationMs?: number;
    error?: string;
    metadata?: Record<string, unknown>;
  }) => void;
}

export const InteractiveTerminal: React.FC<InteractiveTerminalProps> = ({
  isOpen,
  onClose,
  height = 240,
  onRecordCommandEvent,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const xtermRef = useRef<Xterm | null>(null);
  const fitAddonRef = useRef<FitAddon | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);

  const commandHistoryRef = useRef<string[]>([]);
  const historyIndexRef = useRef<number>(-1);
  const currentLineRef = useRef<string>('');

  const prompt = '\x1b[1;32mcodex@jarvis\x1b[0m:\x1b[1;34m~/workspace\x1b[0m$ ';

  const writePrompt = (term: Xterm) => {
    term.write(prompt);
  };

  const executeCommand = (term: Xterm, cmd: string) => {
    const trimmed = cmd.trim();
    term.write('\r\n');

    if (!trimmed) {
      writePrompt(term);
      return;
    }

    commandHistoryRef.current.push(trimmed);
    historyIndexRef.current = commandHistoryRef.current.length;

    const parts = trimmed.split(' ');
    const baseCmd = parts[0].toLowerCase();
    const commandEventId = `cmd_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    switch (baseCmd) {
      case 'help':
      case '?':
        term.write('\x1b[1;36mCodex & Jarvis Execution Environment (command_exec_processor.rs)\x1b[0m\r\n');
        term.write('Available commands:\r\n');
        term.write('  \x1b[33mcargo test\x1b[0m          Run the Jarvis Rust render and RPC test suite\r\n');
        term.write('  \x1b[33mcargo check\x1b[0m         Check workspace crates without code generation\r\n');
        term.write('  \x1b[33mgit status\x1b[0m          Inspect working tree modifications & branch\r\n');
        term.write('  \x1b[33mgit diff\x1b[0m            View AST patch diff across templates\r\n');
        term.write('  \x1b[33magents\x1b[0m              Query active subagent swarm telemetry\r\n');
        term.write('  \x1b[33mls [-la]\x1b[0m            List workspace files and directories\r\n');
        term.write('  \x1b[33mcat <file>\x1b[0m          Print file content to stdout\r\n');
        term.write('  \x1b[33muname -a\x1b[0m            System architecture and sandbox details\r\n');
        term.write('  \x1b[33mclear\x1b[0m               Clear terminal screen\r\n');
        writePrompt(term);

        if (onRecordCommandEvent) {
          onRecordCommandEvent({
            id: commandEventId,
            type: 'command_completed',
            category: 'terminal',
            status: 'completed',
            title: `Terminal: help`,
            description: 'Displayed built-in shell commands and AST patch directives.',
            commandSummary: 'help',
            durationMs: 5,
            metadata: { command: 'help', exitCode: 0 },
          });
        }
        return;

      case 'agents':
        term.write('\x1b[1;36mActive Agent Swarm Status:\x1b[0m\r\n');
        term.write('  \x1b[32m● collaborator\x1b[0m   [syncing]     model: gemini-3.1-pro    threads: 1/8\r\n');
        term.write('  \x1b[36m● code_executor\x1b[0m  [running]     model: gemini-3.5-flash  threads: 2/8\r\n');
        term.write('  \x1b[35m● architect\x1b[0m      [waiting]     model: gemini-3.1-pro    threads: 1/8\r\n');
        term.write('  \x1b[33m● reviewer\x1b[0m       [idle]        model: gemini-3.5-flash  threads: 0/8\r\n');
        term.write('\x1b[90mConsensus threshold: 0.85 | Approval gate: ACTIVE\x1b[0m\r\n');
        writePrompt(term);

        if (onRecordCommandEvent) {
          onRecordCommandEvent({
            id: commandEventId,
            type: 'command_completed',
            category: 'terminal',
            status: 'completed',
            title: `Terminal: agents`,
            description: 'Retrieved telemetry for 4 active subagent swarm threads.',
            commandSummary: 'agents',
            durationMs: 8,
            metadata: { command: 'agents', concurrency: 4, exitCode: 0 },
          });
        }
        return;

      case 'clear':
        term.clear();
        writePrompt(term);
        return;

      default:
        break;
    }

    // Record command start with unique stable ID
    if (onRecordCommandEvent) {
      onRecordCommandEvent({
        id: commandEventId,
        type: 'command_started',
        category: 'terminal',
        status: 'running',
        title: `Terminal: ${trimmed.slice(0, 40)}`,
        commandSummary: trimmed,
        metadata: {
          command: trimmed,
          sandbox: 'local_isolated',
        },
      });
    }

    const execStartTime = Date.now();

    // Call /api/exec for real sandboxed command execution
    fetch('/api/exec', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: trimmed }),
    })
      .then(res => res.json())
      .then(data => {
        const duration = data.durationMs || (Date.now() - execStartTime);

        if (data.stdout) {
          const lines = data.stdout.split('\n');
          for (const line of lines) {
            term.write(line + '\r\n');
          }
        }
        if (data.stderr) {
          term.write(`\x1b[31m${data.stderr}\x1b[0m\r\n`);
        }
        if (data.durationMs) {
          term.write(`\x1b[90m[Finished in ${data.durationMs}ms (exit ${data.exitCode})]\x1b[0m\r\n`);
        }

        if (onRecordCommandEvent) {
          const isSuccess = data.exitCode === 0;
          onRecordCommandEvent({
            id: commandEventId,
            type: isSuccess ? 'command_completed' : 'command_failed',
            category: 'terminal',
            status: isSuccess ? 'completed' : 'failed',
            title: `Terminal: ${trimmed.slice(0, 30)} (exit ${data.exitCode})`,
            description: data.stdout ? data.stdout.slice(0, 150) : data.stderr || 'Command executed',
            commandSummary: trimmed,
            durationMs: duration,
            error: data.exitCode !== 0 ? data.stderr || `Non-zero exit code: ${data.exitCode}` : undefined,
            metadata: {
              exitCode: data.exitCode,
              safetyTier: data.safetyTier,
            },
          });
        }

        writePrompt(term);
      })
      .catch(err => {
        const duration = Date.now() - execStartTime;
        term.write(`\x1b[31mExecution error: ${err?.message || 'Failed to reach exec daemon'}\x1b[0m\r\n`);

        if (onRecordCommandEvent) {
          onRecordCommandEvent({
            id: commandEventId,
            type: 'command_failed',
            category: 'terminal',
            status: 'failed',
            title: `Terminal Failed: ${trimmed.slice(0, 30)}`,
            commandSummary: trimmed,
            durationMs: duration,
            error: err?.message || 'Network failure or daemon unreachable',
          });
        }

        writePrompt(term);
      });
  };

  useEffect(() => {
    if (!isOpen || !containerRef.current) return;

    const term = new Xterm({
      cursorBlink: true,
      fontFamily: 'JetBrains Mono, Menlo, Monaco, "Courier New", monospace',
      fontSize: 12,
      lineHeight: 1.25,
      theme: {
        background: '#0d0f17',
        foreground: '#d4d4d8',
        cursor: '#38bdf8',
        cursorAccent: '#0d0f17',
        selectionBackground: 'rgba(56, 189, 248, 0.25)',
        black: '#18181b',
        red: '#f87171',
        green: '#4ade80',
        yellow: '#facc15',
        blue: '#60a5fa',
        magenta: '#c084fc',
        cyan: '#38bdf8',
        white: '#f4f4f5',
      },
      convertEol: true,
    });

    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);

    term.open(containerRef.current);
    try {
      fitAddon.fit();
    } catch {
      // Container sizing grace
    }

    xtermRef.current = term;
    fitAddonRef.current = fitAddon;

    // Welcome banner
    term.write('\x1b[1;36mCodex & Jarvis Integrated xterm.js Terminal\x1b[0m\r\n');
    term.write('\x1b[90mType \x1b[33mhelp\x1b[90m for simulated shell utilities, or click presets below.\x1b[0m\r\n\r\n');
    writePrompt(term);

    // Keystroke handler
    term.onData(data => {
      // Enter
      if (data === '\r') {
        const cmd = currentLineRef.current;
        currentLineRef.current = '';
        executeCommand(term, cmd);
      }
      // Backspace
      else if (data === '\u007F' || data === '\b') {
        if (currentLineRef.current.length > 0) {
          currentLineRef.current = currentLineRef.current.slice(0, -1);
          term.write('\b \b');
        }
      }
      // Ctrl+C
      else if (data === '\u0003') {
        term.write('^C\r\n');
        currentLineRef.current = '';
        writePrompt(term);
      }
      // Arrow Up (History)
      else if (data === '\u001b[A') {
        if (commandHistoryRef.current.length > 0 && historyIndexRef.current > 0) {
          historyIndexRef.current -= 1;
          const prevCmd = commandHistoryRef.current[historyIndexRef.current];
          // Clear current line
          while (currentLineRef.current.length > 0) {
            term.write('\b \b');
            currentLineRef.current = currentLineRef.current.slice(0, -1);
          }
          currentLineRef.current = prevCmd;
          term.write(prevCmd);
        }
      }
      // Arrow Down (History)
      else if (data === '\u001b[B') {
        if (historyIndexRef.current < commandHistoryRef.current.length - 1) {
          historyIndexRef.current += 1;
          const nextCmd = commandHistoryRef.current[historyIndexRef.current];
          while (currentLineRef.current.length > 0) {
            term.write('\b \b');
            currentLineRef.current = currentLineRef.current.slice(0, -1);
          }
          currentLineRef.current = nextCmd;
          term.write(nextCmd);
        } else if (historyIndexRef.current === commandHistoryRef.current.length - 1) {
          historyIndexRef.current += 1;
          while (currentLineRef.current.length > 0) {
            term.write('\b \b');
            currentLineRef.current = currentLineRef.current.slice(0, -1);
          }
        }
      }
      // Printable characters
      else if (data >= ' ' || data === '\t') {
        currentLineRef.current += data;
        term.write(data);
      }
    });

    const handleResize = () => {
      try {
        fitAddon.fit();
      } catch {}
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      term.dispose();
      xtermRef.current = null;
    };
  }, [isOpen]);

  // Refit when expanded
  useEffect(() => {
    setTimeout(() => {
      try {
        fitAddonRef.current?.fit();
      } catch {}
    }, 100);
  }, [isExpanded]);

  if (!isOpen) return null;

  const runQuickCommand = (cmd: string) => {
    if (!xtermRef.current) return;
    xtermRef.current.write(cmd);
    currentLineRef.current = cmd;
    setTimeout(() => {
      if (xtermRef.current) {
        currentLineRef.current = '';
        executeCommand(xtermRef.current, cmd);
      }
    }, 150);
  };

  return (
    <div
      style={{ height: isExpanded ? '480px' : `${height}px` }}
      className="w-full bg-[#0d0f17] border-t border-[#222635] flex flex-col font-mono text-xs select-none relative z-30 transition-all duration-150"
    >
      {/* Terminal Title Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#141721] border-b border-[#222635] select-none shrink-0">
        <div className="flex items-center gap-2">
          <TerminalIcon className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-semibold text-gray-200 text-xs">Integrated Terminal</span>
          <span className="text-[10px] bg-cyan-950 text-cyan-400 border border-cyan-800/60 px-1.5 py-0.2 rounded">
            bash / xterm.js
          </span>
        </div>

        {/* Preset Shell Commands */}
        <div className="hidden sm:flex items-center gap-1.5">
          <span className="text-[10px] text-gray-500 mr-1">Quick Run:</span>
          <button
            onClick={() => runQuickCommand('cargo test')}
            className="px-2 py-0.5 bg-[#1a1d2b] hover:bg-[#252a3d] text-emerald-400 hover:text-emerald-300 rounded border border-[#2b3147] text-[10px] flex items-center gap-1 transition-colors"
          >
            <Play className="w-2.5 h-2.5 fill-current" />
            <span>cargo test</span>
          </button>
          <button
            onClick={() => runQuickCommand('git status')}
            className="px-2 py-0.5 bg-[#1a1d2b] hover:bg-[#252a3d] text-cyan-400 hover:text-cyan-300 rounded border border-[#2b3147] text-[10px] transition-colors"
          >
            git status
          </button>
          <button
            onClick={() => runQuickCommand('agents')}
            className="px-2 py-0.5 bg-[#1a1d2b] hover:bg-[#252a3d] text-purple-400 hover:text-purple-300 rounded border border-[#2b3147] text-[10px] transition-colors"
          >
            agents
          </button>
        </div>

        {/* Window Controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              if (xtermRef.current) {
                xtermRef.current.clear();
                writePrompt(xtermRef.current);
              }
            }}
            className="p-1 text-gray-400 hover:text-white hover:bg-[#222635] rounded transition-colors"
            title="Clear Terminal"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 text-gray-400 hover:text-white hover:bg-[#222635] rounded transition-colors"
            title={isExpanded ? 'Restore size' : 'Expand size'}
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white hover:bg-[#222635] rounded transition-colors"
            title="Close Terminal"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Terminal Viewport */}
      <div
        ref={containerRef}
        className="flex-1 w-full bg-[#0d0f17] p-2 overflow-hidden"
      />
    </div>
  );
};
