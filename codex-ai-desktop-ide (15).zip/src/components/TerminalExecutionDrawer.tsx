import React, { useState, useRef, useEffect } from 'react';
import {
  Terminal as TerminalIcon,
  Play,
  CheckCircle2,
  AlertTriangle,
  X,
  Trash2,
  CornerDownLeft,
  Minimize2,
  Maximize2,
  Shield,
  Activity,
  RotateCw,
} from 'lucide-react';

interface TerminalExecutionDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onRunExternalCommand?: (cmd: string) => Promise<any>;
}

interface CommandLog {
  id: string;
  command: string;
  timestamp: string;
  exitCode: number;
  stdout: string;
  stderr: string;
  durationMs: number;
  safetyTier: string;
}

const PRESET_COMMANDS = [
  { label: 'cargo test', cmd: 'cargo test --bin jarvis-tests' },
  { label: 'cargo check', cmd: 'cargo check' },
  { label: 'git status', cmd: 'git status' },
  { label: 'git diff', cmd: 'git diff' },
];

export const TerminalExecutionDrawer: React.FC<TerminalExecutionDrawerProps> = ({
  isOpen,
  onClose,
  onRunExternalCommand,
}) => {
  const [logs, setLogs] = useState<CommandLog[]>([
    {
      id: 'init_log_1',
      command: 'cargo test --bin jarvis-tests',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      exitCode: 0,
      stdout: `running 6 tests
test test_config_schema_validation ... ok
test test_default_mode_rendering ... ok
test test_apps_strip_when_disabled ... ok
test test_switch_mode_agent ... ok
test test_command_exec_processor_safety ... ok
test test_document_ingestion_buffer ... ok

test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s`,
      stderr: '',
      durationMs: 42,
      safetyTier: 'SafeReadOnly',
    },
  ]);

  const [inputCommand, setInputCommand] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const terminalBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      terminalBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isOpen]);

  const handleExecute = async (cmdToRun: string) => {
    const raw = cmdToRun.trim();
    if (!raw || isRunning) return;

    setIsRunning(true);
    const logId = `exec_${Date.now()}`;
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    try {
      const res = await fetch('/api/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: raw }),
      });

      const data = await res.json();
      const newLog: CommandLog = {
        id: logId,
        command: raw,
        timestamp,
        exitCode: data.exitCode ?? (res.ok ? 0 : 1),
        stdout: data.stdout || '',
        stderr: data.stderr || '',
        durationMs: data.durationMs || 10,
        safetyTier: data.safetyTier || 'SafeReadOnly',
      };

      setLogs(prev => [...prev, newLog]);
    } catch (err: any) {
      const errorLog: CommandLog = {
        id: logId,
        command: raw,
        timestamp,
        exitCode: 1,
        stdout: '',
        stderr: err?.message || 'Failed to execute command pipeline.',
        durationMs: 1,
        safetyTier: 'SafeReadOnly',
      };
      setLogs(prev => [...prev, errorLog]);
    } finally {
      setIsRunning(false);
      setInputCommand('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleExecute(inputCommand);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className={`border-t border-[#222635] bg-[#090b10] flex flex-col font-mono text-xs z-30 transition-all ${
        isExpanded ? 'h-96' : 'h-64'
      }`}
    >
      {/* Terminal Header Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#11131c] border-b border-[#222635] select-none">
        <div className="flex items-center gap-2">
          <TerminalIcon className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-gray-200 font-semibold text-[11px]">Command Execution Pipeline</span>
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-950/60 text-blue-300 border border-blue-800/40">
            command_exec_processor.rs
          </span>
        </div>

        {/* Quick run pills & controls */}
        <div className="flex items-center gap-1.5">
          <div className="hidden sm:flex items-center gap-1 mr-2">
            {PRESET_COMMANDS.map(p => (
              <button
                key={p.cmd}
                onClick={() => handleExecute(p.cmd)}
                disabled={isRunning}
                className="px-2 py-0.5 rounded bg-[#181a25] hover:bg-[#222635] text-gray-300 hover:text-white border border-[#2c3142] text-[10px] flex items-center gap-1 transition-colors disabled:opacity-40"
              >
                <Play className="w-2.5 h-2.5 fill-current text-emerald-400" />
                <span>{p.label}</span>
              </button>
            ))}
          </div>

          <button
            onClick={() => setLogs([])}
            className="p-1 rounded hover:bg-[#222635] text-gray-400 hover:text-gray-200 transition-colors"
            title="Clear terminal logs"
          >
            <Trash2 className="w-3 h-3" />
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded hover:bg-[#222635] text-gray-400 hover:text-gray-200 transition-colors"
            title={isExpanded ? 'Collapse terminal' : 'Expand terminal'}
          >
            {isExpanded ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
          </button>

          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-[#222635] text-gray-400 hover:text-white transition-colors"
            title="Close terminal"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Terminal Output Log Feed */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 font-mono text-[11px] leading-relaxed scrollbar-thin scrollbar-thumb-[#222635] select-text">
        {logs.map((log) => (
          <div key={log.id} className="space-y-1">
            {/* Command Header */}
            <div className="flex items-center justify-between text-gray-400 text-[10px]">
              <div className="flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">$</span>
                <span className="text-gray-100 font-semibold">{log.command}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-500">{log.timestamp}</span>
                <span className="text-gray-500">{log.durationMs}ms</span>
                {log.exitCode === 0 ? (
                  <span className="flex items-center gap-0.5 text-emerald-400 bg-emerald-950/60 px-1 rounded">
                    <CheckCircle2 className="w-2.5 h-2.5" /> exit 0
                  </span>
                ) : (
                  <span className="flex items-center gap-0.5 text-rose-400 bg-rose-950/60 px-1 rounded">
                    <AlertTriangle className="w-2.5 h-2.5" /> exit {log.exitCode}
                  </span>
                )}
              </div>
            </div>

            {/* Stdout stream */}
            {log.stdout && (
              <pre className="text-gray-300 whitespace-pre-wrap bg-[#11131c]/60 p-2 rounded border border-[#1e2230] font-mono">
                {log.stdout}
              </pre>
            )}

            {/* Stderr stream */}
            {log.stderr && (
              <pre className="text-rose-400 whitespace-pre-wrap bg-rose-950/20 p-2 rounded border border-rose-900/30 font-mono">
                {log.stderr}
              </pre>
            )}
          </div>
        ))}
        <div ref={terminalBottomRef} />
      </div>

      {/* Interactive Command Input line */}
      <div className="p-2 bg-[#11131c] border-t border-[#222635] flex items-center gap-2">
        <span className="text-emerald-400 font-bold text-xs pl-1.5">$</span>
        <input
          type="text"
          value={inputCommand}
          onChange={(e) => setInputCommand(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Run workspace command (e.g. cargo test, cargo check, git status, apply_patch)..."
          disabled={isRunning}
          className="flex-1 bg-transparent text-gray-200 outline-none text-xs placeholder-gray-500 font-mono"
        />
        <button
          onClick={() => handleExecute(inputCommand)}
          disabled={!inputCommand.trim() || isRunning}
          className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
        >
          {isRunning ? (
            <>
              <RotateCw className="w-3 h-3 animate-spin" />
              <span>Running...</span>
            </>
          ) : (
            <>
              <span>Run</span>
              <CornerDownLeft className="w-3 h-3" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
