import React, { useState, useRef, useEffect } from 'react';
import {
  Plus,
  AtSign,
  ChevronDown,
  Mic,
  MicOff,
  Send,
  Sparkles,
  BrainCircuit,
  Volume2,
  VolumeX,
  Paperclip,
  Check,
  Zap,
  Cloud,
  FileText,
  FileSpreadsheet,
  Presentation,
  X,
} from 'lucide-react';
import { ModelOption } from '../types';
import { googleDriveService, DriveFileItem } from '../services/GoogleDriveService';

export interface IngestedDoc {
  name: string;
  content: string;
  iconType?: string;
}

interface FloatingPromptDockProps {
  onSend: (
    prompt: string,
    model: ModelOption,
    thinking: boolean,
    attachedDocs?: IngestedDoc[]
  ) => void;
  isStreaming: boolean;
  selectedModel: ModelOption;
  onSelectModel: (m: ModelOption) => void;
  isThinkingMode: boolean;
  onToggleThinking: () => void;
  onOpenSkills: () => void;
  isListening: boolean;
  onToggleVoice: () => void;
  transcript: string;
  isAudioMuted: boolean;
  onToggleAudioMute: () => void;
}

export const FloatingPromptDock: React.FC<FloatingPromptDockProps> = ({
  onSend,
  isStreaming,
  selectedModel,
  onSelectModel,
  isThinkingMode,
  onToggleThinking,
  onOpenSkills,
  isListening,
  onToggleVoice,
  transcript,
  isAudioMuted,
  onToggleAudioMute,
}) => {
  const [input, setInput] = useState('');
  const [modelDropdownOpen, setModelDropdownOpen] = useState(false);
  const [attachMenuOpen, setAttachMenuOpen] = useState(false);
  const [attachedDocs, setAttachedDocs] = useState<IngestedDoc[]>([]);
  const [driveFiles, setDriveFiles] = useState<DriveFileItem[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    googleDriveService.listFiles().then(files => setDriveFiles(files));
  }, []);

  // Sync transcript if user speaks
  useEffect(() => {
    if (transcript) {
      setInput(prev => (prev ? `${prev} ${transcript}` : transcript));
    }
  }, [transcript]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, [input]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isStreaming) return;
    onSend(input.trim(), selectedModel, isThinkingMode, attachedDocs);
    setInput('');
    setAttachedDocs([]);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleAttachDriveFile = (file: DriveFileItem) => {
    if (attachedDocs.some(d => d.name === file.name)) {
      setAttachMenuOpen(false);
      return;
    }
    setAttachedDocs(prev => [
      ...prev,
      {
        name: file.name,
        content: file.contentPreview || `[Google Drive Content of ${file.name}]`,
        iconType: file.iconType,
      },
    ]);
    setAttachMenuOpen(false);
  };

  const handleRemoveDoc = (docName: string) => {
    setAttachedDocs(prev => prev.filter(d => d.name !== docName));
  };

  return (
    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-full max-w-3xl px-4 z-30 font-mono text-xs select-none">
      <div className="bg-[#181a25]/95 backdrop-blur-md border border-[#2c3142] rounded-xl shadow-2xl overflow-hidden flex flex-col focus-within:border-blue-500/60 transition-all">
        
        {/* Attached Document Ingestion Chips */}
        {attachedDocs.length > 0 && (
          <div className="flex flex-wrap items-center gap-1.5 px-3 pt-2.5 pb-1 bg-[#141721] border-b border-[#222635]">
            <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider flex items-center gap-1 mr-1">
              <Cloud className="w-3 h-3 text-blue-400" />
              Ingested Context:
            </span>
            {attachedDocs.map(doc => (
              <span
                key={doc.name}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-950/60 border border-blue-500/40 text-blue-200 text-[11px]"
              >
                {doc.iconType === 'doc' ? (
                  <FileText className="w-3 h-3 text-blue-400" />
                ) : doc.iconType === 'sheet' ? (
                  <FileSpreadsheet className="w-3 h-3 text-emerald-400" />
                ) : doc.iconType === 'slide' ? (
                  <Presentation className="w-3 h-3 text-amber-400" />
                ) : (
                  <Paperclip className="w-3 h-3 text-cyan-400" />
                )}
                <span className="max-w-[150px] truncate">{doc.name}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveDoc(doc.name)}
                  className="p-0.5 hover:text-white rounded ml-0.5"
                >
                  <X className="w-2.5 h-2.5" />
                </button>
              </span>
            ))}
          </div>
        )}

        {/* Textarea Input */}
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={
            isListening
              ? 'Listening to voice command...'
              : attachedDocs.length > 0
              ? 'Ask anything referencing the ingested Google Drive documents...'
              : 'Do anything'
          }
          rows={2}
          className="w-full bg-transparent p-3.5 outline-none resize-none text-gray-200 placeholder-gray-500 text-xs leading-relaxed max-h-[160px] select-text"
        />

        {/* Action Bar */}
        <div className="flex items-center justify-between px-3 py-2 bg-[#11131c]/90 border-t border-[#222635] relative">
          {/* Left tools: Attach, Custom Context, Model select */}
          <div className="flex items-center gap-2">
            {/* Attach Menu */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setAttachMenuOpen(!attachMenuOpen)}
                className="p-1.5 hover:bg-[#222635] text-gray-400 hover:text-gray-200 rounded-md transition-colors flex items-center gap-1"
                title="Attach Google Drive Doc, PDF spec, or workspace context"
              >
                <Plus className="w-4 h-4" />
              </button>
              {attachMenuOpen && (
                <div className="absolute left-0 bottom-full mb-2 w-64 bg-[#181a25] border border-[#2c3142] rounded-md shadow-2xl py-1 text-xs text-gray-300 z-50">
                  <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-blue-400 border-b border-[#222635] flex items-center gap-1.5">
                    <Cloud className="w-3 h-3" />
                    <span>Google Drive Documents</span>
                  </div>
                  {driveFiles.map(file => (
                    <button
                      key={file.id}
                      onClick={() => handleAttachDriveFile(file)}
                      className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center gap-2 text-[11px] truncate"
                    >
                      {file.iconType === 'doc' ? (
                        <FileText className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      ) : file.iconType === 'sheet' ? (
                        <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      ) : file.iconType === 'slide' ? (
                        <Presentation className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      ) : (
                        <Paperclip className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      )}
                      <span className="truncate">{file.name}</span>
                    </button>
                  ))}

                  <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-purple-400 border-t border-b border-[#222635] mt-1 flex items-center gap-1.5">
                    <Paperclip className="w-3 h-3" />
                    <span>Workspace Context</span>
                  </div>
                  <button
                    onClick={() => {
                      setInput(prev => prev + '\n@config/config.toml');
                      setAttachMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center gap-2"
                  >
                    <Paperclip className="w-3.5 h-3.5 text-orange-400" />
                    <span>Attach config.toml</span>
                  </button>
                  <button
                    onClick={() => {
                      setInput(prev => prev + '\n@core/templates/plan.md');
                      setAttachMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center gap-2"
                  >
                    <Paperclip className="w-3.5 h-3.5 text-purple-400" />
                    <span>Attach plan.md</span>
                  </button>
                  <button
                    onClick={() => {
                      setInput(prev => prev + '\n@src/command_exec_processor.rs');
                      setAttachMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center gap-2"
                  >
                    <Zap className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Attach command_exec_processor.rs</span>
                  </button>
                </div>
              )}
            </div>

            {/* Custom Skill / Context Tag */}
            <button
              type="button"
              onClick={onOpenSkills}
              className="px-2 py-1 bg-[#222635] hover:bg-[#2c3142] text-blue-400 hover:text-blue-300 rounded-md text-[11px] font-semibold flex items-center gap-1 transition-colors border border-blue-500/20"
              title="Open Skills & Context matrix"
            >
              <AtSign className="w-3 h-3" />
              <span>Custom</span>
            </button>

            {/* Model Engine Selector */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setModelDropdownOpen(!modelDropdownOpen)}
                className="px-2 py-1 hover:bg-[#222635] text-gray-300 hover:text-white rounded-md text-[11px] flex items-center gap-1.5 transition-colors border border-[#2c3142]"
              >
                <span className="truncate max-w-[130px] font-medium">{selectedModel}</span>
                <ChevronDown className="w-3 h-3 text-gray-400 shrink-0" />
              </button>

              {modelDropdownOpen && (
                <div className="absolute left-0 bottom-full mb-2 w-64 bg-[#181a25] border border-[#2c3142] rounded-md shadow-2xl py-1 text-xs text-gray-300 z-50">
                  <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-gray-500 border-b border-[#222635]">
                    Select AI Engine
                  </div>
                  {[
                    {
                      name: 'Gemini 3.8 Flash' as ModelOption,
                      desc: 'Recommended default: high speed & reasoning without free-tier quota limits',
                      badge: 'Recommended',
                    },
                    {
                      name: 'Gemini 3.5 Flash' as ModelOption,
                      desc: 'Fast general-purpose workspace assistant',
                      badge: 'Fast',
                    },
                    {
                      name: '5.6 Luna Light' as ModelOption,
                      desc: 'Fastest latency (gemini-3.1-flash-lite)',
                      badge: 'Lite',
                    },
                    {
                      name: 'Gemini 3.1 Pro (High Thinking)' as ModelOption,
                      desc: 'ThinkingLevel.HIGH maximum reasoning (Requires paid API key tier)',
                      badge: 'Paid Tier',
                    },
                  ].map(m => (
                    <button
                      key={m.name}
                      onClick={() => {
                        onSelectModel(m.name);
                        setModelDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex flex-col hover:bg-[#222635] transition-colors ${
                        selectedModel === m.name ? 'bg-[#222635]/80 text-white' : 'text-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-[11px]">{m.name}</span>
                        {selectedModel === m.name && <Check className="w-3.5 h-3.5 text-blue-400" />}
                      </div>
                      <span className="text-[10px] text-gray-400 mt-0.5">{m.desc}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* High Thinking Toggle */}
            <button
              type="button"
              onClick={onToggleThinking}
              className={`px-2 py-1 rounded-md text-[11px] flex items-center gap-1 transition-colors border ${
                isThinkingMode
                  ? 'bg-purple-950/60 border-purple-600/50 text-purple-300 font-semibold'
                  : 'text-gray-400 hover:text-gray-200 border-transparent hover:border-[#2c3142]'
              }`}
              title="Toggle High Thinking reasoning (ThinkingLevel.HIGH)"
            >
              <BrainCircuit className={`w-3 h-3 ${isThinkingMode ? 'text-purple-400 animate-pulse' : ''}`} />
              <span className="hidden sm:inline">Thinking</span>
            </button>
          </div>

          {/* Right tools: Voice mic, Audio TTS toggle, Submit */}
          <div className="flex items-center gap-2">
            {/* Audio Toggle */}
            <button
              type="button"
              onClick={onToggleAudioMute}
              className={`p-1.5 rounded-md transition-colors ${
                isAudioMuted ? 'text-gray-500 hover:text-gray-400' : 'text-cyan-400 hover:text-cyan-300 hover:bg-[#222635]'
              }`}
              title={isAudioMuted ? 'Voice output muted' : 'Voice output active (Gemini 3.1 TTS)'}
            >
              {isAudioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* Mic voice input */}
            <button
              type="button"
              onClick={onToggleVoice}
              className={`p-1.5 rounded-md transition-colors ${
                isListening
                  ? 'bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse'
                  : 'hover:bg-[#222635] text-gray-400 hover:text-gray-200'
              }`}
              title={isListening ? 'Listening (Click to stop)' : 'Voice input (Speech Recognition)'}
            >
              {isListening ? <Mic className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Send button */}
            <button
              type="button"
              onClick={() => handleSubmit()}
              disabled={!input.trim() || isStreaming}
              className="p-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:hover:bg-blue-600 text-white rounded-md transition-all shadow-sm flex items-center justify-center cursor-pointer"
              title="Send prompt (Enter)"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

