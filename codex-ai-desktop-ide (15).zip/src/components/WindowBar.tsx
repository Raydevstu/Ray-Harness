import React, { useState } from 'react';
import { Minus, Square, X, Folder, Save, Settings, Shield, Terminal, BookOpen, RefreshCw } from 'lucide-react';

interface WindowBarProps {
  onNewChat: () => void;
  onOpenSkills: () => void;
  onToggleSidebar: () => void;
  onToggleInspector: () => void;
}

export const WindowBar: React.FC<WindowBarProps> = ({
  onNewChat,
  onOpenSkills,
  onToggleSidebar,
  onToggleInspector,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  const toggleMenu = (menu: string) => {
    setActiveMenu(prev => (prev === menu ? null : menu));
  };

  return (
    <header className="relative flex items-center justify-between px-3 py-1 bg-[#141721] border-b border-[#222635] text-xs text-gray-400 select-none z-50">
      {/* Menu items */}
      <nav className="flex items-center space-x-1" aria-label="Application menu">
        {/* File Menu */}
        <div className="relative">
          <button
            onClick={() => toggleMenu('file')}
            aria-expanded={activeMenu === 'file'}
            aria-haspopup="menu"
            className={`px-2 py-0.5 rounded hover:text-gray-100 hover:bg-[#222635] transition-colors ${
              activeMenu === 'file' ? 'bg-[#222635] text-white' : ''
            }`}
          >
            File
          </button>
          {activeMenu === 'file' && (
            <div 
              role="menu"
              aria-label="File menu"
              className="absolute left-0 top-full mt-1 w-48 bg-[#181a25] border border-[#2c3142] rounded-md shadow-xl py-1 text-xs text-gray-300 z-50 animate-in fade-in zoom-in-95 duration-100"
            >
              <button
                role="menuitem"
                onClick={() => {
                  onNewChat();
                  setActiveMenu(null);
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center justify-between"
              >
                <span>New Chat</span>
                <span className="text-gray-500 text-[10px]">Ctrl+N</span>
              </button>
              <button
                role="menuitem"
                onClick={() => setActiveMenu(null)}
                className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center justify-between"
              >
                <span>New Tab</span>
                <span className="text-gray-500 text-[10px]">Ctrl+T</span>
              </button>
              <div className="my-1 border-t border-[#222635]" />
              <button
                role="menuitem"
                onClick={() => setActiveMenu(null)}
                className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center justify-between"
              >
                <span>Save Buffer</span>
                <span className="text-gray-500 text-[10px]">Ctrl+S</span>
              </button>
              <button
                role="menuitem"
                onClick={() => setActiveMenu(null)}
                className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center justify-between"
              >
                <span>Export Session</span>
                <span className="text-gray-500 text-[10px]">JSON</span>
              </button>
            </div>
          )}
        </div>

        {/* Edit Menu */}
        <div className="relative">
          <button
            onClick={() => toggleMenu('edit')}
            aria-expanded={activeMenu === 'edit'}
            aria-haspopup="menu"
            className={`px-2 py-0.5 rounded hover:text-gray-100 hover:bg-[#222635] transition-colors ${
              activeMenu === 'edit' ? 'bg-[#222635] text-white' : ''
            }`}
          >
            Edit
          </button>
          {activeMenu === 'edit' && (
            <div 
              role="menu"
              aria-label="Edit menu"
              className="absolute left-0 top-full mt-1 w-44 bg-[#181a25] border border-[#2c3142] rounded-md shadow-xl py-1 text-xs text-gray-300 z-50"
            >
              <button role="menuitem" onClick={() => setActiveMenu(null)} className="w-full text-left px-3 py-1.5 hover:bg-[#222635]">
                Undo
              </button>
              <button role="menuitem" onClick={() => setActiveMenu(null)} className="w-full text-left px-3 py-1.5 hover:bg-[#222635]">
                Redo
              </button>
              <div className="my-1 border-t border-[#222635]" />
              <button role="menuitem" onClick={() => setActiveMenu(null)} className="w-full text-left px-3 py-1.5 hover:bg-[#222635]">
                Copy Code Block
              </button>
              <button role="menuitem" onClick={() => setActiveMenu(null)} className="w-full text-left px-3 py-1.5 hover:bg-[#222635]">
                Format JSON
              </button>
            </div>
          )}
        </div>

        {/* View Menu */}
        <div className="relative">
          <button
            onClick={() => toggleMenu('view')}
            aria-expanded={activeMenu === 'view'}
            aria-haspopup="menu"
            className={`px-2 py-0.5 rounded hover:text-gray-100 hover:bg-[#222635] transition-colors ${
              activeMenu === 'view' ? 'bg-[#222635] text-white' : ''
            }`}
          >
            View
          </button>
          {activeMenu === 'view' && (
            <div 
              role="menu"
              aria-label="View menu"
              className="absolute left-0 top-full mt-1 w-48 bg-[#181a25] border border-[#2c3142] rounded-md shadow-xl py-1 text-xs text-gray-300 z-50"
            >
              <button
                role="menuitem"
                onClick={() => {
                  onToggleSidebar();
                  setActiveMenu(null);
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center justify-between"
              >
                <span>Toggle Sidebar</span>
                <span className="text-gray-500 text-[10px]">Ctrl+B</span>
              </button>
              <button
                role="menuitem"
                onClick={() => {
                  onToggleInspector();
                  setActiveMenu(null);
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center justify-between"
              >
                <span>Toggle Inspector</span>
                <span className="text-gray-500 text-[10px]">Ctrl+J</span>
              </button>
              <button
                role="menuitem"
                onClick={() => {
                  onOpenSkills();
                  setActiveMenu(null);
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#222635] flex items-center justify-between"
              >
                <span>Agent Skills Matrix</span>
                <span className="text-blue-400 text-[10px]">@skills</span>
              </button>
            </div>
          )}
        </div>

        {/* Help Menu */}
        <div className="relative">
          <button
            onClick={() => toggleMenu('help')}
            aria-expanded={activeMenu === 'help'}
            aria-haspopup="menu"
            className={`px-2 py-0.5 rounded hover:text-gray-100 hover:bg-[#222635] transition-colors ${
              activeMenu === 'help' ? 'bg-[#222635] text-white' : ''
            }`}
          >
            Help
          </button>
          {activeMenu === 'help' && (
            <div 
              role="menu"
              aria-label="Help menu"
              className="absolute left-0 top-full mt-1 w-52 bg-[#181a25] border border-[#2c3142] rounded-md shadow-xl py-1 text-xs text-gray-300 z-50"
            >
              <div className="px-3 py-1.5 text-[11px] font-semibold text-gray-200 border-b border-[#222635]">
                Codex AI Desktop IDE v5.6
              </div>
              <button role="menuitem" onClick={() => setActiveMenu(null)} className="w-full text-left px-3 py-1.5 hover:bg-[#222635]">
                DeepSeek Harness Spec
              </button>
              <button role="menuitem" onClick={() => setActiveMenu(null)} className="w-full text-left px-3 py-1.5 hover:bg-[#222635]">
                Keyboard Shortcuts
              </button>
              <button role="menuitem" onClick={() => setActiveMenu(null)} className="w-full text-left px-3 py-1.5 hover:bg-[#222635]">
                Check for Updates
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Center desktop title */}
      <div className="hidden sm:flex items-center text-[11px] text-gray-400 font-mono">
        <span className="text-blue-400 font-semibold mr-1.5">Codex</span>
        <span>— [kafsh / amr / config.json]</span>
      </div>

      {/* Right Desktop window controls */}
      <div className="flex items-center space-x-2">
        <span className="text-[10px] text-emerald-400/90 font-mono mr-2 hidden md:inline">
          ● ONLINE
        </span>
        <button className="p-1 hover:bg-[#222635] hover:text-gray-200 rounded text-gray-500" aria-label="Minimize">
          <Minus className="w-3 h-3" />
        </button>
        <button className="p-1 hover:bg-[#222635] hover:text-gray-200 rounded text-gray-500" aria-label="Maximize">
          <Square className="w-2.5 h-2.5" />
        </button>
        <button className="p-1 hover:bg-rose-900/60 hover:text-rose-200 rounded text-gray-500" aria-label="Close">
          <X className="w-3 h-3" />
        </button>
      </div>
    </header>
  );
};
