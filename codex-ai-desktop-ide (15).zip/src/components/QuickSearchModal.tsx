import React, { useState, useEffect, useRef } from 'react';
import { Search, X, File, Folder, CornerDownLeft } from 'lucide-react';
import { FileItem } from '../types';

interface QuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: FileItem[];
  onSelectFile: (file: FileItem) => void;
}

export const QuickSearchModal: React.FC<QuickSearchModalProps> = ({
  isOpen,
  onClose,
  files,
  onSelectFile,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Flatten all files and children
  const allItems: FileItem[] = [];
  const collect = (list: FileItem[]) => {
    for (const item of list) {
      allItems.push(item);
      if (item.children) collect(item.children);
    }
  };
  collect(files);

  const filtered = allItems.filter(item =>
    item.name.toLowerCase().includes(query.toLowerCase()) ||
    item.path.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-black/70 backdrop-blur-sm p-4 font-mono text-xs">
      <div className="w-full max-w-lg bg-[#11131c] border border-[#2c3142] rounded-xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95">
        
        {/* Search input bar */}
        <div className="flex items-center px-3.5 py-3 border-b border-[#222635] bg-[#181a25]">
          <Search className="w-4 h-4 text-gray-400 mr-2 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search files, symbols, commands..."
            className="w-full bg-transparent outline-none text-gray-200 placeholder-gray-500 font-mono text-xs"
          />
          <button onClick={onClose} className="p-1 text-gray-500 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results */}
        <div className="max-h-72 overflow-y-auto p-2 space-y-0.5">
          {filtered.length === 0 ? (
            <div className="p-4 text-center text-gray-500">No matching files found</div>
          ) : (
            filtered.slice(0, 15).map(item => (
              <div
                key={item.id}
                onClick={() => {
                  onSelectFile(item);
                  onClose();
                }}
                className="flex items-center justify-between p-2 rounded hover:bg-[#222635] cursor-pointer text-gray-300 hover:text-white transition-colors"
              >
                <div className="flex items-center gap-2 truncate">
                  {item.type === 'dir' ? (
                    <Folder className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  ) : (
                    <File className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
                  )}
                  <span className="font-medium truncate">{item.name}</span>
                  <span className="text-[10px] text-gray-500 truncate">{item.path}</span>
                </div>
                <CornerDownLeft className="w-3 h-3 text-gray-600 shrink-0" />
              </div>
            ))
          )}
        </div>

        {/* Shortcuts note */}
        <div className="px-3 py-2 bg-[#141721] border-t border-[#222635] flex items-center justify-between text-[10px] text-gray-500">
          <span>Navigate with mouse or enter to open</span>
          <span>ESC to close</span>
        </div>

      </div>
    </div>
  );
};
