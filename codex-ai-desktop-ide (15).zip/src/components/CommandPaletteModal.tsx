import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Search,
  Command,
  Sliders,
  Bot,
  Layers,
  ArrowRight,
  Check,
  Terminal,
  FileCode,
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  Settings,
  HelpCircle,
  X,
  BrainCircuit,
  ShieldCheck,
  Cpu,
} from 'lucide-react';
import { AgentRole } from '../types';

export interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  collaborationMode: 'default' | 'plan' | 'agent';
  onSwitchMode: (mode: 'default' | 'plan' | 'agent') => void;
  activeAgent: AgentRole;
  onSelectAgent: (agent: AgentRole) => void;
  onOpenFileByPath?: (path: string) => void;
  isThinkingMode: boolean;
  onToggleThinking: () => void;
  isAudioMuted: boolean;
  onToggleAudioMute: () => void;
  onRunTests?: () => void;
  onOpenQuickSearch?: () => void;
}

interface PaletteItem {
  id: string;
  category: 'Modes' | 'Agents' | 'Config' | 'Actions';
  title: string;
  description: string;
  badge?: string;
  icon: React.ReactNode;
  action: () => void;
  keywords?: string[];
  active?: boolean;
}

export const CommandPaletteModal: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  collaborationMode,
  onSwitchMode,
  activeAgent,
  onSelectAgent,
  onOpenFileByPath,
  isThinkingMode,
  onToggleThinking,
  isAudioMuted,
  onToggleAudioMute,
  onRunTests,
  onOpenQuickSearch,
}) => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Modes' | 'Agents' | 'Config' | 'Actions'>('All');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  const items: PaletteItem[] = useMemo(() => {
    return [
      // 1. UI Modes
      {
        id: 'mode_agent',
        category: 'Modes',
        title: 'Switch to Agent Mode',
        description: 'Multi-agent orchestration view with live agent communications thread & fleet telemetry.',
        badge: 'UI Mode',
        active: collaborationMode === 'agent',
        icon: <Bot className="w-4 h-4 text-emerald-400" />,
        keywords: ['agent', 'fleet', 'collaborator', 'multi-agent', 'orchestration', 'swarm'],
        action: () => {
          onSwitchMode('agent');
          onClose();
        },
      },
      {
        id: 'mode_plan',
        category: 'Modes',
        title: 'Switch to Plan Mode',
        description: '3-Phase conversational planning engine with decision-complete specifications.',
        badge: 'UI Mode',
        active: collaborationMode === 'plan',
        icon: <Layers className="w-4 h-4 text-purple-400" />,
        keywords: ['plan', 'specification', 'spec', 'planning', 'phases'],
        action: () => {
          onSwitchMode('plan');
          onClose();
        },
      },
      {
        id: 'mode_default',
        category: 'Modes',
        title: 'Switch to Default Mode',
        description: 'Direct code execution and minimal questioning workflow.',
        badge: 'UI Mode',
        active: collaborationMode === 'default',
        icon: <Terminal className="w-4 h-4 text-blue-400" />,
        keywords: ['default', 'direct', 'execute', 'code'],
        action: () => {
          onSwitchMode('default');
          onClose();
        },
      },

      // 2. Available Agents
      {
        id: 'agent_collaborator',
        category: 'Agents',
        title: 'Agent: collaborator',
        description: 'Central arbitration bridge, telemetry sync, and cross-agent event distribution.',
        badge: activeAgent === 'collaborator' ? 'Active Agent' : 'Agent',
        active: activeAgent === 'collaborator',
        icon: <Cpu className="w-4 h-4 text-emerald-400" />,
        keywords: ['collaborator', 'agent', 'bridge', 'consensus', 'telemetry', 'handshake'],
        action: () => {
          onSelectAgent('collaborator');
          onSwitchMode('agent');
          onClose();
        },
      },
      {
        id: 'agent_code_executor',
        category: 'Agents',
        title: 'Agent: code_executor',
        description: 'Sandboxed AST patch generator, compiler verification, and test execution.',
        badge: activeAgent === 'code_executor' ? 'Active Agent' : 'Agent',
        active: activeAgent === 'code_executor',
        icon: <Terminal className="w-4 h-4 text-cyan-400" />,
        keywords: ['code_executor', 'code', 'executor', 'compiler', 'patch', 'ast'],
        action: () => {
          onSelectAgent('code_executor');
          onSwitchMode('agent');
          onClose();
        },
      },
      {
        id: 'agent_architect',
        category: 'Agents',
        title: 'Agent: architect',
        description: 'System schema integrity, macro design consistency, and template rules.',
        badge: activeAgent === 'architect' ? 'Active Agent' : 'Agent',
        active: activeAgent === 'architect',
        icon: <Layers className="w-4 h-4 text-indigo-400" />,
        keywords: ['architect', 'schema', 'macro', 'design', 'system'],
        action: () => {
          onSelectAgent('architect');
          onSwitchMode('agent');
          onClose();
        },
      },
      {
        id: 'agent_reviewer',
        category: 'Agents',
        title: 'Agent: reviewer',
        description: 'Zero-trust diff auditing, security vulnerability scans, and approval gates.',
        badge: activeAgent === 'reviewer' ? 'Active Agent' : 'Agent',
        active: activeAgent === 'reviewer',
        icon: <ShieldCheck className="w-4 h-4 text-amber-400" />,
        keywords: ['reviewer', 'review', 'security', 'zero-trust', 'audit', 'diff', 'approval'],
        action: () => {
          onSelectAgent('reviewer');
          onSwitchMode('agent');
          onClose();
        },
      },

      // 3. System Configuration Keys
      {
        id: 'cfg_ui_mode',
        category: 'Config',
        title: 'config.toml :: ui_mode = "agent" | "plan" | "default"',
        description: 'Defines runtime collaboration layout mode and template bindings.',
        badge: 'String',
        icon: <Sliders className="w-4 h-4 text-orange-400" />,
        keywords: ['ui_mode', 'config', 'toml', 'layout'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/config/config.toml');
          onClose();
        },
      },
      {
        id: 'cfg_model',
        category: 'Config',
        title: 'config.toml :: model = "gemini-3.1-pro-preview"',
        description: 'Primary foundation model for deep reasoning and code generation.',
        badge: 'Model',
        icon: <BrainCircuit className="w-4 h-4 text-purple-400" />,
        keywords: ['model', 'gemini', 'gemini-3.1-pro-preview', 'engine'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/config/config.toml');
          onClose();
        },
      },
      {
        id: 'cfg_model_reasoning_effort',
        category: 'Config',
        title: 'config.toml :: model_reasoning_effort = "high"',
        description: 'Controls ThinkingLevel.HIGH budget allocation for complex AST refactoring.',
        badge: 'Thinking',
        icon: <BrainCircuit className="w-4 h-4 text-purple-400" />,
        keywords: ['reasoning', 'effort', 'high', 'thinking'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/config/config.toml');
          onClose();
        },
      },
      {
        id: 'cfg_notify',
        category: 'Config',
        title: 'config.toml :: notify = ["terminal-notifier", "-title", "Codex IDE"]',
        description: 'Preserved-order array for terminal and desktop push alerts.',
        badge: 'Array<String>',
        icon: <Sliders className="w-4 h-4 text-orange-400" />,
        keywords: ['notify', 'notification', 'terminal-notifier', 'array'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/config/config.toml');
          onClose();
        },
      },
      {
        id: 'cfg_feature_flags_enable_apps',
        category: 'Config',
        title: 'config.toml :: [feature_flags].enable_apps = true',
        description: 'Gates rendering of <APPS_INSTRUCTIONS_OPEN_TAG> across markdown templates.',
        badge: 'Boolean',
        icon: <Sliders className="w-4 h-4 text-blue-400" />,
        keywords: ['enable_apps', 'apps', 'features', 'connectors'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/config/config.toml');
          onClose();
        },
      },
      {
        id: 'cfg_feature_flags_enable_code_mode',
        category: 'Config',
        title: 'config.toml :: [feature_flags].enable_code_mode = true',
        description: 'Enables high-density code inspection and AST patch execution.',
        badge: 'Boolean',
        icon: <Sliders className="w-4 h-4 text-blue-400" />,
        keywords: ['enable_code_mode', 'code_mode', 'ast'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/config/config.toml');
          onClose();
        },
      },
      {
        id: 'cfg_agents_max_threads',
        category: 'Config',
        title: 'config.toml :: [agents].max_concurrent_threads_per_session = 8',
        description: 'Concurrency throttle for simultaneous subagent tool dispatches.',
        badge: 'Integer',
        icon: <Sliders className="w-4 h-4 text-emerald-400" />,
        keywords: ['concurrency', 'threads', 'agents', 'max_concurrent_threads_per_session'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/config/config.toml');
          onClose();
        },
      },
      {
        id: 'cfg_agents_ask_for_approval',
        category: 'Config',
        title: 'config.toml :: [agents].ask_for_approval = true',
        description: 'Mandatory human approval gate before executing mutating diff patches.',
        badge: 'Boolean',
        icon: <ShieldCheck className="w-4 h-4 text-amber-400" />,
        keywords: ['ask_for_approval', 'approval', 'gate', 'security'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/config/config.toml');
          onClose();
        },
      },

      // 4. Actions
      {
        id: 'act_run_cargo_tests',
        category: 'Actions',
        title: 'Run Cargo Tests (jarvis-tests)',
        description: 'Verify render pipeline, mode switching, and collaborator RPC validation.',
        badge: 'cargo test',
        icon: <Play className="w-4 h-4 text-emerald-400" />,
        keywords: ['cargo', 'test', 'rust', 'compile', 'verify'],
        action: () => {
          onRunTests?.();
          onClose();
        },
      },
      {
        id: 'act_toggle_thinking',
        category: 'Actions',
        title: isThinkingMode ? 'Disable Deep Thinking (Gemini 3.1 Pro)' : 'Enable Deep Thinking (ThinkingLevel.HIGH)',
        description: 'Toggle expanded step-by-step reasoning trace during query execution.',
        badge: isThinkingMode ? 'Thinking: ON' : 'Thinking: OFF',
        icon: <Sparkles className="w-4 h-4 text-purple-400" />,
        keywords: ['thinking', 'deep thinking', 'toggle thinking', 'reasoning'],
        action: () => {
          onToggleThinking();
          onClose();
        },
      },
      {
        id: 'act_toggle_tts',
        category: 'Actions',
        title: isAudioMuted ? 'Unmute Gemini Speech TTS' : 'Mute Gemini Speech TTS',
        description: 'Toggle automated auditory synthesis for assistant responses.',
        badge: isAudioMuted ? 'Muted' : 'Audible',
        icon: isAudioMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />,
        keywords: ['audio', 'tts', 'sound', 'mute', 'unmute', 'speech'],
        action: () => {
          onToggleAudioMute();
          onClose();
        },
      },
      {
        id: 'act_open_collaborator_template',
        category: 'Actions',
        title: 'Open Collaborator Template (collaborator.md)',
        description: 'Inspect the newly generated multi-agent arbitration blueprint.',
        badge: 'Template',
        icon: <FileCode className="w-4 h-4 text-emerald-400" />,
        keywords: ['collaborator.md', 'collaborator', 'template', 'agent'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/core/templates/agents/collaborator.md');
          onClose();
        },
      },
      {
        id: 'act_open_schema',
        category: 'Actions',
        title: 'Open config.schema.json',
        description: 'View the JSON Schema specification governing all system configuration flags.',
        badge: 'Schema',
        icon: <FileCode className="w-4 h-4 text-blue-400" />,
        keywords: ['schema', 'json', 'config.schema.json'],
        action: () => {
          onOpenFileByPath?.('jarvis-app/config/config.schema.json');
          onClose();
        },
      },
      {
        id: 'act_open_search',
        category: 'Actions',
        title: 'Open File Quick Search (Ctrl+F)',
        description: 'Search workspace files, directories, and symbols.',
        badge: 'Ctrl+F',
        icon: <Search className="w-4 h-4 text-gray-400" />,
        keywords: ['search', 'find', 'files', 'symbols'],
        action: () => {
          onOpenQuickSearch?.();
          onClose();
        },
      },
    ];
  }, [
    collaborationMode,
    onSwitchMode,
    activeAgent,
    onSelectAgent,
    onOpenFileByPath,
    isThinkingMode,
    onToggleThinking,
    isAudioMuted,
    onToggleAudioMute,
    onRunTests,
    onOpenQuickSearch,
    onClose,
  ]);

  // Filter items
  const filteredItems = useMemo(() => {
    let result = items;
    if (selectedCategory !== 'All') {
      result = result.filter(item => item.category === selectedCategory);
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      result = result.filter(item => {
        const titleMatch = item.title.toLowerCase().includes(q);
        const descMatch = item.description.toLowerCase().includes(q);
        const categoryMatch = item.category.toLowerCase().includes(q);
        const keywordMatch = item.keywords?.some(k => k.toLowerCase().includes(q));
        return titleMatch || descMatch || categoryMatch || keywordMatch;
      });
    }
    return result;
  }, [items, selectedCategory, query]);

  // Reset index when filter changes
  useEffect(() => {
    setSelectedIndex(0);
  }, [query, selectedCategory]);

  // Keyboard navigation inside list
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev < filteredItems.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev > 0 ? prev - 1 : filteredItems.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredItems[selectedIndex]) {
        filteredItems[selectedIndex].action();
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };

  // Keep selected item scrolled into view
  useEffect(() => {
    if (listRef.current) {
      const activeEl = listRef.current.children[selectedIndex] as HTMLElement;
      if (activeEl) {
        activeEl.scrollIntoView({ block: 'nearest' });
      }
    }
  }, [selectedIndex]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-start justify-center pt-20 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-[#141721] border border-[#2c3142] rounded-xl shadow-2xl overflow-hidden font-mono flex flex-col max-h-[80vh] animate-in fade-in zoom-in-95 duration-100"
        onClick={e => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Top Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-[#222635] bg-[#181a25]">
          <Command className="w-5 h-5 text-blue-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Type a command, agent, config key, or mode..."
            className="flex-1 bg-transparent border-none outline-none text-gray-100 placeholder-gray-500 text-sm"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-gray-500 hover:text-gray-300 p-1 text-xs"
            >
              Clear
            </button>
          )}
          <kbd className="hidden sm:inline-flex items-center gap-1 text-[10px] bg-[#222635] text-gray-400 px-2 py-0.5 rounded border border-[#2c3142]">
            ESC
          </kbd>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-b border-[#222635] bg-[#11131c] text-xs overflow-x-auto">
          {(['All', 'Modes', 'Agents', 'Config', 'Actions'] as const).map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white font-medium shadow-sm'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-[#1e2230]'
              }`}
            >
              {cat}
            </button>
          ))}
          <span className="text-[10px] text-gray-500 ml-auto hidden sm:inline">
            {filteredItems.length} results
          </span>
        </div>

        {/* Results List */}
        <div
          ref={listRef}
          className="flex-1 overflow-y-auto p-2 space-y-1 divide-y divide-[#1e2230]/40 scrollbar-thin scrollbar-thumb-[#222635]"
        >
          {filteredItems.length === 0 ? (
            <div className="p-8 text-center text-gray-500 text-xs">
              No matching commands or configuration keys found for "{query}".
            </div>
          ) : (
            filteredItems.map((item, index) => {
              const isSelected = index === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={() => item.action()}
                  onMouseEnter={() => setSelectedIndex(index)}
                  className={`flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-blue-900/30 border border-blue-500/40 text-gray-100'
                      : 'hover:bg-[#1a1d28] border border-transparent text-gray-300'
                  }`}
                >
                  <div className={`p-1.5 rounded-md mt-0.5 ${isSelected ? 'bg-blue-500/20' : 'bg-[#181a25]'}`}>
                    {item.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-xs truncate text-gray-100">
                        {item.title}
                      </span>
                      {item.badge && (
                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-sans tracking-wide uppercase ${
                            item.badge.includes('Active')
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-[#222635] text-gray-400'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                      {item.active && (
                        <span className="text-[10px] text-blue-400 ml-auto flex items-center gap-1 font-sans">
                          <Check className="w-3 h-3 text-blue-400" />
                          <span>Current</span>
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-gray-400 mt-0.5 line-clamp-1">
                      {item.description}
                    </p>
                  </div>
                  {isSelected && (
                    <ArrowRight className="w-4 h-4 text-blue-400 shrink-0 self-center" />
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2 bg-[#10121a] border-t border-[#222635] flex items-center justify-between text-[11px] text-gray-500">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded bg-[#1e2230] text-gray-400 text-[10px] border border-[#2c3142]">↑↓</kbd>
              <span>navigate</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded bg-[#1e2230] text-gray-400 text-[10px] border border-[#2c3142]">↵</kbd>
              <span>select</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded bg-[#1e2230] text-gray-400 text-[10px] border border-[#2c3142]">esc</kbd>
              <span>close</span>
            </span>
          </div>
          <span className="text-[10px] text-blue-400/80 font-mono">
            Ctrl+K / ⌘K
          </span>
        </div>
      </div>
    </div>
  );
};
