import React, { useState, useEffect } from 'react';
import {
  ChevronDown,
  Search,
  Sidebar,
  Plus,
  GitPullRequest,
  Clock,
  AtSign,
  Folder,
  HelpCircle,
  FolderGit2,
  CheckCircle2,
  ChevronRight,
  Sparkles,
  Cloud,
  FileText,
  FileSpreadsheet,
  Presentation,
  RotateCw,
  Link,
  Unlink,
} from 'lucide-react';
import { googleDriveService, DriveFileItem } from '../services/GoogleDriveService';

interface LeftSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNewChat: () => void;
  onOpenSearch: () => void;
  onOpenPRs: () => void;
  onOpenScheduled: () => void;
  onOpenSkills: () => void;
  activeProject: string;
  onSelectProject: (name: string) => void;
  onOpenHelp: () => void;
  onSelectDriveFile?: (file: DriveFileItem) => void;
  selectedDriveFileId?: string | null;
}

const DEFAULT_PROJECTS = ['jarvis-app', 'kafsh', 'JARVIS', 'codex', 'deepseek-harness-master'];
const EXTRA_PROJECTS = ['ai-kernel', 'nexus-bridge', 'antigravity-studio'];

const RECENT_ITEMS = [
  'HOW CAN I ADD FOLDER ...',
  'Optimize context window budget',
  'Inspect Ollama standard presets',
  'Debug runtimeKey auth failure',
];

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  isOpen,
  onClose,
  onNewChat,
  onOpenSearch,
  onOpenPRs,
  onOpenScheduled,
  onOpenSkills,
  activeProject,
  onSelectProject,
  onOpenHelp,
  onSelectDriveFile,
  selectedDriveFileId,
}) => {
  const [showMoreProjects, setShowMoreProjects] = useState(false);
  const [recentsExpanded, setRecentsExpanded] = useState(true);
  const [driveExpanded, setDriveExpanded] = useState(true);
  const [workspaceMenuOpen, setWorkspaceMenuOpen] = useState(false);
  const [currentWorkspace, setCurrentWorkspace] = useState('Codex');

  // Google Drive state
  const [isDriveConnected, setIsDriveConnected] = useState(true);
  const [driveFiles, setDriveFiles] = useState<DriveFileItem[]>([]);
  const [isDriveSyncing, setIsDriveSyncing] = useState(false);
  const [driveSearch, setDriveSearch] = useState('');

  useEffect(() => {
    loadDriveFiles();
  }, [isDriveConnected]);

  const loadDriveFiles = async () => {
    setIsDriveSyncing(true);
    try {
      const files = await googleDriveService.listFiles(driveSearch);
      setDriveFiles(files);
    } catch (err) {
      console.warn('Failed to load drive files:', err);
    } finally {
      setIsDriveSyncing(false);
    }
  };

  const handleToggleDriveConnection = async () => {
    if (isDriveConnected) {
      await googleDriveService.disconnect();
      setIsDriveConnected(false);
      setDriveFiles([]);
    } else {
      setIsDriveSyncing(true);
      await googleDriveService.connect();
      setIsDriveConnected(true);
      const files = await googleDriveService.listFiles();
      setDriveFiles(files);
      setIsDriveSyncing(false);
    }
  };

  const getDriveIcon = (iconType: string) => {
    switch (iconType) {
      case 'doc':
        return <FileText className="w-3.5 h-3.5 text-blue-400 shrink-0" />;
      case 'sheet':
        return <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
      case 'slide':
        return <Presentation className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
      case 'pdf':
        return <FileText className="w-3.5 h-3.5 text-rose-400 shrink-0" />;
      default:
        return <Cloud className="w-3.5 h-3.5 text-cyan-400 shrink-0" />;
    }
  };

  if (!isOpen) return null;

  return (
    <aside className="w-[240px] flex flex-col bg-[#11131c] border-r border-[#222635] shrink-0 font-mono text-xs select-none">
      {/* Header Bar */}
      <div className="flex items-center justify-between p-3 border-b border-[#222635] relative">
        <button
          onClick={() => setWorkspaceMenuOpen(!workspaceMenuOpen)}
          className="flex items-center font-semibold text-gray-200 hover:text-white transition-colors"
          title="Switch workspace"
        >
          <span>{currentWorkspace}</span>
          <ChevronDown className="w-3.5 h-3.5 ml-1 text-gray-400" />
        </button>

        {/* Workspace Dropdown */}
        {workspaceMenuOpen && (
          <div className="absolute left-3 top-11 w-48 bg-[#181a25] border border-[#2c3142] rounded-md shadow-2xl py-1 text-xs z-50 animate-in fade-in zoom-in-95">
            {['Codex', 'JARVIS Core', 'DeepSeek Lab'].map(ws => (
              <button
                key={ws}
                onClick={() => {
                  setCurrentWorkspace(ws);
                  setWorkspaceMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-1.5 flex items-center justify-between hover:bg-[#222635] ${
                  currentWorkspace === ws ? 'text-blue-400 font-bold bg-[#222635]/60' : 'text-gray-300'
                }`}
              >
                <span>{ws}</span>
                {currentWorkspace === ws && <CheckCircle2 className="w-3 h-3 text-blue-400" />}
              </button>
            ))}
          </div>
        )}

        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenSearch}
            className="p-1 rounded hover:bg-[#222635] hover:text-white text-gray-400 transition-colors"
            title="Search (Ctrl+F)"
          >
            <Search className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-[#222635] hover:text-white text-gray-400 transition-colors"
            title="Collapse Sidebar"
          >
            <Sidebar className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Primary Action List */}
      <nav className="flex flex-col gap-1 p-2 border-b border-[#222635]/60" aria-label="Global Actions">
        <button
          onClick={onNewChat}
          className="flex items-center gap-2.5 px-2.5 py-1.5 bg-[#181a25] hover:bg-[#222635] text-gray-200 hover:text-white rounded-md transition-colors border border-[#2c3142]/60 shadow-sm text-left"
        >
          <Plus className="w-4 h-4 text-blue-400" />
          <span className="font-semibold">New chat</span>
        </button>

        <button
          onClick={onOpenPRs}
          className="flex items-center gap-2.5 px-2.5 py-1.5 hover:bg-[#222635] text-gray-400 hover:text-gray-200 rounded-md transition-colors text-left"
        >
          <GitPullRequest className="w-4 h-4 text-purple-400" />
          <span>Pull requests</span>
          <span className="ml-auto text-[10px] bg-purple-950/80 text-purple-300 px-1.5 py-0.5 rounded border border-purple-800/50">
            2
          </span>
        </button>

        <button
          onClick={onOpenScheduled}
          className="flex items-center gap-2.5 px-2.5 py-1.5 hover:bg-[#222635] text-gray-400 hover:text-gray-200 rounded-md transition-colors text-left"
        >
          <Clock className="w-4 h-4 text-amber-400" />
          <span>Scheduled</span>
        </button>

        <button
          onClick={onOpenSkills}
          className="flex items-center gap-2.5 px-2.5 py-1.5 hover:bg-[#222635] text-gray-400 hover:text-gray-200 rounded-md transition-colors text-left"
        >
          <AtSign className="w-4 h-4 text-cyan-400" />
          <span>Skills</span>
          <span className="ml-auto flex items-center text-[10px] text-cyan-400 bg-cyan-950/70 border border-cyan-800/40 px-1 rounded">
            <Sparkles className="w-2.5 h-2.5 mr-0.5" /> Tier-3
          </span>
        </button>
      </nav>

      {/* Projects Workspace Tree */}
      <div className="flex-1 overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-[#222635]">
        <div className="text-[11px] font-bold text-gray-500 mb-2 mt-2 px-1 tracking-wider">
          PROJECTS
        </div>
        <ul className="flex flex-col gap-0.5">
          {DEFAULT_PROJECTS.map(proj => {
            const isActive = activeProject === proj;
            return (
              <li
                key={proj}
                onClick={() => onSelectProject(proj)}
                className={`flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer transition-colors ${
                  isActive
                    ? 'bg-[#1e2230] text-blue-300 font-semibold border border-blue-500/20'
                    : 'text-gray-400 hover:bg-[#222635] hover:text-gray-200'
                }`}
              >
                <Folder className={`w-3.5 h-3.5 ${isActive ? 'text-blue-400 fill-blue-400/20' : 'text-blue-400/80'}`} />
                <span className="truncate">{proj}</span>
                {isActive && (
                  <span className="ml-auto text-[9px] text-emerald-400 border border-emerald-800/50 bg-emerald-950/60 px-1 rounded">
                    active
                  </span>
                )}
              </li>
            );
          })}

          {showMoreProjects &&
            EXTRA_PROJECTS.map(proj => (
              <li
                key={proj}
                onClick={() => onSelectProject(proj)}
                className="flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer text-gray-400 hover:bg-[#222635] hover:text-gray-200"
              >
                <FolderGit2 className="w-3.5 h-3.5 text-gray-500" />
                <span className="truncate">{proj}</span>
              </li>
            ))}

          <li
            onClick={() => setShowMoreProjects(!showMoreProjects)}
            className="px-2 py-1 text-[11px] text-gray-500 hover:text-gray-300 cursor-pointer transition-colors"
          >
            {showMoreProjects ? 'Show less' : 'Show more'}
          </li>
        </ul>

        {/* GOOGLE DRIVE CLOUD FILES */}
        <div className="mt-4 border-t border-[#222635]/60 pt-3">
          <div className="flex items-center justify-between mb-1.5 px-1">
            <button
              onClick={() => setDriveExpanded(!driveExpanded)}
              className="text-[11px] font-bold text-gray-500 hover:text-gray-300 flex items-center gap-1.5 transition-colors"
            >
              <Cloud className="w-3.5 h-3.5 text-blue-400" />
              <span className="tracking-wider">GOOGLE DRIVE</span>
              <ChevronRight className={`w-3 h-3 transition-transform ${driveExpanded ? 'rotate-90' : ''}`} />
            </button>

            <div className="flex items-center gap-1">
              <button
                onClick={loadDriveFiles}
                disabled={isDriveSyncing || !isDriveConnected}
                className="p-1 rounded text-gray-500 hover:text-gray-300 hover:bg-[#222635] disabled:opacity-40 transition-colors"
                title="Sync Google Drive"
              >
                <RotateCw className={`w-3 h-3 ${isDriveSyncing ? 'animate-spin text-blue-400' : ''}`} />
              </button>
              <button
                onClick={handleToggleDriveConnection}
                className={`p-1 rounded text-[10px] transition-colors ${
                  isDriveConnected ? 'text-emerald-400 hover:text-emerald-300 hover:bg-[#222635]' : 'text-gray-500 hover:text-gray-300 hover:bg-[#222635]'
                }`}
                title={isDriveConnected ? 'Connected to Google Workspace (Click to disconnect)' : 'Connect Google Drive OAuth'}
              >
                {isDriveConnected ? <Link className="w-3 h-3" /> : <Unlink className="w-3 h-3" />}
              </button>
            </div>
          </div>

          {driveExpanded && (
            <div className="flex flex-col gap-1">
              {isDriveConnected ? (
                <>
                  {/* Drive file list */}
                  <ul className="flex flex-col gap-0.5">
                    {driveFiles.map(file => {
                      const isSelected = selectedDriveFileId === file.id;
                      return (
                        <li
                          key={file.id}
                          onClick={() => onSelectDriveFile && onSelectDriveFile(file)}
                          className={`flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer transition-colors group ${
                            isSelected
                              ? 'bg-blue-950/60 text-blue-200 font-semibold border border-blue-500/40'
                              : 'text-gray-400 hover:bg-[#222635] hover:text-gray-200'
                          }`}
                          title={`${file.name} • ${file.owner}`}
                        >
                          {getDriveIcon(file.iconType)}
                          <span className="truncate flex-1 text-[11px]">{file.name}</span>
                          <span className="text-[9px] uppercase px-1 py-0.2 rounded bg-[#181a25] text-gray-500 group-hover:text-gray-400">
                            {file.iconType}
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                  <div className="px-2 py-1 text-[9px] text-gray-500 flex items-center justify-between">
                    <span>{driveFiles.length} cloud files</span>
                    <span className="text-emerald-400">OAuth Synced</span>
                  </div>
                </>
              ) : (
                <div className="p-2.5 rounded bg-[#181a25] border border-[#2c3142] text-center">
                  <p className="text-[10px] text-gray-400 mb-2">Google Drive disconnected</p>
                  <button
                    onClick={handleToggleDriveConnection}
                    className="w-full py-1 px-2 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-semibold transition-colors flex items-center justify-center gap-1"
                  >
                    <Link className="w-3 h-3" />
                    <span>Connect Drive</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* RECENTS > */}
        <div className="mt-5 border-t border-[#222635]/60 pt-3">
          <div
            onClick={() => setRecentsExpanded(!recentsExpanded)}
            className="text-[11px] font-bold text-gray-500 mb-2 px-1 flex items-center justify-between cursor-pointer hover:text-gray-300 transition-colors"
          >
            <span className="tracking-wider">RECENTS</span>
            <ChevronRight className={`w-3 h-3 transition-transform ${recentsExpanded ? 'rotate-90' : ''}`} />
          </div>
          {recentsExpanded && (
            <ul className="flex flex-col gap-1 text-[11px]">
              {RECENT_ITEMS.map((item, idx) => (
                <li
                  key={idx}
                  onClick={onNewChat}
                  className="px-2 py-1 truncate text-gray-400 hover:text-gray-200 hover:bg-[#222635] rounded cursor-pointer transition-colors"
                  title={item}
                >
                  {item}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* User Profile Footer */}
      <div
        onClick={onOpenHelp}
        className="p-3 border-t border-[#222635] flex items-center justify-between hover:bg-[#181a25] cursor-pointer transition-colors"
      >
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center text-white text-[10px] font-bold shadow-sm">
            HK
          </div>
          <div className="flex flex-col">
            <span className="text-gray-200 font-semibold leading-none">Hurera K</span>
            <span className="text-[10px] text-emerald-400 mt-0.5 leading-none">Pro Developer</span>
          </div>
        </div>
        <HelpCircle className="w-4 h-4 text-gray-400 hover:text-gray-200 transition-colors" />
      </div>
    </aside>
  );
};
