import React, { useState, useMemo } from 'react';
import {
  FileText,
  Sparkles,
  Eye,
  Code2,
  Copy,
  Check,
  Split,
  Maximize2,
  Minimize2,
  RefreshCw,
  X,
  Sliders,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import {
  DEFAULT_MD_CONTENT,
  PLAN_MD_CONTENT,
  COLLABORATOR_MD_CONTENT,
} from '../data/mockFiles';
import { AgentRole } from '../types';

interface TemplateLivePreviewProps {
  isOpen: boolean;
  onClose: () => void;
  collaborationMode: 'default' | 'plan' | 'agent';
  planningPhase: string;
  planObjective: string;
  activeAgent: AgentRole;
  enableApps?: boolean;
}

export const TemplateLivePreview: React.FC<TemplateLivePreviewProps> = ({
  isOpen,
  onClose,
  collaborationMode,
  planningPhase,
  planObjective,
  activeAgent,
  enableApps = true,
}) => {
  const [selectedTemplate, setSelectedTemplate] = useState<'auto' | 'plan.md' | 'default.md' | 'collaborator.md'>('auto');
  const [viewMode, setViewMode] = useState<'split' | 'rendered' | 'raw'>('split');
  const [copied, setCopied] = useState(false);

  const activeTemplateName = useMemo(() => {
    if (selectedTemplate !== 'auto') return selectedTemplate;
    if (collaborationMode === 'plan') return 'plan.md';
    if (collaborationMode === 'agent') return 'collaborator.md';
    return 'default.md';
  }, [selectedTemplate, collaborationMode]);

  const rawTemplate = useMemo(() => {
    switch (activeTemplateName) {
      case 'plan.md':
        return PLAN_MD_CONTENT;
      case 'collaborator.md':
        return COLLABORATOR_MD_CONTENT;
      case 'default.md':
      default:
        return DEFAULT_MD_CONTENT;
    }
  }, [activeTemplateName]);

  // Interpolate state variables dynamically into template
  const interpolatedTemplate = useMemo(() => {
    let result = rawTemplate;

    const appsSection = enableApps
      ? `## Available Apps & Worktree Connectors
- **Terminal**: Sandboxed pseudo-terminal with cargo test & AST diff validation.
- **Filesystem**: Read-write access to jarvis-app workspace.
- **Google Drive Bridge**: Connected to client workspace.
- **Agent RPC**: Low-latency IPC channel for multi-agent arbitration.`
      : `*(Apps connector feature flag disabled in config.toml)*`;

    const contextSnapshot = `Workspace: jarvis-app (48 files)
Active Branch: codex-feature-sync
Selected Model: gemini-3.1-pro-preview (ThinkingLevel.HIGH)
System Mode: ${collaborationMode.toUpperCase()}
Timestamp: ${new Date().toISOString()}`;

    const planSteps = `1. [x] Phase 1: Context Ingestion & Schema Audit
2. [x] Phase 2: Architectural Alignment & AST Boundaries
3. [ ] Phase 3: Implementation Spec (In Progress - ${planningPhase})
4. [ ] Phase 4: Cargo Verification & Automated Regression Passes`;

    const executionOutput = `[SYSTEM OK] - Subagent ${activeAgent} assigned to active dispatch loop.
Confidence score: 0.98. Sandbox status: SECURE.`;

    result = result.replace(/\{\{planning_phase\}\}/g, planningPhase);
    result = result.replace(/\{\{plan_objective\}\}/g, planObjective);
    result = result.replace(/\{\{plan_steps\}\}/g, planSteps);
    result = result.replace(/\{\{apps_section\}\}/g, appsSection);
    result = result.replace(/\{\{context_snapshot\}\}/g, contextSnapshot);
    result = result.replace(/\{\{execution_output\}\}/g, executionOutput);
    result = result.replace(/\{\{active_agent\}\}/g, activeAgent);
    result = result.replace(/\{\{ask_for_approval\}\}/g, 'true');
    result = result.replace(/\{\{timestamp\}\}/g, Date.now().toString());

    // Clean up or format APPS tags
    if (!enableApps) {
      result = result.replace(/<APPS_INSTRUCTIONS_OPEN_TAG>[\s\S]*?<\/APPS_INSTRUCTIONS_OPEN_TAG>/g, '');
    }

    return result;
  }, [rawTemplate, planningPhase, planObjective, activeAgent, collaborationMode, enableApps]);

  const handleCopy = () => {
    navigator.clipboard.writeText(interpolatedTemplate);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="flex flex-col h-full w-full bg-[#0e1017] border-b border-[#222635] overflow-hidden font-mono text-xs">
      {/* Control Strip */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#141722] border-b border-[#222635] select-none shrink-0">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-purple-300 font-semibold text-xs">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Live Template Hydration</span>
          </div>

          <span className="text-gray-600">|</span>

          {/* Template Selector */}
          <div className="flex items-center gap-1 bg-[#1a1d2b] border border-[#2b3147] rounded px-2 py-0.5 text-[11px]">
            <span className="text-gray-400 text-[10px]">Template:</span>
            <select
              value={selectedTemplate}
              onChange={e => setSelectedTemplate(e.target.value as any)}
              className="bg-transparent text-gray-200 outline-none cursor-pointer font-mono"
            >
              <option value="auto">Auto (Current Mode)</option>
              <option value="plan.md">plan.md (Plan Mode)</option>
              <option value="default.md">default.md (Default Mode)</option>
              <option value="collaborator.md">collaborator.md (Agent Mode)</option>
            </select>
          </div>

          <span className="text-[10px] bg-purple-950 text-purple-300 border border-purple-800/60 px-1.5 py-0.5 rounded">
            {activeTemplateName}
          </span>
        </div>

        {/* View Mode Switcher & Actions */}
        <div className="flex items-center gap-1.5">
          <div className="flex items-center bg-[#1a1d2b] border border-[#2b3147] rounded p-0.5 text-[10px]">
            <button
              onClick={() => setViewMode('split')}
              className={`px-2 py-0.5 rounded flex items-center gap-1 transition-colors ${
                viewMode === 'split' ? 'bg-purple-600 text-white font-semibold' : 'text-gray-400 hover:text-gray-200'
              }`}
              title="Split View: Raw & Rendered"
            >
              <Split className="w-3 h-3" />
              <span>Split</span>
            </button>
            <button
              onClick={() => setViewMode('rendered')}
              className={`px-2 py-0.5 rounded flex items-center gap-1 transition-colors ${
                viewMode === 'rendered' ? 'bg-purple-600 text-white font-semibold' : 'text-gray-400 hover:text-gray-200'
              }`}
              title="Rendered Output Only"
            >
              <Eye className="w-3 h-3" />
              <span>Preview</span>
            </button>
            <button
              onClick={() => setViewMode('raw')}
              className={`px-2 py-0.5 rounded flex items-center gap-1 transition-colors ${
                viewMode === 'raw' ? 'bg-purple-600 text-white font-semibold' : 'text-gray-400 hover:text-gray-200'
              }`}
              title="Hydrated Source Text Only"
            >
              <Code2 className="w-3 h-3" />
              <span>Hydrated Source</span>
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-1 bg-[#1a1d2b] hover:bg-[#252a3d] text-gray-300 hover:text-white rounded border border-[#2b3147] text-[11px] transition-colors"
            title="Copy Hydrated Prompt Markdown"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>

          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white hover:bg-[#222635] rounded transition-colors"
            title="Close Live Preview"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Split-Pane Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Side: Hydrated Raw Markdown Source */}
        {(viewMode === 'split' || viewMode === 'raw') && (
          <div className={`flex-1 flex flex-col overflow-hidden bg-[#0c0e14] ${viewMode === 'split' ? 'border-r border-[#222635]' : ''}`}>
            <div className="px-3 py-1.5 bg-[#12141d] border-b border-[#222635] text-[10px] text-gray-400 flex items-center justify-between select-none">
              <span className="font-semibold text-gray-300 flex items-center gap-1.5">
                <Code2 className="w-3 h-3 text-blue-400" />
                <span>Hydrated Markdown Buffer (Interpolated)</span>
              </span>
              <span className="text-gray-500">{interpolatedTemplate.length} chars</span>
            </div>
            <pre className="flex-1 overflow-y-auto p-4 text-[11.5px] leading-5 text-gray-300 font-mono whitespace-pre-wrap selection:bg-purple-600/30 scrollbar-thin scrollbar-thumb-[#222635]">
              <code>{interpolatedTemplate}</code>
            </pre>
          </div>
        )}

        {/* Right Side: Visual Markdown Preview */}
        {(viewMode === 'split' || viewMode === 'rendered') && (
          <div className="flex-1 flex flex-col overflow-hidden bg-[#0e1017]">
            <div className="px-3 py-1.5 bg-[#12141d] border-b border-[#222635] text-[10px] text-gray-400 flex items-center justify-between select-none">
              <span className="font-semibold text-gray-300 flex items-center gap-1.5">
                <Eye className="w-3 h-3 text-emerald-400" />
                <span>Rendered Document View</span>
              </span>
              <span className="text-emerald-400/80 bg-emerald-950/60 border border-emerald-800/40 px-1 rounded text-[9px]">
                Active Prompt
              </span>
            </div>
            <div className="flex-1 overflow-y-auto p-6 text-gray-200 text-xs leading-relaxed space-y-4 select-text scrollbar-thin scrollbar-thumb-[#222635]">
              <ReactMarkdown
                components={{
                  h1: ({ children }) => (
                    <h1 className="text-base font-bold text-gray-100 pb-2 border-b border-[#222635] mt-1 mb-3">
                      {children}
                    </h1>
                  ),
                  h2: ({ children }) => (
                    <h2 className="text-sm font-bold text-gray-200 mt-4 mb-2 flex items-center gap-1.5">
                      <span className="text-purple-400">#</span>
                      {children}
                    </h2>
                  ),
                  h3: ({ children }) => (
                    <h3 className="text-xs font-semibold text-gray-300 mt-3 mb-1">{children}</h3>
                  ),
                  ul: ({ children }) => (
                    <ul className="list-disc pl-5 my-2 space-y-1 text-gray-300">{children}</ul>
                  ),
                  ol: ({ children }) => (
                    <ol className="list-decimal pl-5 my-2 space-y-1 text-gray-300">{children}</ol>
                  ),
                  blockquote: ({ children }) => (
                    <blockquote className="border-l-2 border-purple-500 bg-purple-950/20 pl-3 py-1.5 my-2 text-purple-200 rounded-r text-[11px]">
                      {children}
                    </blockquote>
                  ),
                  code: ({ children, className }) => {
                    const isBlock = Boolean(className);
                    return isBlock ? (
                      <pre className="bg-[#08090e] p-3 rounded border border-[#222635] overflow-x-auto my-2 text-cyan-300 text-[11px] font-mono leading-5">
                        <code>{children}</code>
                      </pre>
                    ) : (
                      <code className="bg-[#1b1f2e] text-blue-300 px-1 py-0.5 rounded text-[11px] border border-[#2a3148]">
                        {children}
                      </code>
                    );
                  },
                }}
              >
                {interpolatedTemplate}
              </ReactMarkdown>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
