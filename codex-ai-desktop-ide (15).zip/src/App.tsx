import React, { useState, useEffect, useCallback, useRef } from 'react';
import { WindowBar } from './components/WindowBar';
import { LeftSidebar } from './components/LeftSidebar';
import { CenterWorkspace } from './components/CenterWorkspace';
import { FloatingPromptDock } from './components/FloatingPromptDock';
import { RightInspector } from './components/RightInspector';
import { SkillsModal } from './components/SkillsModal';
import { PullRequestsModal } from './components/PullRequestsModal';
import { ScheduledModal } from './components/ScheduledModal';
import { QuickSearchModal } from './components/QuickSearchModal';
import { ShareModal } from './components/ShareModal';
import { HelpModal } from './components/HelpModal';
import { CommandPaletteModal } from './components/CommandPaletteModal';
import {
  INITIAL_FILES,
  CONFIG_TOML_CONTENT,
  CONFIG_SCHEMA_JSON_CONTENT,
  DEFAULT_MD_CONTENT,
  PLAN_MD_CONTENT,
  RENDER_RS_CONTENT,
  APPLY_COMMAND_RS_CONTENT,
  LIB_RS_CONTENT,
  COLLABORATOR_MD_CONTENT,
  INITIAL_AGENTS,
  INITIAL_AGENT_MESSAGES,
} from './data/mockFiles';
import { FileItem, TabItem, Message, ModelOption, AgentRole, AgentInfo, AgentMessage, FilePatch, FilePatchSet, TimelineEvent } from './types';
import { validatePatchSet, applyPatchSetAtomically } from './utils/patchParser';
import { DriveFileItem } from './services/GoogleDriveService';
import { AudioWaveformVisualizer } from './components/AudioWaveformVisualizer';
import { IngestedDoc } from './components/FloatingPromptDock';
import { extractPatchesFromMessage } from './utils/patchParser';
import { INITIAL_TIMELINE_EVENTS, redactSensitiveInfo, sanitizeMetadata } from './utils/telemetryStore';

export default function App() {
  // Layout states
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isInspectorOpen, setIsInspectorOpen] = useState(true);
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);
  const [activeProject, setActiveProject] = useState('jarvis-app');
  const [layoutMode, setLayoutMode] = useState<'default' | 'editor-wide' | 'focus-chat'>('default');

  // Runtime Execution & Telemetry Timeline State
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>(INITIAL_TIMELINE_EVENTS);

  // Centralized Telemetry Recorder with Lifecycle Transition & Deduplication Support
  const recordTimelineEvent = useCallback(
    (event: Omit<TimelineEvent, 'id' | 'timestamp'> & { id?: string; timestamp?: string; createdAt?: number }): string => {
      const nowMs = event.createdAt || Date.now();
      const id = event.id || `evt_${nowMs}_${Math.random().toString(36).substring(2, 7)}`;
      const timestamp =
        event.timestamp ||
        new Date(nowMs).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

      const newEvent: TimelineEvent = {
        ...event,
        id,
        createdAt: nowMs,
        timestamp,
        title: redactSensitiveInfo(event.title),
        description: event.description ? redactSensitiveInfo(event.description) : undefined,
        commandSummary: event.commandSummary ? redactSensitiveInfo(event.commandSummary) : undefined,
        error: event.error ? redactSensitiveInfo(event.error) : undefined,
        metadata: sanitizeMetadata(event.metadata),
      };

      setTimelineEvents(prev => {
        const existingIdx = prev.findIndex(e => e.id === id);
        if (existingIdx >= 0) {
          const current = prev[existingIdx];
          // Prevent completed or failed terminal/chat/agent operations from regressing to running
          if ((current.status === 'completed' || current.status === 'failed') && newEvent.status === 'running') {
            return prev;
          }
          // Mutate state immutably by updating the existing event in place
          const updated = [...prev];
          updated[existingIdx] = {
            ...current,
            ...newEvent,
            createdAt: current.createdAt || newEvent.createdAt,
            timestamp: current.timestamp || newEvent.timestamp,
          };
          return updated;
        }

        // Limit to 200 events in memory, preserving active running events if truncation is needed
        const next = [newEvent, ...prev];
        if (next.length > 200) {
          const running = next.filter(e => e.status === 'running');
          const nonRunning = next.filter(e => e.status !== 'running');
          const maxNonRunning = 200 - running.length;
          const trimmed = [...running, ...nonRunning.slice(0, Math.max(0, maxNonRunning))];
          return trimmed.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        }
        return next;
      });

      return id;
    },
    []
  );

  const clearTimelineEvents = useCallback(() => {
    setTimelineEvents([]);
  }, []);

  // Google Drive Selected File
  const [selectedDriveFile, setSelectedDriveFile] = useState<DriveFileItem | null>(null);

  // Collaboration Mode Engine: 'default' | 'plan' | 'agent'
  const [collaborationMode, setCollaborationMode] = useState<'default' | 'plan' | 'agent'>('plan');
  const [planningPhase, setPlanningPhase] = useState('PHASE 3: Implementation Spec');
  const [planObjective, setPlanObjective] = useState(
    'Build identical Codex UI layout, functions, feature flags, and wiring config in Jarvis app'
  );
  const [activeAgent, setActiveAgent] = useState<AgentRole>('collaborator');
  const [agents, setAgents] = useState<AgentInfo[]>(INITIAL_AGENTS);
  const [agentMessages, setAgentMessages] = useState<AgentMessage[]>(INITIAL_AGENT_MESSAGES);

  // Patch & Diff Approval Pipeline State
  const [activeReviewPatch, setActiveReviewPatch] = useState<FilePatch | null>(null);
  const [activeReviewPatchSet, setActiveReviewPatchSet] = useState<FilePatchSet | null>(null);
  const [pendingPatchStatusMap, setPendingPatchStatusMap] = useState<Record<string, 'pending' | 'approved' | 'rejected'>>({});

  // Modals
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [skillsModalOpen, setSkillsModalOpen] = useState(false);
  const [prsModalOpen, setPrsModalOpen] = useState(false);
  const [scheduledModalOpen, setScheduledModalOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [helpModalOpen, setHelpModalOpen] = useState(false);

  // Files & Tabs
  const [files] = useState<FileItem[]>(INITIAL_FILES);
  const [tabs, setTabs] = useState<TabItem[]>([
    {
      id: 'tab_config_toml',
      name: 'config.toml',
      path: 'jarvis-app/config/config.toml',
      language: 'toml',
      content: CONFIG_TOML_CONTENT,
    },
    {
      id: 'tab_plan_md',
      name: 'plan.md',
      path: 'jarvis-app/core/templates/plan.md',
      language: 'markdown',
      content: PLAN_MD_CONTENT,
    },
    {
      id: 'tab_render_rs',
      name: 'render.rs',
      path: 'jarvis-app/src/render.rs',
      language: 'rust',
      content: RENDER_RS_CONTENT,
    },
  ]);
  const [activeTabId, setActiveTabId] = useState<string>('tab_config_toml');

  // Model & Reasoning Selection
  const [selectedModel, setSelectedModel] = useState<ModelOption>('Gemini 3.8 Flash');
  const [isThinkingMode, setIsThinkingMode] = useState(true);

  // Streaming & Conversation
  const [messages, setMessages] = useState<Message[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [activeThought, setActiveThought] = useState<string | null>(null);

  // Audio / Speech / Waveform
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState('Kore');
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [showWaveformOverlay, setShowWaveformOverlay] = useState(false);
  const recognitionRef = useRef<any>(null);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Keyboard Shortcuts (Ctrl+K palette, Ctrl+B sidebar, Ctrl+J editor, Ctrl+F search)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(prev => !prev);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
        e.preventDefault();
        setIsSidebarOpen(prev => !prev);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'j') {
        e.preventDefault();
        setIsInspectorOpen(prev => !prev);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        setSearchModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Web Speech recognition setup
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setTranscript(currentTranscript);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognitionRef.current = recognition;
    }
  }, []);

  const toggleVoice = () => {
    if (!recognitionRef.current) {
      alert('Voice recognition is not supported in this browser environment.');
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setTranscript('');
      try {
        recognitionRef.current.start();
      } catch (err) {
        console.error('Speech recognition start failed:', err);
      }
    }
  };

  // TTS with Gemini 3.1 Flash TTS (with fallback to speech synthesis)
  const playTTS = useCallback(async (textToSpeak: string) => {
    if (isAudioMuted || !textToSpeak) return;

    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }

    setIsAudioPlaying(true);

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToSpeak.slice(0, 280),
          voice: 'Kore',
        }),
      });

      const data = await res.json();
      if (data.audio) {
        const audio = new Audio(`data:audio/wav;base64,${data.audio}`);
        currentAudioRef.current = audio;
        audio.onended = () => setIsAudioPlaying(false);
        audio.onerror = () => {
          setIsAudioPlaying(false);
          fallbackSpeech(textToSpeak);
        };
        await audio.play();
        return;
      }
    } catch (err) {
      console.warn('Gemini TTS call failed; falling back to client synthesis', err);
    }

    fallbackSpeech(textToSpeak);
  }, [isAudioMuted]);

  const fallbackSpeech = (textToSpeak: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(textToSpeak.slice(0, 200));
      utterance.onend = () => setIsAudioPlaying(false);
      utterance.onerror = () => setIsAudioPlaying(false);
      window.speechSynthesis.speak(utterance);
    } else {
      setIsAudioPlaying(false);
    }
  };

  // Open file in editor tab
  const handleOpenFile = (file: FileItem) => {
    if (file.type === 'dir') return;

    const existing = tabs.find(t => t.path === file.path);
    if (existing) {
      setActiveTabId(existing.id);
    } else {
      const newTab: TabItem = {
        id: `tab_${Date.now()}`,
        name: file.name,
        path: file.path,
        language: file.language || 'text',
        content: file.content || `// Content of ${file.name}\n`,
      };
      setTabs(prev => [...prev, newTab]);
      setActiveTabId(newTab.id);
    }
  };

  const handleCloseTab = (id: string) => {
    if (tabs.length <= 1) return;
    const nextTabs = tabs.filter(t => t.id !== id);
    setTabs(nextTabs);
    if (activeTabId === id) {
      setActiveTabId(nextTabs[nextTabs.length - 1].id);
    }
  };

  const handleNewTab = () => {
    const tabNum = tabs.length + 1;
    const newTab: TabItem = {
      id: `tab_untitled_${Date.now()}`,
      name: `untitled-${tabNum}.rs`,
      path: `jarvis-app/src/untitled-${tabNum}.rs`,
      language: 'rust',
      content: '// New buffer\n',
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
  };

  const findFileByPath = (items: FileItem[], targetPath: string): FileItem | null => {
    for (const item of items) {
      if (item.path === targetPath) return item;
      if (item.children) {
        const found = findFileByPath(item.children, targetPath);
        if (found) return found;
      }
    }
    return null;
  };

  const handleOpenFileByPath = (targetPath: string) => {
    const file = findFileByPath(files, targetPath);
    if (file) {
      handleOpenFile(file);
    } else {
      const fileName = targetPath.split('/').pop() || 'file';
      const ext = fileName.split('.').pop() || 'text';
      let lang = 'text';
      if (ext === 'rs') lang = 'rust';
      else if (ext === 'toml') lang = 'toml';
      else if (ext === 'json') lang = 'json';
      else if (ext === 'md') lang = 'markdown';
      else if (ext === 'ts' || ext === 'tsx') lang = 'typescript';

      handleOpenFile({
        id: `file_${Date.now()}`,
        name: fileName,
        path: targetPath,
        type: 'file',
        language: lang,
        content: `// Content of ${fileName}\n`,
      });
    }
  };

  const handleAddAgentMessage = (msg: AgentMessage) => {
    setAgentMessages(prev => [...prev, msg]);

    // Record agent message telemetry event
    const status = msg.status === 'rejected' ? 'rejected' : msg.status === 'in_progress' ? 'running' : 'completed';
    recordTimelineEvent({
      id: `evt_${msg.id}`,
      type: 'agent_message',
      category: 'agent',
      status,
      title: `[${msg.fromAgent} → ${msg.toAgent}] ${msg.subject}`,
      description: msg.body ? msg.body.slice(0, 150) : undefined,
      source: 'agent',
      metadata: {
        fromAgent: msg.fromAgent,
        toAgent: msg.toAgent,
        status: msg.status,
        hasSnippet: Boolean(msg.codeSnippet),
      },
    });
  };

  const handleApproveAgentMessage = (id: string) => {
    setAgentMessages(prev =>
      prev.map(m => (m.id === id ? { ...m, status: 'approved', actionRequired: false } : m))
    );
  };

  const handleRunCargoTests = () => {
    setCollaborationMode('agent');
    const testCmdEventId = `cmd_cargo_test_${Date.now()}`;
    const startMsg: AgentMessage = {
      id: `msg_test_${Date.now()}`,
      fromAgent: 'code_executor',
      toAgent: 'fleet',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      subject: 'Executing cargo test --bin jarvis-tests',
      body: 'Compiling tests in workspace with APPS_ENABLED=true and APPS_ENABLED=false...',
      status: 'in_progress',
    };
    handleAddAgentMessage(startMsg);

    recordTimelineEvent({
      id: testCmdEventId,
      type: 'command_started',
      category: 'terminal',
      status: 'running',
      title: 'Cargo Test Suite: Dispatched',
      commandSummary: 'cargo test --bin jarvis-tests',
      source: 'agent',
    });

    setTimeout(() => {
      const passMsg: AgentMessage = {
        id: `msg_test_result_${Date.now()}`,
        fromAgent: 'code_executor',
        toAgent: 'collaborator',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        subject: 'Cargo Test Suite: 4/4 Passed (0 Failures)',
        body: 'All test assertions in src/render.rs, src/apply_command.rs, and collaborator RPC verified.',
        status: 'completed',
        codeSnippet: 'running 4 tests\ntest test_default_mode_rendering ... ok\ntest test_apps_strip_when_disabled ... ok\ntest test_switch_mode_agent ... ok\ntest test_collaborator_rpc_routing ... ok\n\ntest result: ok. 4 passed; 0 failed;',
      };
      handleAddAgentMessage(passMsg);

      recordTimelineEvent({
        id: testCmdEventId,
        type: 'command_completed',
        category: 'terminal',
        status: 'completed',
        title: 'Cargo Test Suite: 4/4 Passed',
        commandSummary: 'cargo test --bin jarvis-tests',
        durationMs: 1000,
        source: 'agent',
        metadata: { passed: 4, failed: 0 },
      });
    }, 1000);
  };

  // Switch collaboration mode (Default, Plan, Agent)
  const handleSwitchMode = (mode: 'default' | 'plan' | 'agent') => {
    setCollaborationMode(mode);
    recordTimelineEvent({
      type: 'agent_started',
      category: 'system',
      status: 'completed',
      title: `Collaboration Mode Switched: ${mode.toUpperCase()}`,
      source: 'system',
      metadata: { mode },
    });
    if (mode === 'plan') {
      const planTab = tabs.find(t => t.name === 'plan.md');
      if (planTab) setActiveTabId(planTab.id);
    } else if (mode === 'default') {
      const defTab = tabs.find(t => t.name === 'default.md');
      if (defTab) setActiveTabId(defTab.id);
    } else if (mode === 'agent') {
      let agentTab = tabs.find(t => t.name === 'collaborator.md' || t.name === 'collaboration.md');
      if (agentTab) {
        setActiveTabId(agentTab.id);
      } else {
        handleOpenFileByPath('jarvis-app/core/templates/agents/collaborator.md');
      }
    }
  };

  // Agent Patch & Diff Approval Pipeline Handlers
  const handleOpenPatchReview = (patch: FilePatch) => {
    setActiveReviewPatch(patch);
    setIsInspectorOpen(true);

    recordTimelineEvent({
      type: 'patch_review_opened',
      category: 'patch',
      status: 'pending',
      title: `Diff Review Opened: ${patch.path}`,
      description: patch.explanation || 'Staged diff presented in side-by-side Monaco DiffEditor.',
      filePath: patch.path,
      patchId: patch.patchId,
      source: 'agent',
    });

    // If an existing tab matches the patch path, activate it; otherwise create or open it
    const existingTab = tabs.find(t => t.path === patch.path || t.name === patch.path.split('/').pop());
    if (existingTab) {
      setActiveTabId(existingTab.id);
    } else {
      const fileName = patch.path.split('/').pop() || 'patch-target';
      const ext = fileName.split('.').pop() || 'text';
      let lang = 'text';
      if (ext === 'rs') lang = 'rust';
      else if (ext === 'toml') lang = 'toml';
      else if (ext === 'json') lang = 'json';
      else if (ext === 'md') lang = 'markdown';
      else if (ext === 'ts' || ext === 'tsx') lang = 'typescript';

      const newTab: TabItem = {
        id: `tab_patch_${Date.now()}`,
        name: fileName,
        path: patch.path,
        language: lang,
        content: patch.originalContent || `// ${patch.path}\n`,
      };
      setTabs(prev => [...prev, newTab]);
      setActiveTabId(newTab.id);
    }
  };

  const handleApprovePatch = (patchId: string) => {
    setPendingPatchStatusMap(prev => ({ ...prev, [patchId]: 'approved' }));

    // Find the patch in activeReviewPatch or inside messages
    let targetPatch: FilePatch | null = activeReviewPatch?.patchId === patchId ? activeReviewPatch : null;
    if (!targetPatch) {
      for (const msg of messages) {
        if (msg.patchProposal?.patchId === patchId) {
          targetPatch = msg.patchProposal;
          break;
        }
        const extracted = extractPatchesFromMessage(msg.content);
        const match = extracted.find(p => p.patchId === patchId);
        if (match) {
          targetPatch = match;
          break;
        }
      }
    }

    if (targetPatch) {
      // Atomically update in-memory tab content
      setTabs(prev => {
        const existingIdx = prev.findIndex(
          t => t.path === targetPatch!.path || t.name === targetPatch!.path.split('/').pop()
        );
        if (existingIdx >= 0) {
          const updated = [...prev];
          updated[existingIdx] = {
            ...updated[existingIdx],
            content: targetPatch!.proposedContent,
          };
          return updated;
        } else {
          const fileName = targetPatch!.path.split('/').pop() || 'file';
          const ext = fileName.split('.').pop() || 'text';
          let lang = 'text';
          if (ext === 'rs') lang = 'rust';
          else if (ext === 'toml') lang = 'toml';
          else if (ext === 'json') lang = 'json';
          else if (ext === 'md') lang = 'markdown';
          else if (ext === 'ts' || ext === 'tsx') lang = 'typescript';

          return [
            ...prev,
            {
              id: `tab_${Date.now()}`,
              name: fileName,
              path: targetPatch!.path,
              language: lang,
              content: targetPatch!.proposedContent,
            },
          ];
        }
      });

      // Record approval event in Agent Mode message feed
      const approvalAuditMsg: AgentMessage = {
        id: `msg_audit_appr_${Date.now()}`,
        fromAgent: 'collaborator',
        toAgent: 'code_executor',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        subject: `Patch Approved: ${targetPatch.path}`,
        body: `Developer approved patch ${targetPatch.patchId}. Applied updated AST directly into active tab buffer.`,
        status: 'completed',
        codeSnippet: targetPatch.proposedContent.slice(0, 300) + (targetPatch.proposedContent.length > 300 ? '\n...' : ''),
      };
      handleAddAgentMessage(approvalAuditMsg);

      recordTimelineEvent({
        type: 'patch_approved',
        category: 'patch',
        status: 'completed',
        title: `Patch Approved: ${targetPatch.path}`,
        description: `Applied atomic changes to tab buffer for ${targetPatch.path}`,
        filePath: targetPatch.path,
        patchId: targetPatch.patchId,
        source: 'system',
      });
    }

    // Reset active review patch if it was this one
    if (activeReviewPatch?.patchId === patchId) {
      setActiveReviewPatch(null);
    }
  };

  const handleRejectPatch = (patchId: string) => {
    setPendingPatchStatusMap(prev => ({ ...prev, [patchId]: 'rejected' }));

    let targetPath = activeReviewPatch?.path || 'workspace file';

    const rejectAuditMsg: AgentMessage = {
      id: `msg_audit_rej_${Date.now()}`,
      fromAgent: 'collaborator',
      toAgent: 'code_executor',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      subject: `Patch Rejected: ${targetPath}`,
      body: `Developer rejected patch ${patchId}. Workspace buffer untouched.`,
      status: 'rejected',
    };
    handleAddAgentMessage(rejectAuditMsg);

    recordTimelineEvent({
      type: 'patch_rejected',
      category: 'patch',
      status: 'rejected',
      title: `Patch Rejected: ${targetPath}`,
      description: `Developer rejected patch proposal ${patchId}. Workspace buffer preserved.`,
      filePath: targetPath,
      patchId: patchId,
      source: 'system',
    });

    if (activeReviewPatch?.patchId === patchId) {
      setActiveReviewPatch(null);
    }
  };

  const handleCancelReview = () => {
    setActiveReviewPatch(null);
  };

  // Multi-File Patch Set Handlers
  const handleOpenPatchSetReview = (patchSet: FilePatchSet) => {
    setActiveReviewPatchSet(patchSet);
    setIsInspectorOpen(true);

    recordTimelineEvent({
      type: 'patch_set_proposed',
      category: 'patch',
      status: 'pending',
      title: `Multi-File Patch Set Review Opened: ${patchSet.description}`,
      description: `Staged multi-file patch set containing ${patchSet.patches.length} files.`,
      patchSetId: patchSet.patchSetId,
      source: 'agent',
    });
  };

  const handleApprovePatchSet = (patchSetId: string) => {
    const targetPatchSet = activeReviewPatchSet?.patchSetId === patchSetId ? activeReviewPatchSet : null;

    if (targetPatchSet) {
      // Validate first before applying
      const validation = validatePatchSet(targetPatchSet, tabs, files);
      if (!validation.valid) {
        recordTimelineEvent({
          type: 'patch_set_rejected',
          category: 'patch',
          status: 'failed',
          title: `Patch Set Approval Blocked: ${targetPatchSet.description}`,
          description: validation.error || 'Validation failed before application.',
          patchSetId,
          error: validation.error,
          source: 'system',
        });
        return;
      }

      // Apply atomically in memory
      const result = applyPatchSetAtomically(targetPatchSet, tabs, files);
      if (!result.success) {
        recordTimelineEvent({
          type: 'patch_set_rejected',
          category: 'patch',
          status: 'failed',
          title: `Patch Set Application Failed: ${targetPatchSet.description}`,
          description: result.error || 'Failed to apply patch set atomically.',
          patchSetId,
          error: result.error,
          source: 'system',
        });
        return;
      }
      setTabs(result.updatedTabs);

      const auditMsg: AgentMessage = {
        id: `msg_audit_ps_appr_${Date.now()}`,
        fromAgent: 'collaborator',
        toAgent: 'code_executor',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        subject: `Patch Set Approved: ${targetPatchSet.description}`,
        body: `Developer approved multi-file patch set (${targetPatchSet.patches.length} files). Applied atomic state update.`,
        status: 'completed',
      };
      handleAddAgentMessage(auditMsg);

      recordTimelineEvent({
        type: 'patch_set_approved',
        category: 'patch',
        status: 'completed',
        title: `Patch Set Approved: ${targetPatchSet.description}`,
        description: `Atomically applied ${targetPatchSet.patches.length} file changes to workspace buffers.`,
        patchSetId,
        source: 'system',
      });
    }

    if (activeReviewPatchSet?.patchSetId === patchSetId) {
      setActiveReviewPatchSet(null);
    }
  };

  const handleRejectPatchSet = (patchSetId: string) => {
    const desc = activeReviewPatchSet?.description || 'Patch set';

    const auditMsg: AgentMessage = {
      id: `msg_audit_ps_rej_${Date.now()}`,
      fromAgent: 'collaborator',
      toAgent: 'code_executor',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      subject: `Patch Set Rejected: ${desc}`,
      body: `Developer rejected patch set ${patchSetId}. Workspace buffers untouched.`,
      status: 'rejected',
    };
    handleAddAgentMessage(auditMsg);

    recordTimelineEvent({
      type: 'patch_set_rejected',
      category: 'patch',
      status: 'rejected',
      title: `Patch Set Rejected: ${desc}`,
      description: `Developer rejected patch set proposal ${patchSetId}. Workspace state preserved.`,
      patchSetId,
      source: 'system',
    });

    if (activeReviewPatchSet?.patchSetId === patchSetId) {
      setActiveReviewPatchSet(null);
    }
  };

  const handleCancelPatchSetReview = () => {
    setActiveReviewPatchSet(null);
  };

  // Send prompt to Gemini API with SSE streaming and document context ingestion
  const handleSendPrompt = async (
    promptText: string,
    model: ModelOption,
    thinking: boolean,
    attachedDocs?: IngestedDoc[]
  ) => {
    const correlationId = `req_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const promptStartTime = Date.now();
    const chatEventId = `chat_${correlationId}`;

    recordTimelineEvent({
      id: chatEventId,
      type: 'chat_started',
      category: 'chat',
      status: 'running',
      title: `Chat: ${promptText.slice(0, 40)}`,
      description: promptText.slice(0, 160),
      source: 'chat',
      correlationId,
      metadata: {
        model,
        thinking,
        mode: collaborationMode,
        attachedDocsCount: attachedDocs?.length || 0,
      },
    });

    let displayContent = promptText;
    if (attachedDocs && attachedDocs.length > 0) {
      const docLabels = attachedDocs.map(d => `📁 *${d.name}*`).join(', ');
      displayContent = `> Ingested Context: ${docLabels}\n\n${promptText}`;
    }

    const userMsg: Message = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: displayContent,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setIsStreaming(true);
    setActiveThought(null);

    const assistantMsgId = `ast_${Date.now()}`;
    let accumulatedContent = '';

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptText,
          model,
          thinking,
          mode: collaborationMode,
          history: messages.map(m => ({ role: m.role, text: m.content })),
          attachedDocuments: attachedDocs,
        }),
      });

      if (!res.ok || !res.body) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const block of lines) {
          const eventMatch = block.match(/event:\s*([^\n]+)/);
          const dataMatch = block.match(/data:\s*([^\n]+)/);

          if (eventMatch && dataMatch) {
            const eventType = eventMatch[1].trim();
            const data = JSON.parse(dataMatch[1].trim());

            if (eventType === 'thought') {
              setActiveThought(data.text);
            } else if (eventType === 'delta') {
              accumulatedContent += data.delta;
              updateAssistantMessage(assistantMsgId, accumulatedContent, thinking, model);
            } else if (eventType === 'answer') {
              accumulatedContent = data.text;
              updateAssistantMessage(assistantMsgId, accumulatedContent, thinking, model);
            } else if (eventType === 'error') {
              setIsStreaming(false);
              setActiveThought(null);
              const errMsg = data?.message || 'Gemini stream encountered an error';
              updateAssistantMessage(assistantMsgId, `⚠️ **API Notice:** ${errMsg}`, thinking, model);

              recordTimelineEvent({
                id: chatEventId,
                type: 'chat_failed',
                category: 'error',
                status: 'failed',
                title: `Chat Failed: ${promptText.slice(0, 35)}`,
                error: errMsg,
                source: 'gemini',
                correlationId,
                durationMs: Date.now() - promptStartTime,
              });
            } else if (eventType === 'done') {
              setIsStreaming(false);
              setActiveThought(null);

              const duration = Date.now() - promptStartTime;
              const extractedPatches = extractPatchesFromMessage(accumulatedContent);

              recordTimelineEvent({
                id: chatEventId,
                type: 'chat_completed',
                category: 'chat',
                status: 'completed',
                title: `Chat Completed: ${promptText.slice(0, 35)} (${duration}ms)`,
                description: accumulatedContent.slice(0, 150),
                source: 'gemini',
                correlationId,
                durationMs: duration,
                metadata: {
                  model,
                  extractedPatchesCount: extractedPatches.length,
                },
              });

              if (extractedPatches.length > 0) {
                extractedPatches.forEach(p => {
                  recordTimelineEvent({
                    id: `patch_${p.patchId}`,
                    type: 'patch_proposed',
                    category: 'patch',
                    status: 'pending',
                    title: `Patch Proposed: ${p.path}`,
                    description: p.explanation || 'Agent produced structured patch.',
                    filePath: p.path,
                    patchId: p.patchId,
                    source: 'gemini',
                    correlationId,
                  });
                });
              }

              // Auto-speak reply if audio enabled
              if (!isAudioMuted && accumulatedContent) {
                playTTS(accumulatedContent);
              }
            }
          }
        }
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      setIsStreaming(false);
      setActiveThought(null);
      const duration = Date.now() - promptStartTime;
      updateAssistantMessage(
        assistantMsgId,
        `⚠️ **Execution Notice:** ${err?.message || 'Could not communicate with backend service.'}`,
        thinking,
        model
      );

      recordTimelineEvent({
        id: chatEventId,
        type: 'chat_failed',
        category: 'error',
        status: 'failed',
        title: `Chat Request Failed: ${promptText.slice(0, 30)}`,
        error: err?.message || 'Failed to complete request',
        source: 'chat',
        correlationId,
        durationMs: duration,
      });
    }
  };

  const updateAssistantMessage = (
    id: string,
    content: string,
    isHighThinking: boolean,
    modelUsed: string
  ) => {
    setMessages(prev => {
      const idx = prev.findIndex(m => m.id === id);
      const newMsg: Message = {
        id,
        role: 'assistant',
        content,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isHighThinking,
        modelUsed,
      };
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = newMsg;
        return copy;
      }
      return [...prev, newMsg];
    });
  };

  // Layout Cycle
  const handleCycleLayout = () => {
    if (layoutMode === 'default') {
      setLayoutMode('editor-wide');
      setIsInspectorOpen(true);
      setIsSidebarOpen(false);
    } else if (layoutMode === 'editor-wide') {
      setLayoutMode('focus-chat');
      setIsInspectorOpen(false);
      setIsSidebarOpen(true);
    } else {
      setLayoutMode('default');
      setIsInspectorOpen(true);
      setIsSidebarOpen(true);
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0d0f17] text-gray-300 font-mono text-sm overflow-hidden selection:bg-blue-500/30">
      
      {/* Top Window Bar */}
      <WindowBar
        onNewChat={() => setMessages([])}
        onOpenSkills={() => setSkillsModalOpen(true)}
        onToggleSidebar={() => setIsSidebarOpen(prev => !prev)}
        onToggleInspector={() => setIsInspectorOpen(prev => !prev)}
      />

      {/* Main Workspace Body */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* Region 1: Left Navigation Sidebar */}
        <LeftSidebar
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          onNewChat={() => setMessages([])}
          onOpenSearch={() => setSearchModalOpen(true)}
          onOpenPRs={() => setPrsModalOpen(true)}
          onOpenScheduled={() => setScheduledModalOpen(true)}
          onOpenSkills={() => setSkillsModalOpen(true)}
          activeProject={activeProject}
          onSelectProject={(p) => setActiveProject(p)}
          onOpenHelp={() => setHelpModalOpen(true)}
          selectedDriveFileId={selectedDriveFile?.id}
          onSelectDriveFile={(file) => {
            setSelectedDriveFile(file);
            setIsInspectorOpen(true);
          }}
        />

        {/* Region 2 & 3: Center Workspace & Floating Prompt Dock */}
        <div className="flex-1 flex flex-col relative overflow-hidden">
          <CenterWorkspace
            isSidebarOpen={isSidebarOpen}
            onToggleSidebar={() => setIsSidebarOpen(true)}
            isInspectorOpen={isInspectorOpen}
            onToggleInspector={() => setIsInspectorOpen(true)}
            onShare={() => setShareModalOpen(true)}
            onLayoutChange={handleCycleLayout}
            messages={messages}
            isStreaming={isStreaming}
            activeThought={activeThought}
            onPlayTTS={playTTS}
            isAudioPlaying={isAudioPlaying}
            collaborationMode={collaborationMode}
            onSwitchMode={handleSwitchMode}
            planningPhase={planningPhase}
            planObjective={planObjective}
            activeAgent={activeAgent}
            onSelectAgent={setActiveAgent}
            agents={agents}
            agentMessages={agentMessages}
            onAddAgentMessage={handleAddAgentMessage}
            onApproveAgentMessage={handleApproveAgentMessage}
            onOpenCommandPalette={() => setCommandPaletteOpen(true)}
            onOpenPatchReview={handleOpenPatchReview}
            onApprovePatch={handleApprovePatch}
            onRejectPatch={handleRejectPatch}
            onOpenPatchSetReview={handleOpenPatchSetReview}
            onApprovePatchSet={handleApprovePatchSet}
            onRejectPatchSet={handleRejectPatchSet}
            pendingPatchStatusMap={pendingPatchStatusMap}
            files={files}
            onRecordTelemetry={recordTimelineEvent}
            onRecordCommandEvent={(evt) => recordTimelineEvent({ source: 'terminal', ...evt })}
            isTerminalOpen={isTerminalOpen}
            onSetTerminalOpen={setIsTerminalOpen}
          />

          {/* Floating Audio Waveform Visualizer */}
          {(isAudioPlaying || isListening || showWaveformOverlay) && (
            <div className="absolute top-4 right-4 z-40 w-80 shadow-2xl animate-in fade-in slide-in-from-top-4 duration-200">
              <AudioWaveformVisualizer
                isPlaying={isAudioPlaying}
                isListening={isListening}
                selectedVoice={selectedVoice}
                onSelectVoice={setSelectedVoice}
                playbackRate={playbackRate}
                onSelectRate={setPlaybackRate}
                onTogglePlay={() => {
                  if (currentAudioRef.current) {
                    if (isAudioPlaying) {
                      currentAudioRef.current.pause();
                      setIsAudioPlaying(false);
                    } else {
                      currentAudioRef.current.play();
                      setIsAudioPlaying(true);
                    }
                  }
                }}
                onStop={() => {
                  if (currentAudioRef.current) {
                    currentAudioRef.current.pause();
                    currentAudioRef.current.currentTime = 0;
                  }
                  setIsAudioPlaying(false);
                  setShowWaveformOverlay(false);
                }}
                onClose={() => setShowWaveformOverlay(false)}
              />
            </div>
          )}

          {/* Region 3: Centered Floating Prompt Input Dock */}
          <FloatingPromptDock
            onSend={handleSendPrompt}
            isStreaming={isStreaming}
            selectedModel={selectedModel}
            onSelectModel={setSelectedModel}
            isThinkingMode={isThinkingMode}
            onToggleThinking={() => setIsThinkingMode(prev => !prev)}
            onOpenSkills={() => setSkillsModalOpen(true)}
            isListening={isListening}
            onToggleVoice={toggleVoice}
            transcript={transcript}
            isAudioMuted={isAudioMuted}
            onToggleAudioMute={() => setIsAudioMuted(prev => !prev)}
          />
        </div>

        {/* Region 4: Right Inspector & Code Editor */}
        <RightInspector
          isOpen={isInspectorOpen}
          onClose={() => setIsInspectorOpen(false)}
          files={files}
          tabs={tabs}
          activeTabId={activeTabId}
          onSelectTab={setActiveTabId}
          onCloseTab={handleCloseTab}
          onNewTab={handleNewTab}
          onOpenFile={handleOpenFile}
          uiMode={collaborationMode}
          selectedDriveFile={selectedDriveFile}
          onUpdateTabContent={(tabId, newContent) => {
            setTabs(prev => prev.map(t => (t.id === tabId ? { ...t, content: newContent } : t)));
          }}
          activeReviewPatch={activeReviewPatch}
          activeReviewPatchSet={activeReviewPatchSet}
          onApprovePatch={handleApprovePatch}
          onRejectPatch={handleRejectPatch}
          onApprovePatchSet={handleApprovePatchSet}
          onRejectPatchSet={handleRejectPatchSet}
          onCancelReview={handleCancelReview}
          onCancelPatchSetReview={handleCancelPatchSetReview}
          timelineEvents={timelineEvents}
          onClearTimelineEvents={clearTimelineEvents}
          onOpenPatchReview={handleOpenPatchReview}
          onOpenPatchSetReview={handleOpenPatchSetReview}
          onFocusTerminal={() => setIsTerminalOpen(true)}
        />

      </div>

      {/* Interactive Desktop Modals */}
      <SkillsModal
        isOpen={skillsModalOpen}
        onClose={() => setSkillsModalOpen(false)}
        onApplySkill={(skillName) => {
          setSelectedModel('Gemini 3.1 Pro (High Thinking)');
          setIsThinkingMode(true);
        }}
      />

      <PullRequestsModal
        isOpen={prsModalOpen}
        onClose={() => setPrsModalOpen(false)}
      />

      <ScheduledModal
        isOpen={scheduledModalOpen}
        onClose={() => setScheduledModalOpen(false)}
      />

      <QuickSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        files={files}
        onSelectFile={handleOpenFile}
      />

      <ShareModal
        isOpen={shareModalOpen}
        onClose={() => setShareModalOpen(false)}
      />

      <HelpModal
        isOpen={helpModalOpen}
        onClose={() => setHelpModalOpen(false)}
      />

      {/* Global Command Palette (Ctrl+K) */}
      <CommandPaletteModal
        isOpen={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        collaborationMode={collaborationMode}
        onSwitchMode={handleSwitchMode}
        activeAgent={activeAgent}
        onSelectAgent={setActiveAgent}
        onOpenFileByPath={handleOpenFileByPath}
        isThinkingMode={isThinkingMode}
        onToggleThinking={() => setIsThinkingMode(prev => !prev)}
        isAudioMuted={isAudioMuted}
        onToggleAudioMute={() => setIsAudioMuted(prev => !prev)}
        onRunTests={handleRunCargoTests}
        onOpenQuickSearch={() => setSearchModalOpen(true)}
      />

    </div>
  );
}
