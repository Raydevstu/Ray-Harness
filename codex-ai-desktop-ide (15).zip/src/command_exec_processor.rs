//! `command_exec_processor.rs`
//! High-performance Rust command execution processor for Jarvis & Codex Agent Harness.
//!
//! Provides AST pipeline parsing, safety policy verification, sandboxed subprocess
//! management, and structured stdout/stderr streaming for agent tools and IDE operations.

use std::collections::HashMap;
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CommandSafetyTier {
    SafeReadOnly,
    WorkspaceModifying,
    DangerousNetworkOrSystem,
    Blocked,
}

#[derive(Debug, Clone)]
pub struct CommandPolicy {
    pub allow_network: bool,
    pub timeout_seconds: u64,
    pub max_output_bytes: usize,
    pub allowed_bins: Vec<String>,
    pub blocked_patterns: Vec<String>,
}

impl Default for CommandPolicy {
    fn default() -> Self {
        Self {
            allow_network: false,
            timeout_seconds: 30,
            max_output_bytes: 512 * 1024, // 512 KB
            allowed_bins: vec![
                "cargo".into(),
                "rustc".into(),
                "git".into(),
                "ls".into(),
                "cat".into(),
                "grep".into(),
                "find".into(),
                "echo".into(),
                "node".into(),
                "tsc".into(),
            ],
            blocked_patterns: vec![
                "rm -rf /".into(),
                ":(){ :|:& };:".into(),
                "chmod -R 777 /".into(),
                "mkfs".into(),
                "dd if=".into(),
            ],
        }
    }
}

#[derive(Debug, Clone)]
pub struct ExecutionResult {
    pub exit_code: i32,
    pub stdout: String,
    pub stderr: String,
    pub duration_ms: u128,
    pub is_truncated: bool,
    pub safety_tier: CommandSafetyTier,
}

pub struct CommandExecProcessor {
    policy: CommandPolicy,
    history: Arc<Mutex<Vec<(String, ExecutionResult)>>>,
}

impl CommandExecProcessor {
    pub fn new(policy: CommandPolicy) -> Self {
        Self {
            policy,
            history: Arc::new(Mutex::new(Vec::new())),
        }
    }

    /// Evaluates the safety tier of a raw command line before execution
    pub fn evaluate_safety(&self, raw_cmd: &str) -> CommandSafetyTier {
        let trimmed = raw_cmd.trim();
        if trimmed.is_empty() {
            return CommandSafetyTier::SafeReadOnly;
        }

        for pattern in &self.policy.blocked_patterns {
            if trimmed.contains(pattern) {
                return CommandSafetyTier::Blocked;
            }
        }

        let first_token = trimmed.split_whitespace().next().unwrap_or("");
        if !self.policy.allowed_bins.contains(&first_token.to_string()) {
            return CommandSafetyTier::DangerousNetworkOrSystem;
        }

        if first_token == "cargo" || first_token == "git" || first_token == "tsc" {
            if trimmed.contains("test") || trimmed.contains("check") || trimmed.contains("status") || trimmed.contains("diff") {
                return CommandSafetyTier::SafeReadOnly;
            }
            return CommandSafetyTier::WorkspaceModifying;
        }

        if first_token == "ls" || first_token == "cat" || first_token == "grep" || first_token == "find" {
            return CommandSafetyTier::SafeReadOnly;
        }

        CommandSafetyTier::WorkspaceModifying
    }

    /// Executes a command pipeline with timeout and output truncation safety
    pub fn execute(&self, raw_cmd: &str, cwd: Option<&str>) -> Result<ExecutionResult, String> {
        let safety = self.evaluate_safety(raw_cmd);
        if safety == CommandSafetyTier::Blocked {
            return Err(format!("Command blocked by safety policy: '{}'", raw_cmd));
        }

        let start = Instant::now();
        let tokens: Vec<&str> = raw_cmd.split_whitespace().collect();
        if tokens.is_empty() {
            return Ok(ExecutionResult {
                exit_code: 0,
                stdout: String::new(),
                stderr: String::new(),
                duration_ms: 0,
                is_truncated: false,
                safety_tier: safety,
            });
        }

        let program = tokens[0];
        let args = &tokens[1..];

        let mut cmd = Command::new(program);
        cmd.args(args)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());

        if let Some(dir) = cwd {
            cmd.current_dir(dir);
        }

        let output = match cmd.output() {
            Ok(out) => out,
            Err(e) => {
                return Err(format!("Failed to spawn command '{}': {}", program, e));
            }
        };

        let duration_ms = start.elapsed().as_millis();
        let mut stdout = String::from_utf8_lossy(&output.stdout).to_string();
        let mut stderr = String::from_utf8_lossy(&output.stderr).to_string();
        let mut is_truncated = false;

        if stdout.len() > self.policy.max_output_bytes {
            stdout.truncate(self.policy.max_output_bytes);
            stdout.push_str("\n... [STDOUT TRUNCATED BY PROCESSOR]");
            is_truncated = true;
        }

        if stderr.len() > self.policy.max_output_bytes {
            stderr.truncate(self.policy.max_output_bytes);
            stderr.push_str("\n... [STDERR TRUNCATED BY PROCESSOR]");
            is_truncated = true;
        }

        let result = ExecutionResult {
            exit_code: output.status.code().unwrap_or(-1),
            stdout,
            stderr,
            duration_ms,
            is_truncated,
            safety_tier: safety,
        };

        if let Ok(mut hist) = self.history.lock() {
            hist.push((raw_cmd.to_string(), result.clone()));
        }

        Ok(result)
    }

    /// Ingests document context into unified memory buffer for prompt compilation
    pub fn ingest_document_context(&self, doc_name: &str, content: &str) -> String {
        format!(
            "<!-- DOCUMENT CONTEXT INGESTION: {} -->\n{}\n<!-- END DOCUMENT CONTEXT -->\n",
            doc_name, content
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_safety_evaluation() {
        let processor = CommandExecProcessor::new(CommandPolicy::default());
        assert_eq!(processor.evaluate_safety("cargo check"), CommandSafetyTier::SafeReadOnly);
        assert_eq!(processor.evaluate_safety("rm -rf /"), CommandSafetyTier::Blocked);
        assert_eq!(processor.evaluate_safety("curl https://malicious.com"), CommandSafetyTier::DangerousNetworkOrSystem);
    }

    #[test]
    fn test_document_ingestion() {
        let processor = CommandExecProcessor::new(CommandPolicy::default());
        let doc = processor.ingest_document_context("Spec.pdf", "Architecture overview");
        assert!(doc.contains("DOCUMENT CONTEXT INGESTION: Spec.pdf"));
    }
}
