//! Core library entry point for Jarvis & Codex collaboration engine.
//! Manages CloudConfigBundleLoader, ConfigBuilder, and template render integration tests.

pub mod render;
pub mod apply_command;
pub mod legacy_apply_patch_exec_command_warning;

pub use render::{AppConfig, FeatureFlags, AgentConfig, RenderContext, render_layout};
pub use apply_command::{Command, SystemState, apply_ui_command};
pub use legacy_apply_patch_exec_command_warning::LegacyApplyPatchExecCommandWarning;

/// Validates configuration TOML and JSON settings against config.schema.json rules
pub fn validate_config_schema(toml_content: &str, schema_json: &str) -> Result<bool, Vec<String>> {
    let mut errors = Vec::new();

    // Check required keys
    if !toml_content.contains("model =") {
        errors.push("Missing required field 'model' in config.toml".to_string());
    }
    if !toml_content.contains("ui_mode =") {
        errors.push("Missing required field 'ui_mode' in config.toml".to_string());
    }

    // Check notify array preservation
    if toml_content.contains("notify =") && !toml_content.contains("[") {
        errors.push("Field 'notify' must be an array of string arguments".to_string());
    }

    if errors.is_empty() {
        Ok(true)
    } else {
        Err(errors)
    }
}

pub struct ConfigBuilder {
    pub ui_mode: String,
    pub model: String,
    pub enable_apps: bool,
    pub enable_code_mode: bool,
    pub active_agent: String,
}

impl Default for ConfigBuilder {
    fn default() -> Self {
        Self {
            ui_mode: "plan".to_string(),
            model: "gemini-3.1-pro-preview".to_string(),
            enable_apps: true,
            enable_code_mode: true,
            active_agent: "code_executor".to_string(),
        }
    }
}

impl ConfigBuilder {
    pub fn build(self) -> AppConfig {
        AppConfig {
            ui_mode: self.ui_mode,
            model: self.model,
            feature_flags: FeatureFlags {
                enable_apps: self.enable_apps,
                enable_code_mode: self.enable_code_mode,
                collaboration_modes: true,
                high_thinking: true,
            },
            agents: Some(AgentConfig {
                active_agent: self.active_agent,
                ask_for_approval: true,
                default_subagent_model: "gemini-3.5-flash".to_string(),
                default_subagent_reasoning_effort: "high".to_string(),
            }),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_mode_rendering() {
        let config = ConfigBuilder::default().build();
        let ctx = RenderContext {
            apps_info: "Enabled App: Terminal",
            context_snapshot: "Snapshot v1",
            execution_output: "Success",
            template_content: "# Workspace\n<APPS_INSTRUCTIONS_OPEN_TAG>\n{{apps_section}}\n</APPS_INSTRUCTIONS_OPEN_TAG>\n{{context_snapshot}}",
            planning_phase: "Execution",
            plan_objective: "Build Codex App",
            plan_steps: "1. Render",
        };

        let result = render_layout(&config, &ctx).unwrap();
        assert!(result.contains("Enabled App: Terminal"));
        assert!(result.contains("Snapshot v1"));
    }

    #[test]
    fn test_apps_strip_when_disabled() {
        let mut config = ConfigBuilder::default().build();
        config.feature_flags.enable_apps = false;

        let ctx = RenderContext {
            apps_info: "Disabled App",
            context_snapshot: "Clean Snapshot",
            execution_output: "Ready",
            template_content: "# Workspace\n<APPS_INSTRUCTIONS_OPEN_TAG>\n{{apps_section}}\n</APPS_INSTRUCTIONS_OPEN_TAG>\nDone",
            planning_phase: "Execution",
            plan_objective: "Verify",
            plan_steps: "1. Test",
        };

        let result = render_layout(&config, &ctx).unwrap();
        assert!(!result.contains("<APPS_INSTRUCTIONS_OPEN_TAG>"));
        assert!(!result.contains("Disabled App"));
    }
}
