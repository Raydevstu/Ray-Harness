import { TimelineEvent, TimelineEventCategory, TimelineEventStatus } from '../types';

/**
 * Redacts sensitive strings (API keys, JWTs, bearer tokens, passwords, secrets, cookies, auth headers).
 * Preserves normal file paths, command names, patch IDs, and general error messages.
 */
export function redactSensitiveInfo(input: string): string {
  if (!input || typeof input !== 'string') return '';
  return input
    // Google Gemini API keys
    .replace(/(AIza[0-9A-Za-z-_]{30,})/g, '[REDACTED_GEMINI_KEY]')
    // OpenAI / Anthropic secret keys
    .replace(/(sk-[a-zA-Z0-9_-]{20,})/g, '[REDACTED_SECRET_KEY]')
    // GitHub personal access tokens
    .replace(/(gh[pousr]_[a-zA-Z0-9]{30,})/g, '[REDACTED_GH_TOKEN]')
    // AWS Access Key ID
    .replace(/(AKIA[0-9A-Z]{16})/g, '[REDACTED_AWS_KEY]')
    // Authorization: Bearer <token>
    .replace(/(Authorization\s*:\s*Bearer\s+)[A-Za-z0-9\-._~+/]+=*/gi, '$1[REDACTED_TOKEN]')
    // Authorization: Basic <base64>
    .replace(/(Authorization\s*:\s*Basic\s+)[A-Za-z0-9+/]+=*/gi, '$1[REDACTED_BASIC_AUTH]')
    // Standalone Bearer tokens
    .replace(/(Bearer\s+)[A-Za-z0-9\-._~+/]{15,}=*/gi, '$1[REDACTED_TOKEN]')
    // Standard JWT tokens (header.payload.signature)
    .replace(/(eyJ[a-zA-Z0-9_-]{10,}\.eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_.-]{10,})/g, '[REDACTED_JWT_TOKEN]')
    // Cookie headers and assignments
    .replace(/(Cookie\s*:\s*)([^\r\n;]+)/gi, '$1[REDACTED_COOKIE]')
    .replace(/(set-cookie\s*:\s*)([^\r\n;]+)/gi, '$1[REDACTED_COOKIE]')
    // Key/secret/password/token parameter assignments (e.g. password="foo", api_key=bar, token: 'xyz')
    .replace(
      /(password|passwd|secret|client_secret|apiKey|api_key|access_token|refresh_token|auth_token|private_key)\s*([:=])\s*["']?([^"',\s;\r\n]+)["']?/gi,
      '$1$2"[REDACTED]"'
    )
    // Environment variable exports (e.g. export GEMINI_API_KEY=..., API_SECRET=...)
    .replace(
      /(export\s+[A-Z0-9_]*(KEY|SECRET|TOKEN|PASSWORD|AUTH)[A-Z0-9_]*\s*=\s*)["']?([^"',\s;\r\n]+)["']?/gi,
      '$1"[REDACTED]"'
    );
}

/**
 * Recursively sanitizes metadata payload to ensure no sensitive fields leak into logs or telemetry views.
 * Guarded against circular references and unexpected metadata structures.
 */
export function sanitizeMetadata(
  metadata?: Record<string, unknown>,
  seen = new WeakSet<object>()
): Record<string, unknown> | undefined {
  if (!metadata || typeof metadata !== 'object') return undefined;
  if (seen.has(metadata)) {
    return { '[Circular]': true };
  }
  seen.add(metadata);

  const sanitized: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(metadata)) {
    const lowerKey = key.toLowerCase();
    if (
      lowerKey.includes('key') ||
      lowerKey.includes('secret') ||
      lowerKey.includes('token') ||
      lowerKey.includes('auth') ||
      lowerKey.includes('password') ||
      lowerKey.includes('cookie') ||
      lowerKey.includes('credential') ||
      lowerKey.includes('cert')
    ) {
      sanitized[key] = '[REDACTED]';
    } else if (typeof value === 'string') {
      sanitized[key] = redactSensitiveInfo(value);
    } else if (Array.isArray(value)) {
      sanitized[key] = value.map(item => {
        if (typeof item === 'string') return redactSensitiveInfo(item);
        if (typeof item === 'object' && item !== null) {
          return sanitizeMetadata(item as Record<string, unknown>, seen);
        }
        return item;
      });
    } else if (typeof value === 'object' && value !== null) {
      sanitized[key] = sanitizeMetadata(value as Record<string, unknown>, seen);
    } else {
      sanitized[key] = value;
    }
  }

  return sanitized;
}

/**
 * Initial boot events for Ray Harness session with stable timestamps.
 */
const now = Date.now();
export const INITIAL_TIMELINE_EVENTS: TimelineEvent[] = [
  {
    id: 'evt_sys_boot_001',
    createdAt: now - 360000,
    timestamp: new Date(now - 360000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    type: 'system_init',
    category: 'system',
    status: 'completed',
    title: 'Workspace Initialized',
    description: 'Ray Harness runtime mounted with 4 agent threads and local AST patch interception.',
    source: 'system',
    durationMs: 45,
    metadata: {
      activeProject: 'jarvis-app',
      nodeEnv: 'production',
      sandboxMode: 'local_isolated',
    },
  },
  {
    id: 'evt_agent_sub_002',
    createdAt: now - 300000,
    timestamp: new Date(now - 300000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    type: 'agent_started',
    category: 'agent',
    status: 'completed',
    title: 'Agent Swarm Online',
    description: 'Synchronized roles: code_executor, architect, reviewer, and collaborator.',
    source: 'agent',
    durationMs: 120,
    metadata: {
      concurrency: 4,
      model: 'gemini-3.1-pro-preview',
    },
  },
];
