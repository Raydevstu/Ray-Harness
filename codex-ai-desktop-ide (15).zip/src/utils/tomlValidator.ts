// Live TOML Schema & AST Validator against config.schema.json

export interface TomlDiagnostic {
  id: string;
  line: number;
  column?: number;
  severity: 'error' | 'warning' | 'info';
  message: string;
  key?: string;
  suggestion?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errorCount: number;
  warningCount: number;
  diagnostics: TomlDiagnostic[];
  parsedKeys: Record<string, any>;
}

export function validateTomlConfig(tomlText: string): ValidationResult {
  const diagnostics: TomlDiagnostic[] = [];
  const lines = tomlText.split('\n');
  const parsedKeys: Record<string, any> = {};

  let currentSection = '';

  lines.forEach((line, index) => {
    const lineNum = index + 1;
    const trimmed = line.trim();

    // Skip comments and empty lines
    if (!trimmed || trimmed.startsWith('#')) {
      return;
    }

    // Section header [section]
    if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
      currentSection = trimmed.slice(1, -1).trim();
      return;
    }

    // Key-value pair
    const eqIndex = trimmed.indexOf('=');
    if (eqIndex === -1) {
      diagnostics.push({
        id: `syntax_${lineNum}`,
        line: lineNum,
        severity: 'error',
        message: `Invalid TOML statement: Expected 'key = value' assignment.`,
      });
      return;
    }

    const rawKey = trimmed.slice(0, eqIndex).trim();
    const rawVal = trimmed.slice(eqIndex + 1).trim();
    const fullKeyPath = currentSection ? `${currentSection}.${rawKey}` : rawKey;

    // Parse simple primitives
    let parsedVal: any = rawVal;
    if (rawVal === 'true') parsedVal = true;
    else if (rawVal === 'false') parsedVal = false;
    else if (/^\d+$/.test(rawVal)) parsedVal = parseInt(rawVal, 10);
    else if (rawVal.startsWith('"') && rawVal.endsWith('"')) {
      parsedVal = rawVal.slice(1, -1);
    } else if (rawVal.startsWith('[') && rawVal.endsWith(']')) {
      try {
        parsedVal = JSON.parse(rawVal.replace(/'/g, '"'));
      } catch {
        parsedVal = rawVal;
      }
    }

    parsedKeys[fullKeyPath] = parsedVal;

    // 1. Validate ui_mode enum
    if (fullKeyPath === 'ui_mode') {
      const validModes = ['default', 'plan', 'agent'];
      if (typeof parsedVal !== 'string' || !validModes.includes(parsedVal)) {
        diagnostics.push({
          id: `enum_ui_mode_${lineNum}`,
          line: lineNum,
          severity: 'error',
          key: 'ui_mode',
          message: `Invalid ui_mode: "${parsedVal}". Allowed values are: 'default', 'plan', 'agent'.`,
          suggestion: 'ui_mode = "plan"',
        });
      }
    }

    // 2. Validate model_reasoning_effort enum
    if (fullKeyPath === 'model_reasoning_effort' || fullKeyPath === 'plan_mode_reasoning_effort') {
      const validEfforts = ['low', 'medium', 'high'];
      if (typeof parsedVal !== 'string' || !validEfforts.includes(parsedVal)) {
        diagnostics.push({
          id: `enum_effort_${lineNum}`,
          line: lineNum,
          severity: 'error',
          key: fullKeyPath,
          message: `Invalid reasoning effort: "${parsedVal}". Allowed: 'low', 'medium', 'high'.`,
          suggestion: `${rawKey} = "high"`,
        });
      }
    }

    // 3. Validate approval_policy enum
    if (fullKeyPath === 'approval_policy') {
      const validPolicies = ['on-request', 'never', 'granular'];
      if (typeof parsedVal !== 'string' || !validPolicies.includes(parsedVal)) {
        diagnostics.push({
          id: `enum_policy_${lineNum}`,
          line: lineNum,
          severity: 'warning',
          key: 'approval_policy',
          message: `Unknown approval_policy "${parsedVal}". Standard values: 'on-request', 'never', 'granular'.`,
          suggestion: 'approval_policy = "on-request"',
        });
      }
    }

    // 4. Validate notify array order preservation
    if (fullKeyPath === 'notify') {
      if (!Array.isArray(parsedVal)) {
        diagnostics.push({
          id: `type_notify_${lineNum}`,
          line: lineNum,
          severity: 'error',
          key: 'notify',
          message: `Field 'notify' must be an array of strings per schema.`,
          suggestion: 'notify = ["terminal-notifier", "-title", "Codex IDE"]',
        });
      }
    }

    // 5. Validate boolean flags in feature_flags
    if (currentSection === 'feature_flags') {
      if (typeof parsedVal !== 'boolean') {
        diagnostics.push({
          id: `type_feature_flag_${lineNum}`,
          line: lineNum,
          severity: 'warning',
          key: fullKeyPath,
          message: `Feature flag '${rawKey}' should be a boolean (true/false).`,
          suggestion: `${rawKey} = true`,
        });
      }
    }

    // 6. Validate agents.max_concurrent_threads_per_session bounds
    if (fullKeyPath === 'agents.max_concurrent_threads_per_session') {
      if (typeof parsedVal === 'number' && (parsedVal < 1 || parsedVal > 64)) {
        diagnostics.push({
          id: `bound_threads_${lineNum}`,
          line: lineNum,
          severity: 'warning',
          key: fullKeyPath,
          message: `Thread concurrency (${parsedVal}) outside recommended range 1..64.`,
          suggestion: 'max_concurrent_threads_per_session = 8',
        });
      }
    }
  });

  // Check Schema Required Fields
  if (!('ui_mode' in parsedKeys)) {
    diagnostics.unshift({
      id: 'req_ui_mode',
      line: 1,
      severity: 'error',
      key: 'ui_mode',
      message: `Missing required schema field: 'ui_mode'.`,
      suggestion: 'ui_mode = "plan"',
    });
  }

  const hasFeatureFlags = Object.keys(parsedKeys).some(k => k.startsWith('feature_flags.'));
  if (!hasFeatureFlags) {
    diagnostics.push({
      id: 'req_feature_flags',
      line: 1,
      severity: 'error',
      key: 'feature_flags',
      message: `Missing required schema section: '[feature_flags]'.`,
      suggestion: '[feature_flags]\nenable_apps = true\nenable_code_mode = true',
    });
  }

  const errorCount = diagnostics.filter(d => d.severity === 'error').length;
  const warningCount = diagnostics.filter(d => d.severity === 'warning').length;

  return {
    isValid: errorCount === 0,
    errorCount,
    warningCount,
    diagnostics,
    parsedKeys,
  };
}

export function generateCanonicalToml(): string {
  return `# Codex & Jarvis Collaboration Config
# Array order for notify and args is preserved per schema rules.

model = "gemini-3.1-pro-preview"
model_provider = "google"
model_reasoning_effort = "high"
plan_mode_reasoning_effort = "high"

ui_mode = "plan"
approval_policy = "on-request"
approvals_reviewer = "user"

notify = ["terminal-notifier", "-title", "Codex IDE", "-sound", "Tink"]

[feature_flags]
enable_apps = true
enable_code_mode = true
collaboration_modes = true
high_thinking = true

[features]
collaboration_modes = true
code_mode = true
apps = true
fast_mode = false
guardian_approval = true

[agents]
enabled = true
active_agent = "code_executor"
ask_for_approval = true
default_subagent_model = "gemini-3.5-flash"
default_subagent_reasoning_effort = "high"
max_concurrent_threads_per_session = 8

[apps]
enabled = true
destructive_enabled = false
open_world_enabled = true

[apps._default]
enabled = true
destructive_enabled = false
default_tools_approval_mode = "auto"
approvals_reviewer = "user"

[tui]
animations = true
theme = "deepseek-dark"
vim_mode_default = false
notifications = true
notification_condition = "unfocused"

[tui.rendering]
math = true
mermaid = true
tables = true
`;
}
