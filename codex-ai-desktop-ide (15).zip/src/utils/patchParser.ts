import { FilePatch, FilePatchSet, TabItem, FileItem } from '../types';

/**
 * Validates whether an object strictly adheres to the FilePatch contract
 */
export function isValidFilePatch(obj: any): obj is FilePatch {
  if (!obj || typeof obj !== 'object') return false;
  return (
    obj.type === 'file_patch' &&
    typeof obj.patchId === 'string' &&
    obj.patchId.trim().length > 0 &&
    typeof obj.path === 'string' &&
    obj.path.trim().length > 0 &&
    typeof obj.originalContent === 'string' &&
    typeof obj.proposedContent === 'string'
  );
}

/**
 * Validates whether an object strictly adheres to the FilePatchSet contract
 */
export function isValidFilePatchSet(obj: any): obj is FilePatchSet {
  if (!obj || typeof obj !== 'object') return false;
  if (obj.type !== 'file_patch_set') return false;
  if (typeof obj.patchSetId !== 'string' || obj.patchSetId.trim().length === 0) return false;
  if (typeof obj.description !== 'string') return false;
  if (!Array.isArray(obj.patches) || obj.patches.length === 0) return false;

  for (const patch of obj.patches) {
    if (!isValidFilePatch(patch)) return false;
  }

  return true;
}

/**
 * Validates a patch set against current in-memory workspace buffers.
 * Checks for duplicate patch IDs, duplicate file paths, invalid parameters, and stale buffer state.
 */
export function validatePatchSet(
  patchSet: FilePatchSet,
  currentTabs: TabItem[] = [],
  currentFiles: FileItem[] = []
): { valid: boolean; error?: string; isStale?: boolean; invalidPath?: string } {
  if (!isValidFilePatchSet(patchSet)) {
    return { valid: false, error: 'Malformed or incomplete patch set structure.' };
  }

  const patchIds = new Set<string>();
  const filePaths = new Set<string>();

  for (const patch of patchSet.patches) {
    // Rule 1: Valid path
    if (!patch.path || typeof patch.path !== 'string' || patch.path.trim().length === 0) {
      return { valid: false, error: `Invalid path in patch ${patch.patchId || 'unknown'}` };
    }

    // Rule 2: Unique patch ID within set
    if (patchIds.has(patch.patchId)) {
      return { valid: false, error: `Duplicate patch ID '${patch.patchId}' found in patch set.` };
    }
    patchIds.add(patch.patchId);

    // Rule 3: No duplicate file paths within set
    if (filePaths.has(patch.path)) {
      return { valid: false, error: `Duplicate target file path '${patch.path}' found in patch set.` };
    }
    filePaths.add(patch.path);

    // Rule 4: Proposed content must be a valid string
    if (typeof patch.proposedContent !== 'string') {
      return { valid: false, error: `Proposed content for '${patch.path}' is invalid.` };
    }

    // Rule 5: Approval-gated
    if (patch.requiresApproval === false) {
      return { valid: false, error: `Patch '${patch.patchId}' for '${patch.path}' attempts to bypass human approval.` };
    }

    // Rule 6: Stale buffer detection
    // Check against current open tab or workspace file if originalContent is provided
    const matchingTab = currentTabs.find(t => t.path === patch.path || t.name === patch.path.split('/').pop());
    if (matchingTab && patch.originalContent !== undefined) {
      if (matchingTab.content !== patch.originalContent) {
        return {
          valid: false,
          isStale: true,
          invalidPath: patch.path,
          error: `Buffer for '${patch.path}' was modified since patch set creation (Stale Original Content).`,
        };
      }
    }
  }

  return { valid: true };
}

/**
 * Transactional atomic in-memory application of a patch set.
 * Validates all patches first. If all pass, updates candidate tabs in a single atomic operation.
 * If any patch fails, abandons candidate state and returns original tabs untouched.
 */
export function applyPatchSetAtomically(
  patchSet: FilePatchSet,
  currentTabs: TabItem[],
  currentFiles: FileItem[] = []
): { success: boolean; updatedTabs: TabItem[]; error?: string; appliedCount: number } {
  // Step 1: Validate entire patch set before modifying anything
  const validation = validatePatchSet(patchSet, currentTabs, currentFiles);
  if (!validation.valid) {
    return {
      success: false,
      updatedTabs: currentTabs,
      error: validation.error || 'Patch set validation failed.',
      appliedCount: 0,
    };
  }

  // Step 2: Create a candidate copy of the current tabs
  const candidateTabs = [...currentTabs];

  // Step 3: Apply every patch to candidate state
  for (const patch of patchSet.patches) {
    const existingIdx = candidateTabs.findIndex(
      t => t.path === patch.path || t.name === patch.path.split('/').pop()
    );

    if (existingIdx >= 0) {
      candidateTabs[existingIdx] = {
        ...candidateTabs[existingIdx],
        content: patch.proposedContent,
        isModified: true,
      };
    } else {
      const fileName = patch.path.split('/').pop() || 'file';
      const ext = fileName.split('.').pop() || 'text';
      let lang = 'text';
      if (ext === 'rs') lang = 'rust';
      else if (ext === 'toml') lang = 'toml';
      else if (ext === 'json') lang = 'json';
      else if (ext === 'md') lang = 'markdown';
      else if (ext === 'ts' || ext === 'tsx') lang = 'typescript';

      candidateTabs.push({
        id: `tab_patch_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: fileName,
        path: patch.path,
        language: lang,
        content: patch.proposedContent,
        isModified: true,
      });
    }
  }

  // Step 4: Atomic commit
  return {
    success: true,
    updatedTabs: candidateTabs,
    appliedCount: patchSet.patches.length,
  };
}

/**
 * Extracts structured FilePatch objects from a markdown message or assistant payload
 */
export function extractPatchesFromMessage(content: string): FilePatch[] {
  if (!content) return [];
  const patches: FilePatch[] = [];

  // Pattern 1: Explicit JSON block ```json or ```json:patch containing { "type": "file_patch", ... }
  const jsonBlockRegex = /```(?:json|json:patch)?\s*\n([\s\S]*?)\n```/g;
  let match;

  while ((match = jsonBlockRegex.exec(content)) !== null) {
    const rawJson = match[1].trim();
    if (rawJson.startsWith('{') && rawJson.includes('"file_patch"')) {
      try {
        const parsed = JSON.parse(rawJson);
        if (isValidFilePatch(parsed)) {
          patches.push(parsed);
        }
      } catch {
        // Silently skip malformed JSON blocks
      }
    }
  }

  // Pattern 2: Raw embedded JSON object matching file_patch structure
  if (patches.length === 0 && content.includes('"type": "file_patch"') || content.includes('"type":"file_patch"')) {
    try {
      const startIdx = content.indexOf('{');
      const endIdx = content.lastIndexOf('}');
      if (startIdx >= 0 && endIdx > startIdx) {
        const candidate = content.slice(startIdx, endIdx + 1);
        const parsed = JSON.parse(candidate);
        if (isValidFilePatch(parsed)) {
          patches.push(parsed);
        }
      }
    } catch {
      // Ignored
    }
  }

  return patches;
}

/**
 * Calculates line addition and deletion counts between original and proposed content
 */
export function computeDiffStats(original: string, proposed: string): { additions: number; deletions: number } {
  const origLines = original.split('\n');
  const propLines = proposed.split('\n');

  // Simple heuristic line diff count
  const origSet = new Set(origLines);
  const propSet = new Set(propLines);

  let additions = 0;
  let deletions = 0;

  for (const line of propLines) {
    if (!origSet.has(line)) additions++;
  }
  for (const line of origLines) {
    if (!propSet.has(line)) deletions++;
  }

  return {
    additions: Math.max(1, additions),
    deletions: Math.max(0, deletions),
  };
}
