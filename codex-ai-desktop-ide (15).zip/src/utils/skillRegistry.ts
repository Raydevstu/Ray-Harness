import { AgentSkill, AgentTool, AgentRole, AgentPermissionLevel } from '../types';

export const INITIAL_SKILLS: AgentSkill[] = [
  {
    id: 'workspace_inspection',
    name: 'Workspace Inspector',
    version: '1.0.0',
    description: 'Inspect workspace structure, list files, and view project metadata.',
    category: 'inspection',
    requiredPermission: 'read_only',
    requiresApproval: false,
    allowedRoles: ['code_executor', 'architect', 'reviewer', 'collaborator'],
    status: 'approved',
    tools: [
      {
        id: 'list_workspace_files',
        name: 'List Workspace Files',
        description: 'Enumerates all files and directories in the current workspace.',
        permissionLevel: 'read_only',
        requiresApproval: false,
        isMutating: false,
        parameters: [],
      },
      {
        id: 'get_project_summary',
        name: 'Get Project Summary',
        description: 'Retrieves workspace branch, active project name, and file counts.',
        permissionLevel: 'read_only',
        requiresApproval: false,
        isMutating: false,
        parameters: [],
      },
    ],
  },
  {
    id: 'file_reader',
    name: 'File Reader',
    version: '1.2.0',
    description: 'Read contents of specific files in the workspace with safety bounds.',
    category: 'filesystem',
    requiredPermission: 'read_only',
    requiresApproval: false,
    allowedRoles: ['code_executor', 'architect', 'reviewer', 'collaborator'],
    status: 'approved',
    tools: [
      {
        id: 'read_file_content',
        name: 'Read File Content',
        description: 'Reads text content of a file given its relative path.',
        permissionLevel: 'read_only',
        requiresApproval: false,
        isMutating: false,
        parameters: [
          {
            name: 'filePath',
            type: 'string',
            description: 'Relative path of the target file',
            required: true,
          },
        ],
      },
    ],
  },
  {
    id: 'workspace_search',
    name: 'Codebase Search',
    version: '1.1.0',
    description: 'Search across workspace files for keywords, functions, or patterns.',
    category: 'filesystem',
    requiredPermission: 'read_only',
    requiresApproval: false,
    allowedRoles: ['code_executor', 'architect', 'reviewer', 'collaborator'],
    status: 'approved',
    tools: [
      {
        id: 'search_codebase',
        name: 'Search Codebase',
        description: 'Searches all text files for a query string.',
        permissionLevel: 'read_only',
        requiresApproval: false,
        isMutating: false,
        parameters: [
          {
            name: 'query',
            type: 'string',
            description: 'Search string or keyword',
            required: true,
          },
        ],
      },
    ],
  },
  {
    id: 'config_validator',
    name: 'TOML / Config Validator',
    version: '2.0.0',
    description: 'Validate config.toml against config.schema.json rules.',
    category: 'validation',
    requiredPermission: 'read_only',
    requiresApproval: false,
    allowedRoles: ['architect', 'reviewer', 'collaborator'],
    status: 'approved',
    tools: [
      {
        id: 'validate_toml_config',
        name: 'Validate TOML Config',
        description: 'Validates raw TOML text or workspace config against schema.',
        permissionLevel: 'read_only',
        requiresApproval: false,
        isMutating: false,
        parameters: [
          {
            name: 'content',
            type: 'string',
            description: 'Optional TOML string content to validate',
            required: false,
          },
        ],
      },
    ],
  },
  {
    id: 'patch_proposer',
    name: 'Patch Proposer',
    version: '1.5.0',
    description: 'Propose structured file diff patches. Requires explicit user approval.',
    category: 'patching',
    requiredPermission: 'workspace_write',
    requiresApproval: true,
    allowedRoles: ['code_executor', 'architect', 'collaborator', 'reviewer'],
    status: 'approved',
    tools: [
      {
        id: 'propose_file_patch',
        name: 'Propose File Patch',
        description: 'Creates a proposed diff patch for user review and approval.',
        permissionLevel: 'workspace_write',
        requiresApproval: true,
        isMutating: true,
        parameters: [
          {
            name: 'filePath',
            type: 'string',
            description: 'Path of file to patch',
            required: true,
          },
          {
            name: 'proposedContent',
            type: 'string',
            description: 'New proposed text content',
            required: true,
          },
          {
            name: 'explanation',
            type: 'string',
            description: 'Explanation of changes',
            required: false,
          },
        ],
      },
      {
        id: 'propose_patch_set',
        name: 'Propose Multi-File Patch Set',
        description: 'Creates a multi-file patch set for atomic human review and commit.',
        permissionLevel: 'workspace_write',
        requiresApproval: true,
        isMutating: true,
        parameters: [
          {
            name: 'description',
            type: 'string',
            description: 'Overview of multi-file changes',
            required: true,
          },
          {
            name: 'patches',
            type: 'array',
            description: 'Array of patch objects { filePath, proposedContent, explanation? }',
            required: true,
          },
        ],
      },
    ],
  },
  {
    id: 'terminal_execution',
    name: 'Terminal Command Execution',
    version: '1.3.0',
    description: 'Run safe shell commands in the workspace terminal environment.',
    category: 'terminal',
    requiredPermission: 'terminal_safe',
    requiresApproval: false,
    allowedRoles: ['code_executor', 'collaborator'],
    status: 'approved',
    tools: [
      {
        id: 'execute_terminal_command',
        name: 'Execute Terminal Command',
        description: 'Dispatches a safe shell command to the workspace terminal.',
        permissionLevel: 'terminal_safe',
        requiresApproval: false,
        isMutating: false,
        parameters: [
          {
            name: 'command',
            type: 'string',
            description: 'Shell command string (e.g. ls, cargo check, git status)',
            required: true,
          },
        ],
      },
    ],
  },
  {
    id: 'cargo_test_runner',
    name: 'Cargo Test Suite Runner',
    version: '1.0.0',
    description: 'Execute workspace test suite cargo test --bin jarvis-tests.',
    category: 'testing',
    requiredPermission: 'terminal_safe',
    requiresApproval: false,
    allowedRoles: ['code_executor', 'reviewer', 'collaborator'],
    status: 'approved',
    tools: [
      {
        id: 'run_cargo_tests',
        name: 'Run Cargo Tests',
        description: 'Executes the compiled Rust binary test suite.',
        permissionLevel: 'terminal_safe',
        requiresApproval: false,
        isMutating: false,
        parameters: [],
      },
    ],
  },
];

export function validateRegistryIntegrity(): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const skillIds = new Set<string>();
  const toolIds = new Set<string>();

  for (const skill of INITIAL_SKILLS) {
    if (!skill.id || typeof skill.id !== 'string') {
      errors.push(`Skill has missing or invalid ID.`);
    } else if (skillIds.has(skill.id)) {
      errors.push(`Duplicate skill ID found: '${skill.id}'.`);
    } else {
      skillIds.add(skill.id);
    }

    if (!skill.allowedRoles || !Array.isArray(skill.allowedRoles) || skill.allowedRoles.length === 0) {
      errors.push(`Skill '${skill.id}' must specify at least one allowed role.`);
    }

    for (const tool of skill.tools) {
      if (!tool.id || typeof tool.id !== 'string') {
        errors.push(`Tool in skill '${skill.id}' has missing or invalid ID.`);
      } else if (toolIds.has(tool.id)) {
        errors.push(`Duplicate tool ID found: '${tool.id}' in skill '${skill.id}'.`);
      } else {
        toolIds.add(tool.id);
      }

      if (typeof tool.isMutating !== 'boolean') {
        errors.push(`Tool '${tool.id}' must specify explicit boolean 'isMutating'.`);
      }

      if (typeof tool.requiresApproval !== 'boolean') {
        errors.push(`Tool '${tool.id}' must specify explicit boolean 'requiresApproval'.`);
      }

      if (!tool.permissionLevel) {
        errors.push(`Tool '${tool.id}' must specify an explicit permissionLevel.`);
      }
    }
  }

  return { valid: errors.length === 0, errors };
}

export function getAllSkills(): AgentSkill[] {
  return INITIAL_SKILLS;
}

export function getSkill(skillId: string): AgentSkill | undefined {
  return INITIAL_SKILLS.find(s => s.id === skillId);
}

export function getSkillsForRole(role: AgentRole): AgentSkill[] {
  return INITIAL_SKILLS.filter(s => s.status === 'approved' && s.allowedRoles.includes(role));
}

export function getTool(toolId: string): { tool: AgentTool; skill: AgentSkill } | undefined {
  for (const skill of INITIAL_SKILLS) {
    const tool = skill.tools.find(t => t.id === toolId);
    if (tool) {
      return { tool, skill };
    }
  }
  return undefined;
}

export function validateToolParams(
  tool: AgentTool,
  params: Record<string, unknown>
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  for (const param of tool.parameters) {
    const value = params[param.name];
    if (param.required && (value === undefined || value === null || value === '')) {
      errors.push(`Missing required parameter '${param.name}'`);
      continue;
    }

    if (value !== undefined && value !== null) {
      const actualType = Array.isArray(value) ? 'array' : typeof value;
      if (param.type === 'string' && actualType !== 'string') {
        errors.push(`Parameter '${param.name}' must be a string, got ${actualType}`);
      } else if (param.type === 'number' && actualType !== 'number') {
        errors.push(`Parameter '${param.name}' must be a number, got ${actualType}`);
      } else if (param.type === 'boolean' && actualType !== 'boolean') {
        errors.push(`Parameter '${param.name}' must be a boolean, got ${actualType}`);
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
