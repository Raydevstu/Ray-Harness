//! Core layout rendering pipeline for Codex & Jarvis collaboration system.
//! Implements template parsing, tag stripping for `<APPS_INSTRUCTIONS_OPEN_TAG>`,
//! dynamic slot injections, and feature-flag evaluation.

use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct FeatureFlags {
    pub enable_apps: bool,
    pub enable_code_mode: bool,
    pub collaboration_modes: bool,
    pub high_thinking: bool,
}

#[derive(Debug, Clone)]
pub struct AgentConfig {
    pub active_agent: String,
    pub ask_for_approval: bool,
    pub default_subagent_model: String,
    pub default_subagent_reasoning_effort: String,
}

#[derive(Debug, Clone)]
pub struct AppConfig {
    pub ui_mode: String,
    pub model: String,
    pub feature_flags: FeatureFlags,
    pub agents: Option<AgentConfig>,
}

pub struct RenderContext<'a> {
    pub apps_info: &'a str,
    pub context_snapshot: &'a str,
    pub execution_output: &'a str,
    pub template_content: &'a str,
    pub planning_phase: &'a str,
    pub plan_objective: &'a str,
    pub plan_steps: &'a str,
}

pub fn render_layout(config: &AppConfig, ctx: &RenderContext) -> Result<String, String> {
    let mut rendered = ctx.template_content.to_string();

    // Conditionally handle APPS section rendering based on accessibility & feature flags
    if config.feature_flags.enable_apps && !ctx.apps_info.is_empty() {
        let apps_block = format!("\n{}\n", ctx.apps_info);
        rendered = rendered.replace("{{apps_section}}", &apps_block);
    } else {
        // Strip out the APPS instruction tag block if disabled or empty
        let open_tag = "<APPS_INSTRUCTIONS_OPEN_TAG>";
        let close_tag = "</APPS_INSTRUCTIONS_OPEN_TAG>";
        if let (Some(start), Some(end)) = (rendered.find(open_tag), rendered.find(close_tag)) {
            rendered.drain(start..end + close_tag.len());
        }
    }

    // Dynamic slot replacements
    rendered = rendered.replace("{{context_snapshot}}", ctx.context_snapshot);
    rendered = rendered.replace("{{execution_output}}", ctx.execution_output);
    rendered = rendered.replace("{{planning_phase}}", ctx.planning_phase);
    rendered = rendered.replace("{{plan_objective}}", ctx.plan_objective);
    rendered = rendered.replace("{{plan_steps}}", ctx.plan_steps);

    if let Some(agent) = &config.agents {
        rendered = rendered.replace("{{active_agent}}", &agent.active_agent);
        rendered = rendered.replace("{{ask_for_approval}}", &agent.ask_for_approval.to_string());
    }

    Ok(rendered.trim().to_string())
}
