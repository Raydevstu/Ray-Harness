import { FileItem, AgentInfo, AgentMessage } from '../types';

export const CONFIG_JSON_CONTENT = `{
  "profiles": {
    "prod": {
      "controlKey": "0x98f4e2...a1b9",
      "runtimeKey": "dsh-rt-8821...90f2",
      "apiUrl": "https://api.codex.internal/v2/stream",
      "linkUrl": "wss://broker.codex.internal/harness",
      "user": {
        "id": "usr_992147",
        "authUserId": "auth0|64f28e10",
        "email": "hurera.k@enterprise.ai",
        "name": "Hurera K",
        "image": "https://avatar.codex.internal/hk.png"
      }
    }
  }
}`;

export const CONFIG_TOML_CONTENT = `# Codex & Jarvis Collaboration Config
# Array order for notify and args is preserved per schema rules.

model = "gemini-3.1-pro-preview"
model_provider = "google"
model_reasoning_effort = "high"
plan_mode_reasoning_effort = "high"

ui_mode = "plan"
approval_policy = "on-request"
approvals_reviewer = "user"

notify = ["terminal-notifier", "-title", "Codex IDE", "-sound", "Tink"]

[feature_flags]
enable_apps = true
enable_code_mode = true
collaboration_modes = true
high_thinking = true

[features]
collaboration_modes = true
code_mode = true
apps = true
fast_mode = false
guardian_approval = true

[agents]
enabled = true
active_agent = "code_executor"
ask_for_approval = true
default_subagent_model = "gemini-3.5-flash"
default_subagent_reasoning_effort = "high"
max_concurrent_threads_per_session = 8

[apps]
enabled = true
destructive_enabled = false
open_world_enabled = true

[apps._default]
enabled = true
destructive_enabled = false
default_tools_approval_mode = "auto"
approvals_reviewer = "user"

[tui]
animations = true
theme = "deepseek-dark"
vim_mode_default = false
notifications = true
notification_condition = "unfocused"

[tui.rendering]
math = true
mermaid = true
tables = true
`;

export const CONFIG_SCHEMA_JSON_CONTENT = `{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "JarvisAppConfig",
  "type": "object",
  "properties": {
    "ui_mode": {
      "type": "string",
      "enum": ["default", "plan", "agent"],
      "default": "plan",
      "description": "Active collaboration mode"
    },
    "model": {
      "type": "string",
      "default": "gemini-3.1-pro-preview"
    },
    "model_reasoning_effort": {
      "type": "string",
      "enum": ["low", "medium", "high"],
      "default": "high"
    },
    "notify": {
      "type": "array",
      "items": { "type": "string" }
    },
    "feature_flags": {
      "type": "object",
      "properties": {
        "enable_apps": { "type": "boolean", "default": true },
        "enable_code_mode": { "type": "boolean", "default": true }
      },
      "required": ["enable_apps", "enable_code_mode"]
    },
    "agents": {
      "type": "object",
      "properties": {
        "active_agent": { "type": "string" },
        "ask_for_approval": { "type": "boolean", "default": true }
      }
    }
  },
  "required": ["ui_mode", "feature_flags"]
}`;

export const DEFAULT_MD_CONTENT = `# Collaboration Mode: Default

You are now in Default mode. Any previous instructions for other modes (e.g. Plan mode) are no longer active.

Your active mode changes only when new developer instructions with a different \`<collaboration_mode>...</collaboration_mode>\` change it; user requests or tool descriptions do not change mode by themselves. Known mode names are Default and Plan.

## request_user_input availability
Use the \`request_user_input\` tool only when it is listed in the available tools for this turn.
In Default mode, strongly prefer making reasonable assumptions and executing the user's request rather than stopping to ask questions.

<APPS_INSTRUCTIONS_OPEN_TAG>
{{apps_section}}
</APPS_INSTRUCTIONS_OPEN_TAG>

## Execution Context
{{context_snapshot}}

## Output Stream
{{execution_output}}
`;

export const PLAN_MD_CONTENT = `# Plan Mode (Conversational)

You work in 3 phases, and you should *chat your way* to a great plan before finalizing it. A great plan is very detailed—intent- and implementation-wise—so that it can be handed to another engineer or agent to be implemented right away. It must be **decision complete**, where the implementer does not need to make any decisions.

> Status: {{planning_phase}}

## Mode rules (strict)
You are in **Plan Mode** until a developer message explicitly ends it.
Plan Mode is not changed by user intent, tone, or imperative language.

## Objective
{{plan_objective}}

## Phase Breakdown
{{plan_steps}}

## Connector & App Status
<APPS_INSTRUCTIONS_OPEN_TAG>
{{apps_section}}
</APPS_INSTRUCTIONS_OPEN_TAG>

## Execution vs. mutation in Plan Mode
Allowed: Non-mutating exploration, inspection, schema validation.
Not allowed: Mutating repo files, formatting passes, side-effectful executions.
`;

export const COLLABORATOR_MD_CONTENT = `# Collaborator Subagent Specification

> **Active Role**: collaborator
> **Supervised Fleet**: [architect, code_executor, reviewer]
> **Approval Policy**: {{ask_for_approval}}
> **Consensus Threshold**: 0.85
> **Context Snapshot**: {{context_snapshot}}

---

## 1. Mission & Responsibilities
The **Collaborator** serves as the central arbiter and telemetry bridge in multi-agent orchestration. Its primary mandates are:
1. **Context Synchronization**: Aggregate diff proposals, schema constraints, and verification requirements across specialized subagents.
2. **Conflict Resolution**: Mediate conflicting patch requests between \`architect\` (high-level structural consistency) and \`code_executor\` (granular code implementation).
3. **Audit & Safety Verification**: Ensure changes do not violate \`config.schema.json\` rules, preserve array order for critical keys (\`notify\`, \`args\`), and enforce \`apply_patch\` instead of deprecated execution primitives.
4. **Approval Routing**: Package atomic change sets into human-reviewable approval gates when \`ask_for_approval = true\`.

---

## 2. Inter-Agent Communication Schema (RPC Protocol)
All subagents communicate through typed payload frames routed via the Collaborator bridge:

\`\`\`json
{
  "frame_id": "frame_collab_{{timestamp}}",
  "from_agent": "{{active_agent}}",
  "to_agent": "collaborator",
  "intent": "SYNC_DIFF_REQUEST | VALIDATE_SCHEMA | APPROVAL_REQUEST",
  "worktree_ref": "jarvis-app",
  "payload": {
    "target_files": ["config/config.toml", "src/render.rs"],
    "patch_digest": "sha256:4f89b...",
    "tests_passed": true,
    "confidence_score": 0.96
  }
}
\`\`\`

---

## 3. Tool Access & Sandboxing Guidelines
<APPS_INSTRUCTIONS_OPEN_TAG>
{{apps_section}}
</APPS_INSTRUCTIONS_OPEN_TAG>

- The Collaborator has read access to the entire repository and write delegation to \`code_executor\`.
- All shell mutations must be executed via sandboxed \`apply_patch\` tooling.
- Arbitrary code execution (\`eval\`, legacy shell forks) is strictly banned.

---

## 4. Active Communication Thread & Execution Stream
{{execution_output}}

---
*Generated by Codex & Jarvis Collaboration Engine — core/templates/agents/collaborator.md*
`;

export const RENDER_RS_CONTENT = `//! Core layout rendering pipeline for Codex & Jarvis collaboration system.
use std::collections::HashMap;

pub struct AppConfig {
    pub ui_mode: String,
    pub model: String,
    pub feature_flags: FeatureFlags,
    pub agents: Option<AgentConfig>,
}

pub struct RenderContext<'a> {
    pub apps_info: &'a str,
    pub context_snapshot: &'a str,
    pub execution_output: &'a str,
    pub template_content: &'a str,
    pub planning_phase: &'a str,
    pub plan_objective: &'a str,
    pub plan_steps: &'a str,
}

pub fn render_layout(config: &AppConfig, ctx: &RenderContext) -> Result<String, String> {
    let mut rendered = ctx.template_content.to_string();

    // Conditionally handle APPS section rendering based on accessibility & feature flags
    if config.feature_flags.enable_apps && !ctx.apps_info.is_empty() {
        let apps_block = format!("\\n{}\\n", ctx.apps_info);
        rendered = rendered.replace("{{apps_section}}", &apps_block);
    } else {
        let open_tag = "<APPS_INSTRUCTIONS_OPEN_TAG>";
        let close_tag = "</APPS_INSTRUCTIONS_OPEN_TAG>";
        if let (Some(start), Some(end)) = (rendered.find(open_tag), rendered.find(close_tag)) {
            rendered.drain(start..end + close_tag.len());
        }
    }

    rendered = rendered.replace("{{context_snapshot}}", ctx.context_snapshot);
    rendered = rendered.replace("{{execution_output}}", ctx.execution_output);
    rendered = rendered.replace("{{planning_phase}}", ctx.planning_phase);
    rendered = rendered.replace("{{plan_objective}}", ctx.plan_objective);
    rendered = rendered.replace("{{plan_steps}}", ctx.plan_steps);

    Ok(rendered.trim().to_string())
}
`;

export const APPLY_COMMAND_RS_CONTENT = `//! Command mutation handler for UI mode switching, template selection,
//! and contextual state transitions.

use crate::render::{AppConfig, RenderContext, render_layout};

pub enum Command {
    SwitchMode(String),
    UpdateContext(String),
    ExecutePatch(String),
}

pub fn apply_ui_command(cmd: Command, state: &mut SystemState) -> Result<String, String> {
    match cmd {
        Command::SwitchMode(new_mode) => {
            state.config.ui_mode = new_mode.clone();
            state.active_template = match new_mode.as_str() {
                "plan" => include_str!("../core/templates/plan.md").to_string(),
                _ => include_str!("../core/templates/default.md").to_string(),
            };
        }
        Command::UpdateContext(new_ctx) => {
            state.current_snapshot = new_ctx;
        }
        Command::ExecutePatch(patch_data) => {
            if patch_data.contains("DEPRECATED_EXEC_COMMAND") {
                eprintln!("[Warning] Legacy exec command intercepted. Redirecting to apply_patch tool.");
            }
        }
    }

    let ctx = RenderContext {
        apps_info: "Active Apps: [Git, Filesystem, Terminal, Google GenAI]",
        context_snapshot: &state.current_snapshot,
        execution_output: "Ready.",
        template_content: &state.active_template,
        planning_phase: &state.planning_phase,
        plan_objective: &state.plan_objective,
        plan_steps: &state.plan_steps,
    };

    render_layout(&state.config, &ctx)
}
`;

export const LIB_RS_CONTENT = `//! Core library wiring for Jarvis & Codex collaboration engine.
pub mod render;
pub mod apply_command;
pub mod legacy_apply_patch_exec_command_warning;

pub use render::{AppConfig, FeatureFlags, AgentConfig, RenderContext, render_layout};
pub use apply_command::{Command, SystemState, apply_ui_command};
`;

export const INITIAL_FILES: FileItem[] = [
  {
    id: 'config_dir',
    name: 'config',
    path: 'jarvis-app/config',
    type: 'dir',
    children: [
      {
        id: 'config_toml',
        name: 'config.toml',
        path: 'jarvis-app/config/config.toml',
        type: 'file',
        language: 'toml',
        content: CONFIG_TOML_CONTENT,
      },
      {
        id: 'config_schema_json',
        name: 'config.schema.json',
        path: 'jarvis-app/config/config.schema.json',
        type: 'file',
        language: 'json',
        content: CONFIG_SCHEMA_JSON_CONTENT,
      },
    ],
  },
  {
    id: 'core_dir',
    name: 'core',
    path: 'jarvis-app/core',
    type: 'dir',
    children: [
      {
        id: 'templates_dir',
        name: 'templates',
        path: 'jarvis-app/core/templates',
        type: 'dir',
        children: [
          {
            id: 'template_default',
            name: 'default.md',
            path: 'jarvis-app/core/templates/default.md',
            type: 'file',
            language: 'markdown',
            content: DEFAULT_MD_CONTENT,
          },
          {
            id: 'template_plan',
            name: 'plan.md',
            path: 'jarvis-app/core/templates/plan.md',
            type: 'file',
            language: 'markdown',
            content: PLAN_MD_CONTENT,
          },
          {
            id: 'agents_dir',
            name: 'agents',
            path: 'jarvis-app/core/templates/agents',
            type: 'dir',
            children: [
              {
                id: 'template_agent_collab',
                name: 'collaboration.md',
                path: 'jarvis-app/core/templates/agents/collaboration.md',
                type: 'file',
                language: 'markdown',
                content: '# Agent Collaboration Mode\n\nMulti-agent worktree execution blueprint.',
              },
              {
                id: 'template_agent_collaborator',
                name: 'collaborator.md',
                path: 'jarvis-app/core/templates/agents/collaborator.md',
                type: 'file',
                language: 'markdown',
                content: COLLABORATOR_MD_CONTENT,
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 'src_dir',
    name: 'src',
    path: 'jarvis-app/src',
    type: 'dir',
    children: [
      {
        id: 'src_lib_rs',
        name: 'lib.rs',
        path: 'jarvis-app/src/lib.rs',
        type: 'file',
        language: 'rust',
        content: LIB_RS_CONTENT,
      },
      {
        id: 'src_render_rs',
        name: 'render.rs',
        path: 'jarvis-app/src/render.rs',
        type: 'file',
        language: 'rust',
        content: RENDER_RS_CONTENT,
      },
      {
        id: 'src_apply_command_rs',
        name: 'apply_command.rs',
        path: 'jarvis-app/src/apply_command.rs',
        type: 'file',
        language: 'rust',
        content: APPLY_COMMAND_RS_CONTENT,
      },
      {
        id: 'src_legacy_patch_rs',
        name: 'legacy_apply_patch_exec_command_warning.rs',
        path: 'jarvis-app/src/legacy_apply_patch_exec_command_warning.rs',
        type: 'file',
        language: 'rust',
        content: `pub struct LegacyApplyPatchExecCommandWarning;\n// Sanitizes deprecated exec commands into apply_patch calls`,
      },
      {
        id: 'src_command_exec_processor_rs',
        name: 'command_exec_processor.rs',
        path: 'jarvis-app/src/command_exec_processor.rs',
        type: 'file',
        language: 'rust',
        content: `//! \`command_exec_processor.rs\`
//! High-performance Rust command execution processor for Jarvis & Codex Agent Harness.

use std::collections::HashMap;
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CommandSafetyTier {
    SafeReadOnly,
    WorkspaceModifying,
    DangerousNetworkOrSystem,
    Blocked,
}

pub struct CommandExecProcessor {
    policy: CommandPolicy,
    history: Arc<Mutex<Vec<(String, ExecutionResult)>>>,
}

impl CommandExecProcessor {
    pub fn evaluate_safety(&self, raw_cmd: &str) -> CommandSafetyTier {
        // Evaluates safety tier of raw command lines before execution
        CommandSafetyTier::SafeReadOnly
    }
}`,
      },
    ],
  },
  {
    id: 'vscode_dir',
    name: '.vscode',
    path: 'jarvis-app/.vscode',
    type: 'dir',
    children: [
      {
        id: 'vscode_settings',
        name: 'settings.json',
        path: 'jarvis-app/.vscode/settings.json',
        type: 'file',
        language: 'json',
        content: `{\n  "evenBetterToml.formatter.reorderArrays": false,\n  "evenBetterToml.formatter.reorderKeys": true\n}`,
      },
    ],
  },
  {
    id: 'agents',
    name: 'agents',
    path: 'kafsh/agents',
    type: 'dir',
    children: [
      {
        id: 'agent_orchestrator',
        name: 'orchestrator.ts',
        path: 'kafsh/agents/orchestrator.ts',
        type: 'file',
        language: 'typescript',
        content: `// Codex Agent Orchestrator\nexport class AgentOrchestrator {\n  async dispatch(task: string) {\n    return { status: 'queued', taskId: 'tsk_' + Date.now() };\n  }\n}`,
      },
      {
        id: 'agent_harness',
        name: 'harness.json',
        path: 'kafsh/agents/harness.json',
        type: 'file',
        language: 'json',
        content: '{\n  "version": "2.4.0",\n  "maxWorkers": 8,\n  "timeoutSec": 120\n}',
      },
    ],
  },
  {
    id: 'amr',
    name: 'amr',
    path: 'kafsh/amr',
    type: 'dir',
    children: [
      {
        id: 'config_json',
        name: 'config.json',
        path: 'kafsh/amr/config.json',
        type: 'file',
        language: 'json',
        content: CONFIG_JSON_CONTENT,
      },
      {
        id: 'amr_runtime',
        name: 'runtime.ts',
        path: 'kafsh/amr/runtime.ts',
        type: 'file',
        language: 'typescript',
        content: `export const AMR_CONFIG = {\n  region: 'us-east-1',\n  cluster: 'tier-0-nodes',\n  telemetry: true,\n};`,
      },
    ],
  },
  {
    id: 'root_config',
    name: 'config.json',
    path: 'kafsh/config.json',
    type: 'file',
    language: 'json',
    content: CONFIG_JSON_CONTENT,
  },
  {
    id: 'antigravity-ide',
    name: 'antigravity-ide',
    path: 'kafsh/antigravity-ide',
    type: 'dir',
    children: [
      {
        id: 'ag_spec',
        name: 'blueprint.md',
        path: 'kafsh/antigravity-ide/blueprint.md',
        type: 'file',
        language: 'markdown',
        content: '# Antigravity Codex UI\\n\\nZero-deviation layout specification.',
      },
    ],
  },
  {
    id: 'appmap',
    name: 'appmap',
    path: 'kafsh/appmap',
    type: 'dir',
    children: [],
  },
  {
    id: 'aws',
    name: 'aws',
    path: 'kafsh/aws',
    type: 'dir',
    children: [],
  },
  {
    id: 'azure',
    name: 'azure',
    path: 'kafsh/azure',
    type: 'dir',
    children: [],
  },
  {
    id: 'bsk',
    name: 'bsk',
    path: 'kafsh/bsk',
    type: 'dir',
    children: [],
  },
  {
    id: 'bun',
    name: 'bun',
    path: 'kafsh/bun',
    type: 'dir',
    children: [],
  },
  {
    id: 'cache',
    name: 'cache',
    path: 'kafsh/cache',
    type: 'dir',
    children: [],
  },
  {
    id: 'cagent',
    name: 'cagent',
    path: 'kafsh/cagent',
    type: 'dir',
    children: [],
  },
  {
    id: 'chatgpt-copilot',
    name: 'chatgpt-copilot',
    path: 'kafsh/chatgpt-copilot',
    type: 'dir',
    children: [],
  },
  {
    id: 'claude',
    name: 'claude',
    path: 'kafsh/claude',
    type: 'dir',
    children: [],
  },
  {
    id: 'cline',
    name: 'cline',
    path: 'kafsh/cline',
    type: 'dir',
    children: [],
  },
  {
    id: 'cloudbase',
    name: 'cloudbase',
    path: 'kafsh/cloudbase',
    type: 'dir',
    children: [],
  },
  {
    id: 'codex',
    name: 'codex',
    path: 'kafsh/codex',
    type: 'dir',
    children: [],
  },
  {
    id: 'cognee',
    name: 'cognee',
    path: 'kafsh/cognee',
    type: 'dir',
    children: [],
  },
  {
    id: 'conda',
    name: 'conda',
    path: 'kafsh/conda',
    type: 'dir',
    children: [],
  },
];

export const INITIAL_AGENTS: AgentInfo[] = [
  {
    id: 'code_executor',
    name: 'Code Executor',
    description: 'Sandboxed AST patch generator, compiler verification, and test execution.',
    model: 'gemini-3.1-pro-preview',
    status: 'running',
    currentTask: 'Running cargo test verification on render pipeline',
    concurrency: 2,
  },
  {
    id: 'architect',
    name: 'Architect',
    description: 'System schema integrity, macro design consistency, and template rules.',
    model: 'gemini-3.1-pro-preview',
    status: 'idle',
    currentTask: 'Validated config.schema.json & array preservation rules',
    concurrency: 1,
  },
  {
    id: 'reviewer',
    name: 'Reviewer',
    description: 'Zero-trust diff auditing, security vulnerability scans, and approval gates.',
    model: 'gemini-3.5-flash',
    status: 'waiting',
    currentTask: 'Awaiting diff payload from collaborator for approval',
    concurrency: 1,
  },
  {
    id: 'collaborator',
    name: 'Collaborator',
    description: 'Central arbitration bridge, telemetry sync, and cross-agent event distribution.',
    model: 'gemini-3.1-pro-preview',
    status: 'syncing',
    currentTask: 'Synchronizing inter-agent telemetry with live IDE dock',
    concurrency: 3,
  },
];

export const INITIAL_AGENT_MESSAGES: AgentMessage[] = [
  {
    id: 'msg_ag_1',
    fromAgent: 'architect',
    toAgent: 'collaborator',
    timestamp: '10:14:02 AM',
    subject: 'System Schema Coherence Verified',
    body: 'Re-validated config.schema.json against config.toml. All enums (ui_mode, model_reasoning_effort) conform. Array keys `notify` and `args` have reordering locks enforced.',
    status: 'completed',
    codeSnippet: 'ui_mode: "agent" | "plan" | "default"\npreserve_array_order: ["notify", "args"]',
  },
  {
    id: 'msg_ag_2',
    fromAgent: 'collaborator',
    toAgent: 'code_executor',
    timestamp: '10:14:28 AM',
    subject: 'Dispatching Render Pipeline Unit Tests',
    body: 'Requesting isolated compilation check for `src/render.rs` and `src/apply_command.rs` with mock APPS enabled and disabled configurations.',
    status: 'completed',
  },
  {
    id: 'msg_ag_3',
    fromAgent: 'code_executor',
    toAgent: 'collaborator',
    timestamp: '10:15:10 AM',
    subject: 'Test Suite Result: All 4 Tests Passed',
    body: 'Executed cargo test --bin jarvis-tests. Zero regressions detected. Legacy exec redirection verified to apply_patch.',
    status: 'completed',
    codeSnippet: 'test test_default_mode_rendering ... ok\ntest test_apps_strip_when_disabled ... ok\ntest test_collaborator_rpc_routing ... ok',
  },
  {
    id: 'msg_ag_4',
    fromAgent: 'collaborator',
    toAgent: 'reviewer',
    timestamp: '10:16:04 AM',
    subject: 'Review Request: Collaborator RPC & Command Palette integration',
    body: 'Submitting proposed worktree changeset for Command Palette (Ctrl+K) keybindings, config key explorer, and agent communications thread.',
    status: 'in_progress',
    actionRequired: true,
  },
  {
    id: 'msg_ag_5',
    fromAgent: 'reviewer',
    toAgent: 'fleet',
    timestamp: '10:16:45 AM',
    subject: 'Preliminary Diff Analysis: PASSED',
    body: 'Zero unsafe operations detected. All mutations use React state & Rust AST patch abstraction. Ready for user confirmation.',
    status: 'approved',
  },
];

