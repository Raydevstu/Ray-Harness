# Agent Collaboration Mode

> Active Role: {{active_agent}}
> Approval Gate: {{ask_for_approval}}

## Subagent Fleet & Roles
- **code_executor**: Sandboxed AST transformations and tool calls
- **architect**: Global plan verification and schema alignment
- **reviewer**: Zero-trust diff analysis and test generation

## Multi-Agent Worktree Context
{{context_snapshot}}

<APPS_INSTRUCTIONS_OPEN_TAG>
{{apps_section}}
</APPS_INSTRUCTIONS_OPEN_TAG>

## Agent Stream
{{execution_output}}
